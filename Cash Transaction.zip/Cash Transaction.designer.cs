﻿namespace Loop_Inventory
{
    partial class Cash_Transaction
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Cash_Transaction));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lnk_pnt_prview = new System.Windows.Forms.LinkLabel();
            this.bunifuImageButton8 = new Bunifu.Framework.UI.BunifuImageButton();
            this.lnk_exprt = new System.Windows.Forms.LinkLabel();
            this.bunifuImageButton11 = new Bunifu.Framework.UI.BunifuImageButton();
            this.lnk_stock_updte = new System.Windows.Forms.LinkLabel();
            this.lnk_sve = new System.Windows.Forms.LinkLabel();
            this.bunifuImageButton12 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton13 = new Bunifu.Framework.UI.BunifuImageButton();
            this.lnk_sale_rpt = new System.Windows.Forms.LinkLabel();
            this.bunifuImageButton14 = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bunifuImageButton5 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton9 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton6 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton10 = new Bunifu.Framework.UI.BunifuImageButton();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel37 = new System.Windows.Forms.Panel();
            this.u = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.tIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.transactionIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paymentModeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.accountIDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.oldbalanceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.amountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.balanceamountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paymentModeDetailsDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.paymentBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.inventory_DBDataSet = new Loop_Inventory.Inventory_DBDataSet();
            this.txtT_ID = new System.Windows.Forms.TextBox();
            this.panel19 = new System.Windows.Forms.Panel();
            this.cmbAccountType = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txt_dues = new System.Windows.Forms.TextBox();
            this.txt_old_bal = new System.Windows.Forms.TextBox();
            this.btnDelete = new System.Windows.Forms.Button();
            this.panel8 = new System.Windows.Forms.Panel();
            this.cmbPaymentMode = new System.Windows.Forms.ComboBox();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.panel17 = new System.Windows.Forms.Panel();
            this.txtContactNo = new System.Windows.Forms.TextBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.txtAccountName = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.txtAccountID = new System.Windows.Forms.TextBox();
            this.panel34 = new System.Windows.Forms.Panel();
            this.dtpTranactionDate = new System.Windows.Forms.DateTimePicker();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtTransactionNo = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.black = new Bunifu.Framework.UI.BunifuImageButton();
            this.label7 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.lblUser = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.lblBalance = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.Mehroon = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel41 = new System.Windows.Forms.Panel();
            this.txtPaymentModeDetails = new System.Windows.Forms.TextBox();
            this.txtID = new System.Windows.Forms.TextBox();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel18 = new System.Windows.Forms.Panel();
            this.paymentTableAdapter = new Loop_Inventory.Inventory_DBDataSetTableAdapters.PaymentTableAdapter();
            this.add1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel20 = new System.Windows.Forms.Panel();
            this.comboDiscounttype = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.comboCurrencyType = new System.Windows.Forms.ComboBox();
            this.label12 = new System.Windows.Forms.Label();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel22 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel39 = new System.Windows.Forms.Panel();
            this.txtTotalAmountafterdis = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.panel23 = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton14)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.u.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.paymentBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventory_DBDataSet)).BeginInit();
            this.panel19.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.black)).BeginInit();
            this.panel15.SuspendLayout();
            this.panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.Mehroon)).BeginInit();
            this.panel41.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.add1)).BeginInit();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            this.panel22.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel23.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.panel1.Controls.Add(this.lnk_pnt_prview);
            this.panel1.Controls.Add(this.bunifuImageButton8);
            this.panel1.Controls.Add(this.lnk_exprt);
            this.panel1.Controls.Add(this.bunifuImageButton11);
            this.panel1.Controls.Add(this.lnk_stock_updte);
            this.panel1.Controls.Add(this.lnk_sve);
            this.panel1.Controls.Add(this.bunifuImageButton12);
            this.panel1.Controls.Add(this.bunifuImageButton13);
            this.panel1.Controls.Add(this.lnk_sale_rpt);
            this.panel1.Controls.Add(this.bunifuImageButton14);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(695, 95);
            this.panel1.TabIndex = 292;
            // 
            // lnk_pnt_prview
            // 
            this.lnk_pnt_prview.AutoSize = true;
            this.lnk_pnt_prview.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnk_pnt_prview.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lnk_pnt_prview.LinkColor = System.Drawing.Color.White;
            this.lnk_pnt_prview.Location = new System.Drawing.Point(304, 58);
            this.lnk_pnt_prview.Name = "lnk_pnt_prview";
            this.lnk_pnt_prview.Size = new System.Drawing.Size(87, 15);
            this.lnk_pnt_prview.TabIndex = 1004;
            this.lnk_pnt_prview.TabStop = true;
            this.lnk_pnt_prview.Text = "Delete Record";
            // 
            // bunifuImageButton8
            // 
            this.bunifuImageButton8.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton8.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton8.Image")));
            this.bunifuImageButton8.ImageActive = null;
            this.bunifuImageButton8.Location = new System.Drawing.Point(266, 47);
            this.bunifuImageButton8.Name = "bunifuImageButton8";
            this.bunifuImageButton8.Size = new System.Drawing.Size(35, 35);
            this.bunifuImageButton8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton8.TabIndex = 1011;
            this.bunifuImageButton8.TabStop = false;
            this.bunifuImageButton8.Zoom = 10;
            // 
            // lnk_exprt
            // 
            this.lnk_exprt.AutoSize = true;
            this.lnk_exprt.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnk_exprt.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lnk_exprt.LinkColor = System.Drawing.Color.White;
            this.lnk_exprt.Location = new System.Drawing.Point(171, 58);
            this.lnk_exprt.Name = "lnk_exprt";
            this.lnk_exprt.Size = new System.Drawing.Size(91, 15);
            this.lnk_exprt.TabIndex = 1003;
            this.lnk_exprt.TabStop = true;
            this.lnk_exprt.Text = "Update Record";
            // 
            // bunifuImageButton11
            // 
            this.bunifuImageButton11.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton11.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton11.Image")));
            this.bunifuImageButton11.ImageActive = null;
            this.bunifuImageButton11.Location = new System.Drawing.Point(132, 47);
            this.bunifuImageButton11.Name = "bunifuImageButton11";
            this.bunifuImageButton11.Size = new System.Drawing.Size(35, 35);
            this.bunifuImageButton11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton11.TabIndex = 1010;
            this.bunifuImageButton11.TabStop = false;
            this.bunifuImageButton11.Zoom = 10;
            // 
            // lnk_stock_updte
            // 
            this.lnk_stock_updte.AutoSize = true;
            this.lnk_stock_updte.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnk_stock_updte.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lnk_stock_updte.LinkColor = System.Drawing.Color.White;
            this.lnk_stock_updte.Location = new System.Drawing.Point(553, 58);
            this.lnk_stock_updte.Name = "lnk_stock_updte";
            this.lnk_stock_updte.Size = new System.Drawing.Size(95, 15);
            this.lnk_stock_updte.TabIndex = 1006;
            this.lnk_stock_updte.TabStop = true;
            this.lnk_stock_updte.Text = "Export to Excel ";
            // 
            // lnk_sve
            // 
            this.lnk_sve.AutoSize = true;
            this.lnk_sve.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnk_sve.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lnk_sve.LinkColor = System.Drawing.Color.White;
            this.lnk_sve.Location = new System.Drawing.Point(50, 58);
            this.lnk_sve.Name = "lnk_sve";
            this.lnk_sve.Size = new System.Drawing.Size(79, 15);
            this.lnk_sve.TabIndex = 1002;
            this.lnk_sve.TabStop = true;
            this.lnk_sve.Text = "Save Record";
            // 
            // bunifuImageButton12
            // 
            this.bunifuImageButton12.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton12.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton12.Image")));
            this.bunifuImageButton12.ImageActive = null;
            this.bunifuImageButton12.Location = new System.Drawing.Point(15, 47);
            this.bunifuImageButton12.Name = "bunifuImageButton12";
            this.bunifuImageButton12.Size = new System.Drawing.Size(35, 35);
            this.bunifuImageButton12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton12.TabIndex = 1007;
            this.bunifuImageButton12.TabStop = false;
            this.bunifuImageButton12.Zoom = 10;
            // 
            // bunifuImageButton13
            // 
            this.bunifuImageButton13.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton13.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton13.Image")));
            this.bunifuImageButton13.ImageActive = null;
            this.bunifuImageButton13.Location = new System.Drawing.Point(514, 47);
            this.bunifuImageButton13.Name = "bunifuImageButton13";
            this.bunifuImageButton13.Size = new System.Drawing.Size(35, 35);
            this.bunifuImageButton13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton13.TabIndex = 1009;
            this.bunifuImageButton13.TabStop = false;
            this.bunifuImageButton13.Zoom = 10;
            // 
            // lnk_sale_rpt
            // 
            this.lnk_sale_rpt.AutoSize = true;
            this.lnk_sale_rpt.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnk_sale_rpt.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lnk_sale_rpt.LinkColor = System.Drawing.Color.White;
            this.lnk_sale_rpt.Location = new System.Drawing.Point(432, 58);
            this.lnk_sale_rpt.Name = "lnk_sale_rpt";
            this.lnk_sale_rpt.Size = new System.Drawing.Size(81, 15);
            this.lnk_sale_rpt.TabIndex = 1005;
            this.lnk_sale_rpt.TabStop = true;
            this.lnk_sale_rpt.Text = "Clear Record";
            // 
            // bunifuImageButton14
            // 
            this.bunifuImageButton14.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton14.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton14.Image")));
            this.bunifuImageButton14.ImageActive = null;
            this.bunifuImageButton14.Location = new System.Drawing.Point(394, 47);
            this.bunifuImageButton14.Name = "bunifuImageButton14";
            this.bunifuImageButton14.Size = new System.Drawing.Size(35, 35);
            this.bunifuImageButton14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton14.TabIndex = 1008;
            this.bunifuImageButton14.TabStop = false;
            this.bunifuImageButton14.Zoom = 10;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Navy;
            this.panel2.Controls.Add(this.bunifuImageButton5);
            this.panel2.Controls.Add(this.txtID);
            this.panel2.Controls.Add(this.bunifuImageButton9);
            this.panel2.Controls.Add(this.bunifuImageButton6);
            this.panel2.Controls.Add(this.bunifuImageButton10);
            this.panel2.Controls.Add(this.pictureBox1);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(0, 13);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(695, 27);
            this.panel2.TabIndex = 0;
            this.panel2.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseDown);
            this.panel2.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseMove);
            this.panel2.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel2_MouseUp);
            // 
            // bunifuImageButton5
            // 
            this.bunifuImageButton5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton5.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton5.Image")));
            this.bunifuImageButton5.ImageActive = null;
            this.bunifuImageButton5.Location = new System.Drawing.Point(651, 3);
            this.bunifuImageButton5.Name = "bunifuImageButton5";
            this.bunifuImageButton5.Size = new System.Drawing.Size(22, 22);
            this.bunifuImageButton5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton5.TabIndex = 226;
            this.bunifuImageButton5.TabStop = false;
            this.bunifuImageButton5.Zoom = 10;
            this.bunifuImageButton5.Click += new System.EventHandler(this.bunifuImageButton5_Click);
            // 
            // bunifuImageButton9
            // 
            this.bunifuImageButton9.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton9.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton9.Image")));
            this.bunifuImageButton9.ImageActive = null;
            this.bunifuImageButton9.Location = new System.Drawing.Point(828, 3);
            this.bunifuImageButton9.Name = "bunifuImageButton9";
            this.bunifuImageButton9.Size = new System.Drawing.Size(22, 22);
            this.bunifuImageButton9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton9.TabIndex = 288;
            this.bunifuImageButton9.TabStop = false;
            this.bunifuImageButton9.Zoom = 10;
            // 
            // bunifuImageButton6
            // 
            this.bunifuImageButton6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton6.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton6.Image")));
            this.bunifuImageButton6.ImageActive = null;
            this.bunifuImageButton6.Location = new System.Drawing.Point(670, 3);
            this.bunifuImageButton6.Name = "bunifuImageButton6";
            this.bunifuImageButton6.Size = new System.Drawing.Size(22, 22);
            this.bunifuImageButton6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton6.TabIndex = 225;
            this.bunifuImageButton6.TabStop = false;
            this.bunifuImageButton6.Zoom = 10;
            this.bunifuImageButton6.Click += new System.EventHandler(this.bunifuImageButton6_Click);
            // 
            // bunifuImageButton10
            // 
            this.bunifuImageButton10.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton10.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton10.Image")));
            this.bunifuImageButton10.ImageActive = null;
            this.bunifuImageButton10.Location = new System.Drawing.Point(849, 3);
            this.bunifuImageButton10.Name = "bunifuImageButton10";
            this.bunifuImageButton10.Size = new System.Drawing.Size(22, 22);
            this.bunifuImageButton10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton10.TabIndex = 287;
            this.bunifuImageButton10.TabStop = false;
            this.bunifuImageButton10.Zoom = 10;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(1, 0);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(29, 27);
            this.pictureBox1.TabIndex = 286;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Transparent;
            this.label1.Location = new System.Drawing.Point(249, 2);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(187, 23);
            this.label1.TabIndex = 146;
            this.label1.Text = "Cash Transaction Form";
            this.label1.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 95);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(5, 605);
            this.panel4.TabIndex = 294;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.panel5.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel5.Location = new System.Drawing.Point(690, 95);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(5, 605);
            this.panel5.TabIndex = 295;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.panel10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel10.Location = new System.Drawing.Point(5, 695);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(685, 5);
            this.panel10.TabIndex = 296;
            // 
            // panel37
            // 
            this.panel37.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel37.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel37.Location = new System.Drawing.Point(5, 694);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(685, 1);
            this.panel37.TabIndex = 916;
            // 
            // u
            // 
            this.u.BackColor = System.Drawing.Color.White;
            this.u.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("u.BackgroundImage")));
            this.u.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.u.Controls.Add(this.dataGridView1);
            this.u.Controls.Add(this.txtT_ID);
            this.u.Controls.Add(this.panel19);
            this.u.Controls.Add(this.label3);
            this.u.Controls.Add(this.Mehroon);
            this.u.Controls.Add(this.txt_dues);
            this.u.Controls.Add(this.txt_old_bal);
            this.u.Controls.Add(this.add1);
            this.u.Controls.Add(this.btnDelete);
            this.u.Controls.Add(this.panel20);
            this.u.Controls.Add(this.label11);
            this.u.Controls.Add(this.panel8);
            this.u.Controls.Add(this.btnUpdate);
            this.u.Controls.Add(this.panel17);
            this.u.Controls.Add(this.panel6);
            this.u.Controls.Add(this.btnSave);
            this.u.Controls.Add(this.panel9);
            this.u.Controls.Add(this.panel34);
            this.u.Controls.Add(this.panel3);
            this.u.Controls.Add(this.label25);
            this.u.Controls.Add(this.label9);
            this.u.Controls.Add(this.label8);
            this.u.Controls.Add(this.label5);
            this.u.Controls.Add(this.label4);
            this.u.Controls.Add(this.black);
            this.u.Controls.Add(this.label7);
            this.u.Controls.Add(this.label2);
            this.u.Controls.Add(this.label6);
            this.u.Controls.Add(this.panel11);
            this.u.Controls.Add(this.panel14);
            this.u.Controls.Add(this.panel13);
            this.u.Controls.Add(this.panel16);
            this.u.Controls.Add(this.lblUser);
            this.u.Controls.Add(this.panel15);
            this.u.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.u.Location = new System.Drawing.Point(7, 88);
            this.u.Name = "u";
            this.u.Size = new System.Drawing.Size(681, 604);
            this.u.TabIndex = 917;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            dataGridViewCellStyle13.BackColor = System.Drawing.Color.OldLace;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle13;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle14.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle14;
            this.dataGridView1.ColumnHeadersHeight = 24;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.tIDDataGridViewTextBoxColumn,
            this.transactionIDDataGridViewTextBoxColumn,
            this.dateDataGridViewTextBoxColumn,
            this.paymentModeDataGridViewTextBoxColumn,
            this.accountIDDataGridViewTextBoxColumn,
            this.oldbalanceDataGridViewTextBoxColumn,
            this.amountDataGridViewTextBoxColumn,
            this.balanceamountDataGridViewTextBoxColumn,
            this.paymentModeDetailsDataGridViewTextBoxColumn});
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView1.DataSource = this.paymentBindingSource;
            this.dataGridView1.EnableHeadersVisualStyles = false;
            this.dataGridView1.GridColor = System.Drawing.Color.White;
            this.dataGridView1.Location = new System.Drawing.Point(4, 357);
            this.dataGridView1.MultiSelect = false;
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.Color.Orange;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dataGridView1.RowHeadersWidth = 25;
            this.dataGridView1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle16.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle16;
            this.dataGridView1.RowTemplate.Height = 18;
            this.dataGridView1.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView1.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(673, 243);
            this.dataGridView1.TabIndex = 970;
            // 
            // tIDDataGridViewTextBoxColumn
            // 
            this.tIDDataGridViewTextBoxColumn.DataPropertyName = "T_ID";
            this.tIDDataGridViewTextBoxColumn.HeaderText = "T_ID";
            this.tIDDataGridViewTextBoxColumn.Name = "tIDDataGridViewTextBoxColumn";
            this.tIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // transactionIDDataGridViewTextBoxColumn
            // 
            this.transactionIDDataGridViewTextBoxColumn.DataPropertyName = "TransactionID";
            this.transactionIDDataGridViewTextBoxColumn.HeaderText = "TransactionID";
            this.transactionIDDataGridViewTextBoxColumn.Name = "transactionIDDataGridViewTextBoxColumn";
            this.transactionIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dateDataGridViewTextBoxColumn
            // 
            this.dateDataGridViewTextBoxColumn.DataPropertyName = "Date";
            this.dateDataGridViewTextBoxColumn.HeaderText = "Date";
            this.dateDataGridViewTextBoxColumn.Name = "dateDataGridViewTextBoxColumn";
            this.dateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // paymentModeDataGridViewTextBoxColumn
            // 
            this.paymentModeDataGridViewTextBoxColumn.DataPropertyName = "PaymentMode";
            this.paymentModeDataGridViewTextBoxColumn.HeaderText = "PaymentMode";
            this.paymentModeDataGridViewTextBoxColumn.Name = "paymentModeDataGridViewTextBoxColumn";
            this.paymentModeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // accountIDDataGridViewTextBoxColumn
            // 
            this.accountIDDataGridViewTextBoxColumn.DataPropertyName = "AccountID";
            this.accountIDDataGridViewTextBoxColumn.HeaderText = "AccountID";
            this.accountIDDataGridViewTextBoxColumn.Name = "accountIDDataGridViewTextBoxColumn";
            this.accountIDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // oldbalanceDataGridViewTextBoxColumn
            // 
            this.oldbalanceDataGridViewTextBoxColumn.DataPropertyName = "Oldbalance";
            this.oldbalanceDataGridViewTextBoxColumn.HeaderText = "OldBalance";
            this.oldbalanceDataGridViewTextBoxColumn.Name = "oldbalanceDataGridViewTextBoxColumn";
            this.oldbalanceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // amountDataGridViewTextBoxColumn
            // 
            this.amountDataGridViewTextBoxColumn.DataPropertyName = "Amount";
            this.amountDataGridViewTextBoxColumn.HeaderText = "Amount";
            this.amountDataGridViewTextBoxColumn.Name = "amountDataGridViewTextBoxColumn";
            this.amountDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // balanceamountDataGridViewTextBoxColumn
            // 
            this.balanceamountDataGridViewTextBoxColumn.DataPropertyName = "Balanceamount";
            this.balanceamountDataGridViewTextBoxColumn.HeaderText = "Balance";
            this.balanceamountDataGridViewTextBoxColumn.Name = "balanceamountDataGridViewTextBoxColumn";
            this.balanceamountDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // paymentModeDetailsDataGridViewTextBoxColumn
            // 
            this.paymentModeDetailsDataGridViewTextBoxColumn.DataPropertyName = "PaymentModeDetails";
            this.paymentModeDetailsDataGridViewTextBoxColumn.HeaderText = "PayModeDetails";
            this.paymentModeDetailsDataGridViewTextBoxColumn.Name = "paymentModeDetailsDataGridViewTextBoxColumn";
            this.paymentModeDetailsDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // paymentBindingSource
            // 
            this.paymentBindingSource.DataMember = "Payment";
            this.paymentBindingSource.DataSource = this.inventory_DBDataSet;
            // 
            // inventory_DBDataSet
            // 
            this.inventory_DBDataSet.DataSetName = "Inventory_DBDataSet";
            this.inventory_DBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // txtT_ID
            // 
            this.txtT_ID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.txtT_ID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtT_ID.Font = new System.Drawing.Font("Trebuchet MS", 14.25F);
            this.txtT_ID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtT_ID.Location = new System.Drawing.Point(86, 408);
            this.txtT_ID.Name = "txtT_ID";
            this.txtT_ID.ReadOnly = true;
            this.txtT_ID.Size = new System.Drawing.Size(142, 30);
            this.txtT_ID.TabIndex = 1013;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.Gainsboro;
            this.panel19.Controls.Add(this.cmbAccountType);
            this.panel19.Location = new System.Drawing.Point(129, 90);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(191, 29);
            this.panel19.TabIndex = 999;
            // 
            // cmbAccountType
            // 
            this.cmbAccountType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbAccountType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbAccountType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.cmbAccountType.DropDownHeight = 200;
            this.cmbAccountType.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.cmbAccountType.ForeColor = System.Drawing.Color.Black;
            this.cmbAccountType.FormattingEnabled = true;
            this.cmbAccountType.IntegralHeight = false;
            this.cmbAccountType.ItemHeight = 17;
            this.cmbAccountType.Items.AddRange(new object[] {
            "Supplier",
            "Customer"});
            this.cmbAccountType.Location = new System.Drawing.Point(2, 2);
            this.cmbAccountType.MaxDropDownItems = 50;
            this.cmbAccountType.Name = "cmbAccountType";
            this.cmbAccountType.Size = new System.Drawing.Size(187, 25);
            this.cmbAccountType.TabIndex = 572;
            this.cmbAccountType.Text = "--- Select Account Type---";
            this.cmbAccountType.SelectedIndexChanged += new System.EventHandler(this.cmbAccountType_SelectedIndexChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label3.Location = new System.Drawing.Point(11, 96);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 18);
            this.label3.TabIndex = 998;
            this.label3.Text = "Account Type:";
            // 
            // txt_dues
            // 
            this.txt_dues.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_dues.Font = new System.Drawing.Font("Trebuchet MS", 14.25F);
            this.txt_dues.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_dues.Location = new System.Drawing.Point(300, 510);
            this.txt_dues.Name = "txt_dues";
            this.txt_dues.Size = new System.Drawing.Size(142, 30);
            this.txt_dues.TabIndex = 1009;
            // 
            // txt_old_bal
            // 
            this.txt_old_bal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.txt_old_bal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_old_bal.Font = new System.Drawing.Font("Trebuchet MS", 14.25F);
            this.txt_old_bal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_old_bal.Location = new System.Drawing.Point(300, 408);
            this.txt_old_bal.Name = "txt_old_bal";
            this.txt_old_bal.ReadOnly = true;
            this.txt_old_bal.Size = new System.Drawing.Size(142, 30);
            this.txt_old_bal.TabIndex = 1007;
            // 
            // btnDelete
            // 
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Image = ((System.Drawing.Image)(resources.GetObject("btnDelete.Image")));
            this.btnDelete.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.Location = new System.Drawing.Point(548, 307);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(82, 40);
            this.btnDelete.TabIndex = 1006;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Gainsboro;
            this.panel8.Controls.Add(this.cmbPaymentMode);
            this.panel8.Location = new System.Drawing.Point(130, 251);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(191, 29);
            this.panel8.TabIndex = 1001;
            // 
            // cmbPaymentMode
            // 
            this.cmbPaymentMode.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.cmbPaymentMode.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.cmbPaymentMode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.cmbPaymentMode.DropDownHeight = 200;
            this.cmbPaymentMode.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.cmbPaymentMode.ForeColor = System.Drawing.Color.Black;
            this.cmbPaymentMode.FormattingEnabled = true;
            this.cmbPaymentMode.IntegralHeight = false;
            this.cmbPaymentMode.ItemHeight = 17;
            this.cmbPaymentMode.Items.AddRange(new object[] {
            "By Cash",
            "By Cheque",
            "By Online Transfer"});
            this.cmbPaymentMode.Location = new System.Drawing.Point(2, 2);
            this.cmbPaymentMode.MaxDropDownItems = 50;
            this.cmbPaymentMode.Name = "cmbPaymentMode";
            this.cmbPaymentMode.Size = new System.Drawing.Size(187, 25);
            this.cmbPaymentMode.TabIndex = 571;
            this.cmbPaymentMode.Text = "--- Trans Type---";
            this.cmbPaymentMode.SelectedIndexChanged += new System.EventHandler(this.cmbPaymentMode_SelectedIndexChanged);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdate.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnUpdate.Image = ((System.Drawing.Image)(resources.GetObject("btnUpdate.Image")));
            this.btnUpdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUpdate.Location = new System.Drawing.Point(456, 307);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(89, 40);
            this.btnUpdate.TabIndex = 1005;
            this.btnUpdate.Text = " &Update";
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUpdate.UseVisualStyleBackColor = true;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.Gainsboro;
            this.panel17.Controls.Add(this.txtContactNo);
            this.panel17.Location = new System.Drawing.Point(130, 211);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(192, 29);
            this.panel17.TabIndex = 1000;
            // 
            // txtContactNo
            // 
            this.txtContactNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.txtContactNo.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtContactNo.ForeColor = System.Drawing.Color.Black;
            this.txtContactNo.Location = new System.Drawing.Point(2, 2);
            this.txtContactNo.Multiline = true;
            this.txtContactNo.Name = "txtContactNo";
            this.txtContactNo.Size = new System.Drawing.Size(188, 25);
            this.txtContactNo.TabIndex = 4;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Gainsboro;
            this.panel6.Controls.Add(this.txtAccountName);
            this.panel6.Location = new System.Drawing.Point(130, 170);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(191, 29);
            this.panel6.TabIndex = 999;
            // 
            // txtAccountName
            // 
            this.txtAccountName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txtAccountName.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtAccountName.ForeColor = System.Drawing.Color.Black;
            this.txtAccountName.Location = new System.Drawing.Point(2, 2);
            this.txtAccountName.Multiline = true;
            this.txtAccountName.Name = "txtAccountName";
            this.txtAccountName.Size = new System.Drawing.Size(187, 25);
            this.txtAccountName.TabIndex = 4;
            // 
            // btnSave
            // 
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Image = ((System.Drawing.Image)(resources.GetObject("btnSave.Image")));
            this.btnSave.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Location = new System.Drawing.Point(377, 307);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(76, 40);
            this.btnSave.TabIndex = 1004;
            this.btnSave.Text = "&Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Gainsboro;
            this.panel9.Controls.Add(this.txtAccountID);
            this.panel9.Location = new System.Drawing.Point(130, 130);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(167, 29);
            this.panel9.TabIndex = 998;
            // 
            // txtAccountID
            // 
            this.txtAccountID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtAccountID.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtAccountID.ForeColor = System.Drawing.Color.Black;
            this.txtAccountID.Location = new System.Drawing.Point(2, 2);
            this.txtAccountID.Name = "txtAccountID";
            this.txtAccountID.Size = new System.Drawing.Size(163, 25);
            this.txtAccountID.TabIndex = 4;
            this.txtAccountID.TextChanged += new System.EventHandler(this.txtAccountID_TextChanged);
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.Color.Gainsboro;
            this.panel34.Controls.Add(this.dtpTranactionDate);
            this.panel34.Location = new System.Drawing.Point(130, 51);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(191, 29);
            this.panel34.TabIndex = 997;
            // 
            // dtpTranactionDate
            // 
            this.dtpTranactionDate.CalendarFont = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpTranactionDate.CustomFormat = "dd/MM/yyyy";
            this.dtpTranactionDate.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.dtpTranactionDate.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpTranactionDate.Location = new System.Drawing.Point(2, 2);
            this.dtpTranactionDate.Margin = new System.Windows.Forms.Padding(2);
            this.dtpTranactionDate.Name = "dtpTranactionDate";
            this.dtpTranactionDate.Size = new System.Drawing.Size(187, 25);
            this.dtpTranactionDate.TabIndex = 7;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gainsboro;
            this.panel3.Controls.Add(this.txtTransactionNo);
            this.panel3.Location = new System.Drawing.Point(130, 12);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(191, 29);
            this.panel3.TabIndex = 996;
            // 
            // txtTransactionNo
            // 
            this.txtTransactionNo.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.txtTransactionNo.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtTransactionNo.ForeColor = System.Drawing.Color.Black;
            this.txtTransactionNo.Location = new System.Drawing.Point(2, 2);
            this.txtTransactionNo.Name = "txtTransactionNo";
            this.txtTransactionNo.ReadOnly = true;
            this.txtTransactionNo.Size = new System.Drawing.Size(187, 25);
            this.txtTransactionNo.TabIndex = 2;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label25.Location = new System.Drawing.Point(347, 132);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(113, 54);
            this.label25.TabIndex = 986;
            this.label25.Text = "Payment Mode \r\nDetails (Trans ID/\r\nCheque No.)";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label9.Location = new System.Drawing.Point(11, 216);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(106, 18);
            this.label9.TabIndex = 968;
            this.label9.Text = "Mobile Number:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(376, 13);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 20);
            this.label8.TabIndex = 938;
            this.label8.Text = "Cheque Details:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.Location = new System.Drawing.Point(11, 135);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(79, 18);
            this.label5.TabIndex = 964;
            this.label5.Text = "Account ID:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label4.Location = new System.Drawing.Point(11, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(116, 18);
            this.label4.TabIndex = 958;
            this.label4.Text = "Transaction Date:";
            // 
            // black
            // 
            this.black.BackColor = System.Drawing.Color.DimGray;
            this.black.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.black.Image = ((System.Drawing.Image)(resources.GetObject("black.Image")));
            this.black.ImageActive = null;
            this.black.Location = new System.Drawing.Point(301, 135);
            this.black.Name = "black";
            this.black.Size = new System.Drawing.Size(20, 21);
            this.black.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.black.TabIndex = 969;
            this.black.TabStop = false;
            this.black.Zoom = 10;
            this.black.Click += new System.EventHandler(this.black_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label7.Location = new System.Drawing.Point(11, 176);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(101, 18);
            this.label7.TabIndex = 966;
            this.label7.Text = "Account Name:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label2.Location = new System.Drawing.Point(11, 256);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(101, 18);
            this.label2.TabIndex = 960;
            this.label2.Text = "Payment Mode:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label6.Location = new System.Drawing.Point(11, 17);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(101, 18);
            this.label6.TabIndex = 956;
            this.label6.Text = "Transaction ID:";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.Location = new System.Drawing.Point(2, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(677, 2);
            this.panel11.TabIndex = 368;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel14.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel14.Location = new System.Drawing.Point(0, 0);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(2, 602);
            this.panel14.TabIndex = 336;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel13.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel13.Location = new System.Drawing.Point(0, 602);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(679, 2);
            this.panel13.TabIndex = 335;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel16.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel16.Location = new System.Drawing.Point(679, 0);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(2, 604);
            this.panel16.TabIndex = 334;
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(323, 378);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(49, 18);
            this.lblUser.TabIndex = 971;
            this.lblUser.Text = "Label8";
            this.lblUser.Visible = false;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.Transparent;
            this.panel15.Controls.Add(this.label15);
            this.panel15.Controls.Add(this.panel23);
            this.panel15.Controls.Add(this.label14);
            this.panel15.Controls.Add(this.panel39);
            this.panel15.Controls.Add(this.label13);
            this.panel15.Controls.Add(this.panel22);
            this.panel15.Controls.Add(this.bunifuImageButton1);
            this.panel15.Controls.Add(this.panel21);
            this.panel15.Controls.Add(this.label12);
            this.panel15.Controls.Add(this.lblBalance);
            this.panel15.Controls.Add(this.label10);
            this.panel15.Controls.Add(this.panel7);
            this.panel15.Controls.Add(this.panel41);
            this.panel15.Controls.Add(this.panel29);
            this.panel15.Controls.Add(this.panel28);
            this.panel15.Controls.Add(this.panel27);
            this.panel15.Controls.Add(this.panel18);
            this.panel15.Location = new System.Drawing.Point(332, 24);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(340, 306);
            this.panel15.TabIndex = 1003;
            // 
            // lblBalance
            // 
            this.lblBalance.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblBalance.AutoSize = true;
            this.lblBalance.BackColor = System.Drawing.Color.Transparent;
            this.lblBalance.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalance.ForeColor = System.Drawing.Color.Maroon;
            this.lblBalance.Location = new System.Drawing.Point(194, 261);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(32, 24);
            this.lblBalance.TabIndex = 1008;
            this.lblBalance.Text = "00";
            // 
            // label10
            // 
            this.label10.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label10.Location = new System.Drawing.Point(105, 260);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 24);
            this.label10.TabIndex = 1007;
            this.label10.Text = "Balance :";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Transparent;
            this.panel7.Controls.Add(this.panel12);
            this.panel7.ForeColor = System.Drawing.Color.Black;
            this.panel7.Location = new System.Drawing.Point(21, 273);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(290, 26);
            this.panel7.TabIndex = 1006;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Gray;
            this.panel12.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel12.Location = new System.Drawing.Point(0, 0);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(290, 2);
            this.panel12.TabIndex = 426;
            // 
            // Mehroon
            // 
            this.Mehroon.BackColor = System.Drawing.Color.DimGray;
            this.Mehroon.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Mehroon.Image = ((System.Drawing.Image)(resources.GetObject("Mehroon.Image")));
            this.Mehroon.ImageActive = null;
            this.Mehroon.Location = new System.Drawing.Point(301, 135);
            this.Mehroon.Name = "Mehroon";
            this.Mehroon.Size = new System.Drawing.Size(20, 21);
            this.Mehroon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.Mehroon.TabIndex = 1010;
            this.Mehroon.TabStop = false;
            this.Mehroon.Zoom = 10;
            this.Mehroon.Click += new System.EventHandler(this.Mehroon_Click);
            // 
            // panel41
            // 
            this.panel41.BackColor = System.Drawing.Color.Gainsboro;
            this.panel41.Controls.Add(this.txtPaymentModeDetails);
            this.panel41.Location = new System.Drawing.Point(135, 106);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(191, 56);
            this.panel41.TabIndex = 1003;
            // 
            // txtPaymentModeDetails
            // 
            this.txtPaymentModeDetails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.txtPaymentModeDetails.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtPaymentModeDetails.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtPaymentModeDetails.Location = new System.Drawing.Point(2, 2);
            this.txtPaymentModeDetails.Multiline = true;
            this.txtPaymentModeDetails.Name = "txtPaymentModeDetails";
            this.txtPaymentModeDetails.Size = new System.Drawing.Size(187, 52);
            this.txtPaymentModeDetails.TabIndex = 0;
            this.txtPaymentModeDetails.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtID
            // 
            this.txtID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtID.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtID.Location = new System.Drawing.Point(463, -1);
            this.txtID.Multiline = true;
            this.txtID.Name = "txtID";
            this.txtID.Size = new System.Drawing.Size(142, 24);
            this.txtID.TabIndex = 874;
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.Color.DimGray;
            this.panel29.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel29.Location = new System.Drawing.Point(2, 0);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(336, 2);
            this.panel29.TabIndex = 426;
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.DimGray;
            this.panel28.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel28.Location = new System.Drawing.Point(2, 304);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(336, 2);
            this.panel28.TabIndex = 425;
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.DimGray;
            this.panel27.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel27.Location = new System.Drawing.Point(338, 0);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(2, 306);
            this.panel27.TabIndex = 423;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.DimGray;
            this.panel18.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel18.Location = new System.Drawing.Point(0, 0);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(2, 306);
            this.panel18.TabIndex = 422;
            // 
            // paymentTableAdapter
            // 
            this.paymentTableAdapter.ClearBeforeFill = true;
            // 
            // add1
            // 
            this.add1.BackColor = System.Drawing.Color.DimGray;
            this.add1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.add1.Image = ((System.Drawing.Image)(resources.GetObject("add1.Image")));
            this.add1.ImageActive = null;
            this.add1.Location = new System.Drawing.Point(301, 298);
            this.add1.Name = "add1";
            this.add1.Size = new System.Drawing.Size(20, 23);
            this.add1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.add1.TabIndex = 1061;
            this.add1.TabStop = false;
            this.add1.Zoom = 10;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.Gainsboro;
            this.panel20.Controls.Add(this.comboDiscounttype);
            this.panel20.Location = new System.Drawing.Point(130, 294);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(169, 29);
            this.panel20.TabIndex = 1060;
            // 
            // comboDiscounttype
            // 
            this.comboDiscounttype.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboDiscounttype.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboDiscounttype.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.comboDiscounttype.DropDownHeight = 200;
            this.comboDiscounttype.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.comboDiscounttype.ForeColor = System.Drawing.Color.Black;
            this.comboDiscounttype.FormattingEnabled = true;
            this.comboDiscounttype.IntegralHeight = false;
            this.comboDiscounttype.ItemHeight = 17;
            this.comboDiscounttype.Items.AddRange(new object[] {
            "By Cash",
            "By Cheque",
            "By Online Transfer"});
            this.comboDiscounttype.Location = new System.Drawing.Point(2, 2);
            this.comboDiscounttype.MaxDropDownItems = 50;
            this.comboDiscounttype.Name = "comboDiscounttype";
            this.comboDiscounttype.Size = new System.Drawing.Size(165, 25);
            this.comboDiscounttype.TabIndex = 572;
            this.comboDiscounttype.Text = "--- Discount Type---";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label11.Location = new System.Drawing.Point(11, 299);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(99, 18);
            this.label11.TabIndex = 1059;
            this.label11.Text = "Discount Type:";
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.Gainsboro;
            this.panel21.Controls.Add(this.comboCurrencyType);
            this.panel21.Location = new System.Drawing.Point(135, 66);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(169, 29);
            this.panel21.TabIndex = 1063;
            // 
            // comboCurrencyType
            // 
            this.comboCurrencyType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.comboCurrencyType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.comboCurrencyType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.comboCurrencyType.DropDownHeight = 200;
            this.comboCurrencyType.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.comboCurrencyType.ForeColor = System.Drawing.Color.Black;
            this.comboCurrencyType.FormattingEnabled = true;
            this.comboCurrencyType.IntegralHeight = false;
            this.comboCurrencyType.ItemHeight = 17;
            this.comboCurrencyType.Items.AddRange(new object[] {
            "By Cash",
            "By Cheque",
            "By Online Transfer"});
            this.comboCurrencyType.Location = new System.Drawing.Point(2, 2);
            this.comboCurrencyType.MaxDropDownItems = 50;
            this.comboCurrencyType.Name = "comboCurrencyType";
            this.comboCurrencyType.Size = new System.Drawing.Size(165, 25);
            this.comboCurrencyType.TabIndex = 572;
            this.comboCurrencyType.Text = "--- Currency Type---";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label12.Location = new System.Drawing.Point(14, 71);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(111, 18);
            this.label12.TabIndex = 1062;
            this.label12.Text = "Select Currency:";
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.DimGray;
            this.bunifuImageButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(306, 71);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(20, 23);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 1064;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.Gainsboro;
            this.panel22.Controls.Add(this.textBox1);
            this.panel22.Location = new System.Drawing.Point(135, 27);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(189, 29);
            this.panel22.TabIndex = 1061;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.textBox1.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBox1.Location = new System.Drawing.Point(2, 2);
            this.textBox1.Multiline = true;
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(185, 25);
            this.textBox1.TabIndex = 1;
            this.textBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label13.Location = new System.Drawing.Point(14, 32);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(116, 18);
            this.label13.TabIndex = 1065;
            this.label13.Text = "Discount Amount:";
            // 
            // panel39
            // 
            this.panel39.BackColor = System.Drawing.Color.Gainsboro;
            this.panel39.Controls.Add(this.txtTotalAmountafterdis);
            this.panel39.Controls.Add(this.textBox2);
            this.panel39.Location = new System.Drawing.Point(135, 175);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(191, 29);
            this.panel39.TabIndex = 1066;
            // 
            // txtTotalAmountafterdis
            // 
            this.txtTotalAmountafterdis.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtTotalAmountafterdis.Font = new System.Drawing.Font("Trebuchet MS", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalAmountafterdis.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtTotalAmountafterdis.Location = new System.Drawing.Point(2, 2);
            this.txtTotalAmountafterdis.Multiline = true;
            this.txtTotalAmountafterdis.Name = "txtTotalAmountafterdis";
            this.txtTotalAmountafterdis.Size = new System.Drawing.Size(187, 25);
            this.txtTotalAmountafterdis.TabIndex = 0;
            this.txtTotalAmountafterdis.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // textBox2
            // 
            this.textBox2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBox2.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.textBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBox2.Location = new System.Drawing.Point(24, 28);
            this.textBox2.Multiline = true;
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(142, 24);
            this.textBox2.TabIndex = 874;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label14.Location = new System.Drawing.Point(14, 181);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(92, 18);
            this.label14.TabIndex = 1014;
            this.label14.Text = "Total Amount:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label15.Location = new System.Drawing.Point(14, 222);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(47, 18);
            this.label15.TabIndex = 1067;
            this.label15.Text = "Notes:";
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.Gainsboro;
            this.panel23.Controls.Add(this.textBox3);
            this.panel23.Location = new System.Drawing.Point(135, 216);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(191, 40);
            this.panel23.TabIndex = 1068;
            // 
            // textBox3
            // 
            this.textBox3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textBox3.Font = new System.Drawing.Font("Trebuchet MS", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBox3.Location = new System.Drawing.Point(2, 2);
            this.textBox3.Multiline = true;
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(187, 36);
            this.textBox3.TabIndex = 0;
            this.textBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Cash_Transaction
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(695, 700);
            this.Controls.Add(this.u);
            this.Controls.Add(this.panel37);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Cash_Transaction";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cash_Transaction";
            this.Load += new System.EventHandler(this.Cash_Transaction_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton14)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.u.ResumeLayout(false);
            this.u.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.paymentBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventory_DBDataSet)).EndInit();
            this.panel19.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel34.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.black)).EndInit();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.Mehroon)).EndInit();
            this.panel41.ResumeLayout(false);
            this.panel41.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.add1)).EndInit();
            this.panel20.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel39.ResumeLayout(false);
            this.panel39.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton5;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton9;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton6;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton10;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Panel u;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        internal System.Windows.Forms.DataGridView dataGridView1;
        private Bunifu.Framework.UI.BunifuImageButton black;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label6;
        internal System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.Label label8;
       
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtTransactionNo;
        private System.Windows.Forms.Panel panel34;
        internal System.Windows.Forms.DateTimePicker dtpTranactionDate;
        private System.Windows.Forms.Panel panel9;
        public System.Windows.Forms.TextBox txtAccountID;
        private System.Windows.Forms.Panel panel6;
        public System.Windows.Forms.TextBox txtAccountName;
        private System.Windows.Forms.Panel panel17;
        public System.Windows.Forms.TextBox txtContactNo;
        private System.Windows.Forms.Panel panel8;
        public System.Windows.Forms.ComboBox cmbPaymentMode;
        private System.Windows.Forms.Panel panel15;
        public System.Windows.Forms.Label lblBalance;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.TextBox txtPaymentModeDetails;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel18;
        internal System.Windows.Forms.Button btnDelete;
        internal System.Windows.Forms.Button btnUpdate;
        internal System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.LinkLabel lnk_pnt_prview;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton8;
        private System.Windows.Forms.LinkLabel lnk_exprt;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton11;
        private System.Windows.Forms.LinkLabel lnk_stock_updte;
        private System.Windows.Forms.LinkLabel lnk_sve;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton12;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton13;
        private System.Windows.Forms.LinkLabel lnk_sale_rpt;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton14;
        public System.Windows.Forms.TextBox txt_dues;
        public System.Windows.Forms.TextBox txt_old_bal;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label3;
        private Bunifu.Framework.UI.BunifuImageButton Mehroon;
        public System.Windows.Forms.TextBox txtT_ID;
        public System.Windows.Forms.TextBox txtID;
        private Inventory_DBDataSet inventory_DBDataSet;
        private System.Windows.Forms.BindingSource paymentBindingSource;
        private Inventory_DBDataSetTableAdapters.PaymentTableAdapter paymentTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn tIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn transactionIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn dateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paymentModeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn accountIDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn oldbalanceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn amountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn balanceamountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn paymentModeDetailsDataGridViewTextBoxColumn;
        public System.Windows.Forms.ComboBox cmbAccountType;
        private Bunifu.Framework.UI.BunifuImageButton add1;
        private System.Windows.Forms.Panel panel20;
        public System.Windows.Forms.ComboBox comboDiscounttype;
        private System.Windows.Forms.Label label11;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private System.Windows.Forms.Panel panel21;
        public System.Windows.Forms.ComboBox comboCurrencyType;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.TextBox txtTotalAmountafterdis;
        public System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.TextBox textBox3;
    }
}