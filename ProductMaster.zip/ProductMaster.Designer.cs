﻿namespace Loop_Inventory
{
    partial class ProductMaster
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ProductMaster));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.txtID = new System.Windows.Forms.TextBox();
            this.close = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.label24 = new System.Windows.Forms.Label();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.panel37 = new System.Windows.Forms.Panel();
            this.panel21 = new System.Windows.Forms.Panel();
            this.label28 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel42 = new System.Windows.Forms.Panel();
            this.panel43 = new System.Windows.Forms.Panel();
            this.panel45 = new System.Windows.Forms.Panel();
            this.panel46 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.dgvExcelData = new System.Windows.Forms.DataGridView();
            this.btnReset = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.panel9 = new System.Windows.Forms.Panel();
            this.btnGetData = new System.Windows.Forms.Button();
            this.panel34 = new System.Windows.Forms.Panel();
            this.txtFilePath = new System.Windows.Forms.TextBox();
            this.panel15 = new System.Windows.Forms.Panel();
            this.panel16 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel38 = new System.Windows.Forms.Panel();
            this.panel39 = new System.Windows.Forms.Panel();
            this.panel40 = new System.Windows.Forms.Panel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.dgw = new System.Windows.Forms.DataGridView();
            this.iDDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.barcode1DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.barcode2DataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.codeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameArabicDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nameEngDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.storeTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.brandNameDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.categoryDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.unitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colorDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.descriptionDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.qtyPerUnitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.companyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.venderDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.discountTypeDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.directDiscountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nextShoppingDiscountDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.taxPercentDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.reorderLevelDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.manufacturingDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.expireDateDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchaseCurrencyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.sellingCurrencyDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.wholeSalePriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.purchasePriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.retailPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.customerPriceDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addProfitDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.statusDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tblItemMasterBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.inventory_DBDataSet = new Loop_Inventory.Inventory_DBDataSet();
            this.btnfetch = new System.Windows.Forms.Button();
            this.btn_export = new System.Windows.Forms.Button();
            this.label38 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel47 = new System.Windows.Forms.Panel();
            this.panel48 = new System.Windows.Forms.Panel();
            this.panel49 = new System.Windows.Forms.Panel();
            this.panel50 = new System.Windows.Forms.Panel();
            this.panel51 = new System.Windows.Forms.Panel();
            this.panel52 = new System.Windows.Forms.Panel();
            this.dateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.panel53 = new System.Windows.Forms.Panel();
            this.panel54 = new System.Windows.Forms.Panel();
            this.panel55 = new System.Windows.Forms.Panel();
            this.panel56 = new System.Windows.Forms.Panel();
            this.panel57 = new System.Windows.Forms.Panel();
            this.panel62 = new System.Windows.Forms.Panel();
            this.dateTimePicker4 = new System.Windows.Forms.DateTimePicker();
            this.panel58 = new System.Windows.Forms.Panel();
            this.panel59 = new System.Windows.Forms.Panel();
            this.panel60 = new System.Windows.Forms.Panel();
            this.panel61 = new System.Windows.Forms.Panel();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.u = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.btn_print = new System.Windows.Forms.Button();
            this.combo_search_type = new System.Windows.Forms.ComboBox();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel12 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.lblUser = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.panel90 = new System.Windows.Forms.Panel();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.btndel = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.label23 = new System.Windows.Forms.Label();
            this.add9 = new Bunifu.Framework.UI.BunifuImageButton();
            this.add8 = new Bunifu.Framework.UI.BunifuImageButton();
            this.label36 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.panel87 = new System.Windows.Forms.Panel();
            this.combo_Status = new System.Windows.Forms.ComboBox();
            this.panel88 = new System.Windows.Forms.Panel();
            this.txt_OpenningStock = new System.Windows.Forms.TextBox();
            this.label35 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.panel85 = new System.Windows.Forms.Panel();
            this.txt_Location = new System.Windows.Forms.TextBox();
            this.panel83 = new System.Windows.Forms.Panel();
            this.txt_RetailPrice = new System.Windows.Forms.TextBox();
            this.panel86 = new System.Windows.Forms.Panel();
            this.txt_AddProfit = new System.Windows.Forms.TextBox();
            this.panel84 = new System.Windows.Forms.Panel();
            this.txt_CustomerPrice = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.panel82 = new System.Windows.Forms.Panel();
            this.txt_PurchasePrice = new System.Windows.Forms.TextBox();
            this.panel81 = new System.Windows.Forms.Panel();
            this.txt_WholeSalePrice = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.panel80 = new System.Windows.Forms.Panel();
            this.combo_SellingCurrency = new System.Windows.Forms.ComboBox();
            this.panel79 = new System.Windows.Forms.Panel();
            this.combo_PurchaseCurency = new System.Windows.Forms.ComboBox();
            this.label26 = new System.Windows.Forms.Label();
            this.add6 = new Bunifu.Framework.UI.BunifuImageButton();
            this.label20 = new System.Windows.Forms.Label();
            this.panel71 = new System.Windows.Forms.Panel();
            this.txt_ReorderLevel = new System.Windows.Forms.TextBox();
            this.panel67 = new System.Windows.Forms.Panel();
            this.txt_TaxAmount = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.panel68 = new System.Windows.Forms.Panel();
            this.combo_TaxType = new System.Windows.Forms.ComboBox();
            this.panel66 = new System.Windows.Forms.Panel();
            this.txt_CompanyProduct = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.panel65 = new System.Windows.Forms.Panel();
            this.txt_QtyPerUnit = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.panel30 = new System.Windows.Forms.Panel();
            this.txt_Description = new System.Windows.Forms.TextBox();
            this.panel23 = new System.Windows.Forms.Panel();
            this.txt_ProductnameEng = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.txt_ProductnameArabic = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.add5 = new Bunifu.Framework.UI.BunifuImageButton();
            this.add4 = new Bunifu.Framework.UI.BunifuImageButton();
            this.add3 = new Bunifu.Framework.UI.BunifuImageButton();
            this.add2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.add1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel18 = new System.Windows.Forms.Panel();
            this.combo_Unit = new System.Windows.Forms.ComboBox();
            this.panel8 = new System.Windows.Forms.Panel();
            this.combo_Color = new System.Windows.Forms.ComboBox();
            this.panel24 = new System.Windows.Forms.Panel();
            this.combo_Brand = new System.Windows.Forms.ComboBox();
            this.panel31 = new System.Windows.Forms.Panel();
            this.combo_Category = new System.Windows.Forms.ComboBox();
            this.panel32 = new System.Windows.Forms.Panel();
            this.combo_Store = new System.Windows.Forms.ComboBox();
            this.panel33 = new System.Windows.Forms.Panel();
            this.txt_Productcode = new System.Windows.Forms.TextBox();
            this.panel63 = new System.Windows.Forms.Panel();
            this.txt_Barcode2 = new System.Windows.Forms.TextBox();
            this.panel64 = new System.Windows.Forms.Panel();
            this.txt_Barcode1 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel28 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel69 = new System.Windows.Forms.Panel();
            this.panel91 = new System.Windows.Forms.Panel();
            this.txt_PreferredVender = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.panel78 = new System.Windows.Forms.Panel();
            this.txt_NextShoppingDiscount = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.panel77 = new System.Windows.Forms.Panel();
            this.txt_DirectDiscount = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.panel70 = new System.Windows.Forms.Panel();
            this.txt_DiscountAmount = new System.Windows.Forms.TextBox();
            this.add7 = new Bunifu.Framework.UI.BunifuImageButton();
            this.label19 = new System.Windows.Forms.Label();
            this.panel72 = new System.Windows.Forms.Panel();
            this.combo_DiscountType = new System.Windows.Forms.ComboBox();
            this.panel73 = new System.Windows.Forms.Panel();
            this.panel74 = new System.Windows.Forms.Panel();
            this.panel75 = new System.Windows.Forms.Panel();
            this.panel76 = new System.Windows.Forms.Panel();
            this.panel89 = new System.Windows.Forms.Panel();
            this.panel95 = new System.Windows.Forms.Panel();
            this.panel11 = new System.Windows.Forms.Panel();
            this.panel14 = new System.Windows.Forms.Panel();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel44 = new System.Windows.Forms.Panel();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tblItemMasterTableAdapter = new Loop_Inventory.Inventory_DBDataSetTableAdapters.tblItemMasterTableAdapter();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.close)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            this.tabPage4.SuspendLayout();
            this.panel37.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExcelData)).BeginInit();
            this.panel9.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel22.SuspendLayout();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgw)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblItemMasterBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventory_DBDataSet)).BeginInit();
            this.panel35.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel51.SuspendLayout();
            this.panel52.SuspendLayout();
            this.panel57.SuspendLayout();
            this.panel62.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.u.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel17.SuspendLayout();
            this.panel90.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.add9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.add8)).BeginInit();
            this.panel87.SuspendLayout();
            this.panel88.SuspendLayout();
            this.panel85.SuspendLayout();
            this.panel83.SuspendLayout();
            this.panel86.SuspendLayout();
            this.panel84.SuspendLayout();
            this.panel82.SuspendLayout();
            this.panel81.SuspendLayout();
            this.panel80.SuspendLayout();
            this.panel79.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.add6)).BeginInit();
            this.panel71.SuspendLayout();
            this.panel67.SuspendLayout();
            this.panel68.SuspendLayout();
            this.panel66.SuspendLayout();
            this.panel65.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel25.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.add5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.add4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.add3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.add2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.add1)).BeginInit();
            this.panel18.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel63.SuspendLayout();
            this.panel64.SuspendLayout();
            this.panel69.SuspendLayout();
            this.panel91.SuspendLayout();
            this.panel78.SuspendLayout();
            this.panel77.SuspendLayout();
            this.panel70.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.add7)).BeginInit();
            this.panel72.SuspendLayout();
            this.panel89.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 31);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(2, 680);
            this.panel4.TabIndex = 296;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.panel5.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel5.Location = new System.Drawing.Point(1100, 31);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(2, 680);
            this.panel5.TabIndex = 297;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.panel10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel10.Location = new System.Drawing.Point(2, 709);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(1098, 2);
            this.panel10.TabIndex = 298;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.panel1.Controls.Add(this.txtID);
            this.panel1.Controls.Add(this.close);
            this.panel1.Controls.Add(this.bunifuImageButton1);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1102, 31);
            this.panel1.TabIndex = 294;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // txtID
            // 
            this.txtID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.txtID.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtID.ForeColor = System.Drawing.Color.Black;
            this.txtID.Location = new System.Drawing.Point(385, 3);
            this.txtID.Name = "txtID";
            this.txtID.ReadOnly = true;
            this.txtID.Size = new System.Drawing.Size(10, 25);
            this.txtID.TabIndex = 989;
            // 
            // close
            // 
            this.close.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.close.BackColor = System.Drawing.Color.Transparent;
            this.close.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.close.Image = ((System.Drawing.Image)(resources.GetObject("close.Image")));
            this.close.ImageActive = null;
            this.close.Location = new System.Drawing.Point(1077, 4);
            this.close.Name = "close";
            this.close.Size = new System.Drawing.Size(22, 22);
            this.close.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.close.TabIndex = 324;
            this.close.TabStop = false;
            this.close.Zoom = 10;
            this.close.Click += new System.EventHandler(this.close_Click);
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(1, 5);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(20, 21);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton1.TabIndex = 323;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Transparent;
            this.label24.Location = new System.Drawing.Point(24, 5);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(116, 20);
            this.label24.TabIndex = 322;
            this.label24.Text = "Product Master";
            this.label24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.LightCyan;
            this.tabPage4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage4.Controls.Add(this.panel37);
            this.tabPage4.Controls.Add(this.label15);
            this.tabPage4.Controls.Add(this.dgvExcelData);
            this.tabPage4.Controls.Add(this.btnReset);
            this.tabPage4.Controls.Add(this.button3);
            this.tabPage4.Controls.Add(this.panel9);
            this.tabPage4.Controls.Add(this.panel22);
            this.tabPage4.Location = new System.Drawing.Point(4, 30);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(1090, 644);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Import Product";
            // 
            // panel37
            // 
            this.panel37.BackColor = System.Drawing.Color.Transparent;
            this.panel37.Controls.Add(this.panel21);
            this.panel37.Controls.Add(this.label28);
            this.panel37.Controls.Add(this.pictureBox1);
            this.panel37.Controls.Add(this.panel42);
            this.panel37.Controls.Add(this.panel43);
            this.panel37.Controls.Add(this.panel45);
            this.panel37.Controls.Add(this.panel46);
            this.panel37.ForeColor = System.Drawing.Color.DarkGray;
            this.panel37.Location = new System.Drawing.Point(641, 16);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(317, 66);
            this.panel37.TabIndex = 825;
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.Gainsboro;
            this.panel21.Location = new System.Drawing.Point(252, 27);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(191, 10);
            this.panel21.TabIndex = 826;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.DimGray;
            this.label28.Location = new System.Drawing.Point(74, 21);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(172, 20);
            this.label28.TabIndex = 826;
            this.label28.Text = "From Excel to Sql Server";
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox1.Location = new System.Drawing.Point(8, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(57, 58);
            this.pictureBox1.TabIndex = 427;
            this.pictureBox1.TabStop = false;
            // 
            // panel42
            // 
            this.panel42.BackColor = System.Drawing.Color.Gray;
            this.panel42.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel42.Location = new System.Drawing.Point(2, 0);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(313, 2);
            this.panel42.TabIndex = 426;
            // 
            // panel43
            // 
            this.panel43.BackColor = System.Drawing.Color.Gray;
            this.panel43.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel43.ForeColor = System.Drawing.Color.Gainsboro;
            this.panel43.Location = new System.Drawing.Point(2, 64);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(313, 2);
            this.panel43.TabIndex = 425;
            // 
            // panel45
            // 
            this.panel45.BackColor = System.Drawing.Color.Gray;
            this.panel45.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel45.Location = new System.Drawing.Point(315, 0);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(2, 66);
            this.panel45.TabIndex = 423;
            // 
            // panel46
            // 
            this.panel46.BackColor = System.Drawing.Color.Gray;
            this.panel46.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel46.Location = new System.Drawing.Point(0, 0);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(2, 66);
            this.panel46.TabIndex = 422;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.BackColor = System.Drawing.Color.Transparent;
            this.label15.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(41, 5);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(194, 20);
            this.label15.TabIndex = 822;
            this.label15.Text = "Import Product From Excel:";
            // 
            // dgvExcelData
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.OldLace;
            this.dgvExcelData.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvExcelData.BackgroundColor = System.Drawing.Color.White;
            this.dgvExcelData.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvExcelData.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvExcelData.ColumnHeadersHeight = 24;
            this.dgvExcelData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgvExcelData.EnableHeadersVisualStyles = false;
            this.dgvExcelData.GridColor = System.Drawing.Color.White;
            this.dgvExcelData.Location = new System.Drawing.Point(6, 91);
            this.dgvExcelData.MultiSelect = false;
            this.dgvExcelData.Name = "dgvExcelData";
            this.dgvExcelData.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.Orange;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvExcelData.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvExcelData.RowHeadersWidth = 25;
            this.dgvExcelData.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.Color.White;
            this.dgvExcelData.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvExcelData.RowTemplate.Height = 18;
            this.dgvExcelData.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvExcelData.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvExcelData.Size = new System.Drawing.Size(1077, 545);
            this.dgvExcelData.TabIndex = 819;
            // 
            // btnReset
            // 
            this.btnReset.BackColor = System.Drawing.Color.Transparent;
            this.btnReset.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReset.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnReset.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReset.ForeColor = System.Drawing.Color.Black;
            this.btnReset.Image = ((System.Drawing.Image)(resources.GetObject("btnReset.Image")));
            this.btnReset.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnReset.Location = new System.Drawing.Point(549, 34);
            this.btnReset.Name = "btnReset";
            this.btnReset.Size = new System.Drawing.Size(80, 35);
            this.btnReset.TabIndex = 821;
            this.btnReset.Text = "Reset";
            this.btnReset.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnReset.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.White;
            this.button3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
            this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button3.Location = new System.Drawing.Point(414, 34);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(129, 35);
            this.button3.TabIndex = 818;
            this.button3.Text = "&Save Records";
            this.button3.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button3.UseVisualStyleBackColor = false;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Transparent;
            this.panel9.Controls.Add(this.btnGetData);
            this.panel9.Controls.Add(this.panel34);
            this.panel9.Controls.Add(this.panel15);
            this.panel9.Controls.Add(this.panel16);
            this.panel9.Controls.Add(this.panel19);
            this.panel9.Controls.Add(this.panel20);
            this.panel9.ForeColor = System.Drawing.Color.DarkGray;
            this.panel9.Location = new System.Drawing.Point(6, 16);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(399, 66);
            this.panel9.TabIndex = 823;
            // 
            // btnGetData
            // 
            this.btnGetData.BackColor = System.Drawing.Color.White;
            this.btnGetData.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGetData.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnGetData.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGetData.ForeColor = System.Drawing.Color.Black;
            this.btnGetData.Image = ((System.Drawing.Image)(resources.GetObject("btnGetData.Image")));
            this.btnGetData.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnGetData.Location = new System.Drawing.Point(277, 18);
            this.btnGetData.Name = "btnGetData";
            this.btnGetData.Size = new System.Drawing.Size(112, 35);
            this.btnGetData.TabIndex = 1;
            this.btnGetData.Text = " Load Excel";
            this.btnGetData.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnGetData.UseVisualStyleBackColor = false;
            this.btnGetData.Click += new System.EventHandler(this.btnGetData_Click);
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.Color.Gainsboro;
            this.panel34.Controls.Add(this.txtFilePath);
            this.panel34.Location = new System.Drawing.Point(8, 18);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(259, 35);
            this.panel34.TabIndex = 542;
            // 
            // txtFilePath
            // 
            this.txtFilePath.BackColor = System.Drawing.Color.White;
            this.txtFilePath.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFilePath.Location = new System.Drawing.Point(3, 3);
            this.txtFilePath.Multiline = true;
            this.txtFilePath.Name = "txtFilePath";
            this.txtFilePath.Size = new System.Drawing.Size(253, 29);
            this.txtFilePath.TabIndex = 1;
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.Color.Gray;
            this.panel15.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel15.Location = new System.Drawing.Point(2, 0);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(395, 2);
            this.panel15.TabIndex = 426;
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.Color.Gray;
            this.panel16.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel16.ForeColor = System.Drawing.Color.Gainsboro;
            this.panel16.Location = new System.Drawing.Point(2, 64);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(395, 2);
            this.panel16.TabIndex = 425;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.Color.Gray;
            this.panel19.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel19.Location = new System.Drawing.Point(397, 0);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(2, 66);
            this.panel19.TabIndex = 423;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.Gray;
            this.panel20.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel20.Location = new System.Drawing.Point(0, 0);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(2, 66);
            this.panel20.TabIndex = 422;
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.Transparent;
            this.panel22.Controls.Add(this.panel38);
            this.panel22.Controls.Add(this.panel39);
            this.panel22.Controls.Add(this.panel40);
            this.panel22.Controls.Add(this.panel41);
            this.panel22.ForeColor = System.Drawing.Color.DarkGray;
            this.panel22.Location = new System.Drawing.Point(409, 16);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(226, 66);
            this.panel22.TabIndex = 824;
            // 
            // panel38
            // 
            this.panel38.BackColor = System.Drawing.Color.Gray;
            this.panel38.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel38.Location = new System.Drawing.Point(2, 0);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(222, 2);
            this.panel38.TabIndex = 426;
            // 
            // panel39
            // 
            this.panel39.BackColor = System.Drawing.Color.Gray;
            this.panel39.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel39.ForeColor = System.Drawing.Color.Gainsboro;
            this.panel39.Location = new System.Drawing.Point(2, 64);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(222, 2);
            this.panel39.TabIndex = 425;
            // 
            // panel40
            // 
            this.panel40.BackColor = System.Drawing.Color.Gray;
            this.panel40.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel40.Location = new System.Drawing.Point(224, 0);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(2, 66);
            this.panel40.TabIndex = 423;
            // 
            // panel41
            // 
            this.panel41.BackColor = System.Drawing.Color.Gray;
            this.panel41.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel41.Location = new System.Drawing.Point(0, 0);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(2, 66);
            this.panel41.TabIndex = 422;
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.LightCyan;
            this.tabPage3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabPage3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tabPage3.Controls.Add(this.dgw);
            this.tabPage3.Controls.Add(this.btnfetch);
            this.tabPage3.Controls.Add(this.btn_export);
            this.tabPage3.Controls.Add(this.label38);
            this.tabPage3.Controls.Add(this.label37);
            this.tabPage3.Controls.Add(this.panel35);
            this.tabPage3.Controls.Add(this.panel51);
            this.tabPage3.Controls.Add(this.panel57);
            this.tabPage3.Location = new System.Drawing.Point(4, 30);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(1090, 644);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Export Product";
            // 
            // dgw
            // 
            this.dgw.AllowUserToAddRows = false;
            this.dgw.AllowUserToDeleteRows = false;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.OldLace;
            this.dgw.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle5;
            this.dgw.AutoGenerateColumns = false;
            this.dgw.BackgroundColor = System.Drawing.Color.White;
            this.dgw.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgw.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgw.ColumnHeadersHeight = 24;
            this.dgw.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDDataGridViewTextBoxColumn,
            this.barcode1DataGridViewTextBoxColumn,
            this.barcode2DataGridViewTextBoxColumn,
            this.codeDataGridViewTextBoxColumn,
            this.nameArabicDataGridViewTextBoxColumn,
            this.nameEngDataGridViewTextBoxColumn,
            this.storeTypeDataGridViewTextBoxColumn,
            this.brandNameDataGridViewTextBoxColumn,
            this.categoryDataGridViewTextBoxColumn,
            this.unitDataGridViewTextBoxColumn,
            this.colorDataGridViewTextBoxColumn,
            this.descriptionDataGridViewTextBoxColumn,
            this.qtyPerUnitDataGridViewTextBoxColumn,
            this.companyDataGridViewTextBoxColumn,
            this.venderDataGridViewTextBoxColumn,
            this.discountTypeDataGridViewTextBoxColumn,
            this.directDiscountDataGridViewTextBoxColumn,
            this.nextShoppingDiscountDataGridViewTextBoxColumn,
            this.taxPercentDataGridViewTextBoxColumn,
            this.reorderLevelDataGridViewTextBoxColumn,
            this.manufacturingDateDataGridViewTextBoxColumn,
            this.expireDateDataGridViewTextBoxColumn,
            this.purchaseCurrencyDataGridViewTextBoxColumn,
            this.sellingCurrencyDataGridViewTextBoxColumn,
            this.wholeSalePriceDataGridViewTextBoxColumn,
            this.purchasePriceDataGridViewTextBoxColumn,
            this.customPriceDataGridViewTextBoxColumn,
            this.retailPriceDataGridViewTextBoxColumn,
            this.customerPriceDataGridViewTextBoxColumn,
            this.addProfitDataGridViewTextBoxColumn,
            this.statusDataGridViewTextBoxColumn});
            this.dgw.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dgw.DataSource = this.tblItemMasterBindingSource;
            this.dgw.EnableHeadersVisualStyles = false;
            this.dgw.GridColor = System.Drawing.Color.White;
            this.dgw.Location = new System.Drawing.Point(6, 87);
            this.dgw.MultiSelect = false;
            this.dgw.Name = "dgw";
            this.dgw.ReadOnly = true;
            this.dgw.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.Orange;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgw.RowHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgw.RowHeadersWidth = 25;
            this.dgw.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle8.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.Color.White;
            this.dgw.RowsDefaultCellStyle = dataGridViewCellStyle8;
            this.dgw.RowTemplate.Height = 18;
            this.dgw.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dgw.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.dgw.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgw.Size = new System.Drawing.Size(1077, 549);
            this.dgw.TabIndex = 924;
            // 
            // iDDataGridViewTextBoxColumn
            // 
            this.iDDataGridViewTextBoxColumn.DataPropertyName = "ID";
            this.iDDataGridViewTextBoxColumn.HeaderText = "ID";
            this.iDDataGridViewTextBoxColumn.Name = "iDDataGridViewTextBoxColumn";
            this.iDDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // barcode1DataGridViewTextBoxColumn
            // 
            this.barcode1DataGridViewTextBoxColumn.DataPropertyName = "Barcode1";
            this.barcode1DataGridViewTextBoxColumn.HeaderText = "Barcode1";
            this.barcode1DataGridViewTextBoxColumn.Name = "barcode1DataGridViewTextBoxColumn";
            this.barcode1DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // barcode2DataGridViewTextBoxColumn
            // 
            this.barcode2DataGridViewTextBoxColumn.DataPropertyName = "Barcode2";
            this.barcode2DataGridViewTextBoxColumn.HeaderText = "Barcode2";
            this.barcode2DataGridViewTextBoxColumn.Name = "barcode2DataGridViewTextBoxColumn";
            this.barcode2DataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // codeDataGridViewTextBoxColumn
            // 
            this.codeDataGridViewTextBoxColumn.DataPropertyName = "Code";
            this.codeDataGridViewTextBoxColumn.HeaderText = "Code";
            this.codeDataGridViewTextBoxColumn.Name = "codeDataGridViewTextBoxColumn";
            this.codeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nameArabicDataGridViewTextBoxColumn
            // 
            this.nameArabicDataGridViewTextBoxColumn.DataPropertyName = "NameArabic";
            this.nameArabicDataGridViewTextBoxColumn.HeaderText = "NameArabic";
            this.nameArabicDataGridViewTextBoxColumn.Name = "nameArabicDataGridViewTextBoxColumn";
            this.nameArabicDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nameEngDataGridViewTextBoxColumn
            // 
            this.nameEngDataGridViewTextBoxColumn.DataPropertyName = "NameEng";
            this.nameEngDataGridViewTextBoxColumn.HeaderText = "NameEng";
            this.nameEngDataGridViewTextBoxColumn.Name = "nameEngDataGridViewTextBoxColumn";
            this.nameEngDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // storeTypeDataGridViewTextBoxColumn
            // 
            this.storeTypeDataGridViewTextBoxColumn.DataPropertyName = "StoreType";
            this.storeTypeDataGridViewTextBoxColumn.HeaderText = "StoreType";
            this.storeTypeDataGridViewTextBoxColumn.Name = "storeTypeDataGridViewTextBoxColumn";
            this.storeTypeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // brandNameDataGridViewTextBoxColumn
            // 
            this.brandNameDataGridViewTextBoxColumn.DataPropertyName = "BrandName";
            this.brandNameDataGridViewTextBoxColumn.HeaderText = "BrandName";
            this.brandNameDataGridViewTextBoxColumn.Name = "brandNameDataGridViewTextBoxColumn";
            this.brandNameDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // categoryDataGridViewTextBoxColumn
            // 
            this.categoryDataGridViewTextBoxColumn.DataPropertyName = "Category";
            this.categoryDataGridViewTextBoxColumn.HeaderText = "Category";
            this.categoryDataGridViewTextBoxColumn.Name = "categoryDataGridViewTextBoxColumn";
            this.categoryDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // unitDataGridViewTextBoxColumn
            // 
            this.unitDataGridViewTextBoxColumn.DataPropertyName = "Unit";
            this.unitDataGridViewTextBoxColumn.HeaderText = "Unit";
            this.unitDataGridViewTextBoxColumn.Name = "unitDataGridViewTextBoxColumn";
            this.unitDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // colorDataGridViewTextBoxColumn
            // 
            this.colorDataGridViewTextBoxColumn.DataPropertyName = "Color";
            this.colorDataGridViewTextBoxColumn.HeaderText = "Color";
            this.colorDataGridViewTextBoxColumn.Name = "colorDataGridViewTextBoxColumn";
            this.colorDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // descriptionDataGridViewTextBoxColumn
            // 
            this.descriptionDataGridViewTextBoxColumn.DataPropertyName = "Description";
            this.descriptionDataGridViewTextBoxColumn.HeaderText = "Description";
            this.descriptionDataGridViewTextBoxColumn.Name = "descriptionDataGridViewTextBoxColumn";
            this.descriptionDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // qtyPerUnitDataGridViewTextBoxColumn
            // 
            this.qtyPerUnitDataGridViewTextBoxColumn.DataPropertyName = "QtyPerUnit";
            this.qtyPerUnitDataGridViewTextBoxColumn.HeaderText = "QtyPerUnit";
            this.qtyPerUnitDataGridViewTextBoxColumn.Name = "qtyPerUnitDataGridViewTextBoxColumn";
            this.qtyPerUnitDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // companyDataGridViewTextBoxColumn
            // 
            this.companyDataGridViewTextBoxColumn.DataPropertyName = "Company";
            this.companyDataGridViewTextBoxColumn.HeaderText = "Company";
            this.companyDataGridViewTextBoxColumn.Name = "companyDataGridViewTextBoxColumn";
            this.companyDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // venderDataGridViewTextBoxColumn
            // 
            this.venderDataGridViewTextBoxColumn.DataPropertyName = "Vender";
            this.venderDataGridViewTextBoxColumn.HeaderText = "Vender";
            this.venderDataGridViewTextBoxColumn.Name = "venderDataGridViewTextBoxColumn";
            this.venderDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // discountTypeDataGridViewTextBoxColumn
            // 
            this.discountTypeDataGridViewTextBoxColumn.DataPropertyName = "DiscountType";
            this.discountTypeDataGridViewTextBoxColumn.HeaderText = "DiscountType";
            this.discountTypeDataGridViewTextBoxColumn.Name = "discountTypeDataGridViewTextBoxColumn";
            this.discountTypeDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // directDiscountDataGridViewTextBoxColumn
            // 
            this.directDiscountDataGridViewTextBoxColumn.DataPropertyName = "DirectDiscount";
            this.directDiscountDataGridViewTextBoxColumn.HeaderText = "DirectDiscount";
            this.directDiscountDataGridViewTextBoxColumn.Name = "directDiscountDataGridViewTextBoxColumn";
            this.directDiscountDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nextShoppingDiscountDataGridViewTextBoxColumn
            // 
            this.nextShoppingDiscountDataGridViewTextBoxColumn.DataPropertyName = "NextShoppingDiscount";
            this.nextShoppingDiscountDataGridViewTextBoxColumn.HeaderText = "NextShoppingDiscount";
            this.nextShoppingDiscountDataGridViewTextBoxColumn.Name = "nextShoppingDiscountDataGridViewTextBoxColumn";
            this.nextShoppingDiscountDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // taxPercentDataGridViewTextBoxColumn
            // 
            this.taxPercentDataGridViewTextBoxColumn.DataPropertyName = "TaxPercent";
            this.taxPercentDataGridViewTextBoxColumn.HeaderText = "TaxPercent";
            this.taxPercentDataGridViewTextBoxColumn.Name = "taxPercentDataGridViewTextBoxColumn";
            this.taxPercentDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // reorderLevelDataGridViewTextBoxColumn
            // 
            this.reorderLevelDataGridViewTextBoxColumn.DataPropertyName = "ReorderLevel";
            this.reorderLevelDataGridViewTextBoxColumn.HeaderText = "ReorderLevel";
            this.reorderLevelDataGridViewTextBoxColumn.Name = "reorderLevelDataGridViewTextBoxColumn";
            this.reorderLevelDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // manufacturingDateDataGridViewTextBoxColumn
            // 
            this.manufacturingDateDataGridViewTextBoxColumn.DataPropertyName = "ManufacturingDate";
            this.manufacturingDateDataGridViewTextBoxColumn.HeaderText = "ManufacturingDate";
            this.manufacturingDateDataGridViewTextBoxColumn.Name = "manufacturingDateDataGridViewTextBoxColumn";
            this.manufacturingDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // expireDateDataGridViewTextBoxColumn
            // 
            this.expireDateDataGridViewTextBoxColumn.DataPropertyName = "ExpireDate";
            this.expireDateDataGridViewTextBoxColumn.HeaderText = "ExpireDate";
            this.expireDateDataGridViewTextBoxColumn.Name = "expireDateDataGridViewTextBoxColumn";
            this.expireDateDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // purchaseCurrencyDataGridViewTextBoxColumn
            // 
            this.purchaseCurrencyDataGridViewTextBoxColumn.DataPropertyName = "PurchaseCurrency";
            this.purchaseCurrencyDataGridViewTextBoxColumn.HeaderText = "PurchaseCurrency";
            this.purchaseCurrencyDataGridViewTextBoxColumn.Name = "purchaseCurrencyDataGridViewTextBoxColumn";
            this.purchaseCurrencyDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // sellingCurrencyDataGridViewTextBoxColumn
            // 
            this.sellingCurrencyDataGridViewTextBoxColumn.DataPropertyName = "SellingCurrency";
            this.sellingCurrencyDataGridViewTextBoxColumn.HeaderText = "SellingCurrency";
            this.sellingCurrencyDataGridViewTextBoxColumn.Name = "sellingCurrencyDataGridViewTextBoxColumn";
            this.sellingCurrencyDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // wholeSalePriceDataGridViewTextBoxColumn
            // 
            this.wholeSalePriceDataGridViewTextBoxColumn.DataPropertyName = "WholeSalePrice";
            this.wholeSalePriceDataGridViewTextBoxColumn.HeaderText = "WholeSalePrice";
            this.wholeSalePriceDataGridViewTextBoxColumn.Name = "wholeSalePriceDataGridViewTextBoxColumn";
            this.wholeSalePriceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // purchasePriceDataGridViewTextBoxColumn
            // 
            this.purchasePriceDataGridViewTextBoxColumn.DataPropertyName = "PurchasePrice";
            this.purchasePriceDataGridViewTextBoxColumn.HeaderText = "PurchasePrice";
            this.purchasePriceDataGridViewTextBoxColumn.Name = "purchasePriceDataGridViewTextBoxColumn";
            this.purchasePriceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // customPriceDataGridViewTextBoxColumn
            // 
            this.customPriceDataGridViewTextBoxColumn.DataPropertyName = "CustomPrice";
            this.customPriceDataGridViewTextBoxColumn.HeaderText = "CustomPrice";
            this.customPriceDataGridViewTextBoxColumn.Name = "customPriceDataGridViewTextBoxColumn";
            this.customPriceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // retailPriceDataGridViewTextBoxColumn
            // 
            this.retailPriceDataGridViewTextBoxColumn.DataPropertyName = "RetailPrice";
            this.retailPriceDataGridViewTextBoxColumn.HeaderText = "RetailPrice";
            this.retailPriceDataGridViewTextBoxColumn.Name = "retailPriceDataGridViewTextBoxColumn";
            this.retailPriceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // customerPriceDataGridViewTextBoxColumn
            // 
            this.customerPriceDataGridViewTextBoxColumn.DataPropertyName = "CustomerPrice";
            this.customerPriceDataGridViewTextBoxColumn.HeaderText = "CustomerPrice";
            this.customerPriceDataGridViewTextBoxColumn.Name = "customerPriceDataGridViewTextBoxColumn";
            this.customerPriceDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // addProfitDataGridViewTextBoxColumn
            // 
            this.addProfitDataGridViewTextBoxColumn.DataPropertyName = "AddProfit";
            this.addProfitDataGridViewTextBoxColumn.HeaderText = "AddProfit";
            this.addProfitDataGridViewTextBoxColumn.Name = "addProfitDataGridViewTextBoxColumn";
            this.addProfitDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // statusDataGridViewTextBoxColumn
            // 
            this.statusDataGridViewTextBoxColumn.DataPropertyName = "Status";
            this.statusDataGridViewTextBoxColumn.HeaderText = "Status";
            this.statusDataGridViewTextBoxColumn.Name = "statusDataGridViewTextBoxColumn";
            this.statusDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // tblItemMasterBindingSource
            // 
            this.tblItemMasterBindingSource.DataMember = "tblItemMaster";
            this.tblItemMasterBindingSource.DataSource = this.inventory_DBDataSet;
            // 
            // inventory_DBDataSet
            // 
            this.inventory_DBDataSet.DataSetName = "Inventory_DBDataSet";
            this.inventory_DBDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // btnfetch
            // 
            this.btnfetch.BackColor = System.Drawing.Color.Transparent;
            this.btnfetch.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnfetch.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnfetch.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnfetch.ForeColor = System.Drawing.Color.Black;
            this.btnfetch.Image = ((System.Drawing.Image)(resources.GetObject("btnfetch.Image")));
            this.btnfetch.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnfetch.Location = new System.Drawing.Point(429, 31);
            this.btnfetch.Name = "btnfetch";
            this.btnfetch.Size = new System.Drawing.Size(127, 35);
            this.btnfetch.TabIndex = 923;
            this.btnfetch.Text = "&Fetch Reord";
            this.btnfetch.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnfetch.UseVisualStyleBackColor = false;
            // 
            // btn_export
            // 
            this.btn_export.BackColor = System.Drawing.Color.White;
            this.btn_export.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_export.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_export.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_export.ForeColor = System.Drawing.Color.Black;
            this.btn_export.Image = ((System.Drawing.Image)(resources.GetObject("btn_export.Image")));
            this.btn_export.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_export.Location = new System.Drawing.Point(560, 31);
            this.btn_export.Name = "btn_export";
            this.btn_export.Size = new System.Drawing.Size(92, 35);
            this.btn_export.TabIndex = 922;
            this.btn_export.Text = "&Export";
            this.btn_export.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_export.UseVisualStyleBackColor = false;
            this.btn_export.Click += new System.EventHandler(this.btn_export_Click);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.Transparent;
            this.label38.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.Location = new System.Drawing.Point(245, 4);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(74, 20);
            this.label38.TabIndex = 830;
            this.label38.Text = "Select To:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.Transparent;
            this.label37.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.Location = new System.Drawing.Point(33, 4);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(94, 20);
            this.label37.TabIndex = 823;
            this.label37.Text = "Select From:";
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.Color.Transparent;
            this.panel35.Controls.Add(this.panel36);
            this.panel35.Controls.Add(this.label32);
            this.panel35.Controls.Add(this.pictureBox2);
            this.panel35.Controls.Add(this.panel47);
            this.panel35.Controls.Add(this.panel48);
            this.panel35.Controls.Add(this.panel49);
            this.panel35.Controls.Add(this.panel50);
            this.panel35.ForeColor = System.Drawing.Color.DarkGray;
            this.panel35.Location = new System.Drawing.Point(658, 15);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(317, 66);
            this.panel35.TabIndex = 829;
            // 
            // panel36
            // 
            this.panel36.BackColor = System.Drawing.Color.Gainsboro;
            this.panel36.Location = new System.Drawing.Point(252, 27);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(173, 10);
            this.panel36.TabIndex = 826;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.Transparent;
            this.label32.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.DimGray;
            this.label32.Location = new System.Drawing.Point(74, 21);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(172, 20);
            this.label32.TabIndex = 826;
            this.label32.Text = "From Sql Server to Excel";
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox2.BackgroundImage")));
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Location = new System.Drawing.Point(8, 4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(60, 58);
            this.pictureBox2.TabIndex = 427;
            this.pictureBox2.TabStop = false;
            // 
            // panel47
            // 
            this.panel47.BackColor = System.Drawing.Color.Gray;
            this.panel47.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel47.Location = new System.Drawing.Point(2, 0);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(313, 2);
            this.panel47.TabIndex = 426;
            // 
            // panel48
            // 
            this.panel48.BackColor = System.Drawing.Color.Gray;
            this.panel48.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel48.ForeColor = System.Drawing.Color.Gainsboro;
            this.panel48.Location = new System.Drawing.Point(2, 64);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(313, 2);
            this.panel48.TabIndex = 425;
            // 
            // panel49
            // 
            this.panel49.BackColor = System.Drawing.Color.Gray;
            this.panel49.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel49.Location = new System.Drawing.Point(315, 0);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(2, 66);
            this.panel49.TabIndex = 423;
            // 
            // panel50
            // 
            this.panel50.BackColor = System.Drawing.Color.Gray;
            this.panel50.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel50.Location = new System.Drawing.Point(0, 0);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(2, 66);
            this.panel50.TabIndex = 422;
            // 
            // panel51
            // 
            this.panel51.BackColor = System.Drawing.Color.Transparent;
            this.panel51.Controls.Add(this.panel52);
            this.panel51.Controls.Add(this.panel53);
            this.panel51.Controls.Add(this.panel54);
            this.panel51.Controls.Add(this.panel55);
            this.panel51.Controls.Add(this.panel56);
            this.panel51.ForeColor = System.Drawing.Color.DarkGray;
            this.panel51.Location = new System.Drawing.Point(6, 15);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(208, 66);
            this.panel51.TabIndex = 827;
            // 
            // panel52
            // 
            this.panel52.BackColor = System.Drawing.Color.Gainsboro;
            this.panel52.Controls.Add(this.dateTimePicker3);
            this.panel52.Location = new System.Drawing.Point(8, 17);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(193, 35);
            this.panel52.TabIndex = 542;
            // 
            // dateTimePicker3
            // 
            this.dateTimePicker3.CalendarFont = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker3.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker3.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker3.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker3.Location = new System.Drawing.Point(2, 2);
            this.dateTimePicker3.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker3.Name = "dateTimePicker3";
            this.dateTimePicker3.Size = new System.Drawing.Size(189, 31);
            this.dateTimePicker3.TabIndex = 313;
            // 
            // panel53
            // 
            this.panel53.BackColor = System.Drawing.Color.Gray;
            this.panel53.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel53.Location = new System.Drawing.Point(2, 0);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(204, 2);
            this.panel53.TabIndex = 426;
            // 
            // panel54
            // 
            this.panel54.BackColor = System.Drawing.Color.Gray;
            this.panel54.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel54.ForeColor = System.Drawing.Color.Gainsboro;
            this.panel54.Location = new System.Drawing.Point(2, 64);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(204, 2);
            this.panel54.TabIndex = 425;
            // 
            // panel55
            // 
            this.panel55.BackColor = System.Drawing.Color.Gray;
            this.panel55.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel55.Location = new System.Drawing.Point(206, 0);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(2, 66);
            this.panel55.TabIndex = 423;
            // 
            // panel56
            // 
            this.panel56.BackColor = System.Drawing.Color.Gray;
            this.panel56.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel56.Location = new System.Drawing.Point(0, 0);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(2, 66);
            this.panel56.TabIndex = 422;
            // 
            // panel57
            // 
            this.panel57.BackColor = System.Drawing.Color.Transparent;
            this.panel57.Controls.Add(this.panel62);
            this.panel57.Controls.Add(this.panel58);
            this.panel57.Controls.Add(this.panel59);
            this.panel57.Controls.Add(this.panel60);
            this.panel57.Controls.Add(this.panel61);
            this.panel57.ForeColor = System.Drawing.Color.DarkGray;
            this.panel57.Location = new System.Drawing.Point(217, 15);
            this.panel57.Name = "panel57";
            this.panel57.Size = new System.Drawing.Size(208, 66);
            this.panel57.TabIndex = 828;
            // 
            // panel62
            // 
            this.panel62.BackColor = System.Drawing.Color.Gainsboro;
            this.panel62.Controls.Add(this.dateTimePicker4);
            this.panel62.Location = new System.Drawing.Point(7, 16);
            this.panel62.Name = "panel62";
            this.panel62.Size = new System.Drawing.Size(193, 35);
            this.panel62.TabIndex = 543;
            // 
            // dateTimePicker4
            // 
            this.dateTimePicker4.CalendarFont = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker4.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker4.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker4.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker4.Location = new System.Drawing.Point(2, 2);
            this.dateTimePicker4.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker4.Name = "dateTimePicker4";
            this.dateTimePicker4.Size = new System.Drawing.Size(189, 31);
            this.dateTimePicker4.TabIndex = 314;
            // 
            // panel58
            // 
            this.panel58.BackColor = System.Drawing.Color.Gray;
            this.panel58.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel58.Location = new System.Drawing.Point(2, 0);
            this.panel58.Name = "panel58";
            this.panel58.Size = new System.Drawing.Size(204, 2);
            this.panel58.TabIndex = 426;
            // 
            // panel59
            // 
            this.panel59.BackColor = System.Drawing.Color.Gray;
            this.panel59.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel59.ForeColor = System.Drawing.Color.Gainsboro;
            this.panel59.Location = new System.Drawing.Point(2, 64);
            this.panel59.Name = "panel59";
            this.panel59.Size = new System.Drawing.Size(204, 2);
            this.panel59.TabIndex = 425;
            // 
            // panel60
            // 
            this.panel60.BackColor = System.Drawing.Color.Gray;
            this.panel60.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel60.Location = new System.Drawing.Point(206, 0);
            this.panel60.Name = "panel60";
            this.panel60.Size = new System.Drawing.Size(2, 66);
            this.panel60.TabIndex = 423;
            // 
            // panel61
            // 
            this.panel61.BackColor = System.Drawing.Color.Gray;
            this.panel61.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel61.Location = new System.Drawing.Point(0, 0);
            this.panel61.Name = "panel61";
            this.panel61.Size = new System.Drawing.Size(2, 66);
            this.panel61.TabIndex = 422;
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.u);
            this.tabPage1.Location = new System.Drawing.Point(4, 30);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(1090, 644);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Product Creation";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // u
            // 
            this.u.BackColor = System.Drawing.Color.LightCyan;
            this.u.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.u.Controls.Add(this.label9);
            this.u.Controls.Add(this.label13);
            this.u.Controls.Add(this.panel2);
            this.u.Controls.Add(this.panel17);
            this.u.Controls.Add(this.panel11);
            this.u.Controls.Add(this.panel14);
            this.u.Controls.Add(this.panel13);
            this.u.Controls.Add(this.panel44);
            this.u.Dock = System.Windows.Forms.DockStyle.Fill;
            this.u.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.u.Location = new System.Drawing.Point(3, 3);
            this.u.Name = "u";
            this.u.Size = new System.Drawing.Size(1084, 638);
            this.u.TabIndex = 472;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Transparent;
            this.label9.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(710, 3);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(114, 20);
            this.label9.TabIndex = 828;
            this.label9.Text = "Search Product:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.BackColor = System.Drawing.Color.Transparent;
            this.label13.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(25, 2);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(114, 20);
            this.label13.TabIndex = 825;
            this.label13.Text = "Product Details:";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Transparent;
            this.panel2.Controls.Add(this.btn_print);
            this.panel2.Controls.Add(this.combo_search_type);
            this.panel2.Controls.Add(this.txt_search);
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.panel12);
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel7);
            this.panel2.Controls.Add(this.lblUser);
            this.panel2.ForeColor = System.Drawing.Color.DarkGray;
            this.panel2.Location = new System.Drawing.Point(632, 12);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(446, 622);
            this.panel2.TabIndex = 827;
            // 
            // btn_print
            // 
            this.btn_print.BackColor = System.Drawing.Color.Blue;
            this.btn_print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_print.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_print.ForeColor = System.Drawing.Color.White;
            this.btn_print.Location = new System.Drawing.Point(294, 18);
            this.btn_print.Name = "btn_print";
            this.btn_print.Size = new System.Drawing.Size(63, 25);
            this.btn_print.TabIndex = 1022;
            this.btn_print.Text = "Search";
            this.btn_print.UseVisualStyleBackColor = false;
            // 
            // combo_search_type
            // 
            this.combo_search_type.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_search_type.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_search_type.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_search_type.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_search_type.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.combo_search_type.FormattingEnabled = true;
            this.combo_search_type.Items.AddRange(new object[] {
            "Barcode",
            "Name"});
            this.combo_search_type.Location = new System.Drawing.Point(8, 18);
            this.combo_search_type.Name = "combo_search_type";
            this.combo_search_type.Size = new System.Drawing.Size(142, 25);
            this.combo_search_type.TabIndex = 1021;
            this.combo_search_type.Text = "--- Select Field---";
            // 
            // txt_search
            // 
            this.txt_search.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_search.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_search.Location = new System.Drawing.Point(151, 18);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(142, 25);
            this.txt_search.TabIndex = 1020;
            this.txt_search.TextChanged += new System.EventHandler(this.txt_search_TextChanged);
            // 
            // dataGridView1
            // 
            dataGridViewCellStyle9.BackColor = System.Drawing.Color.OldLace;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle9;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(8, 47);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Trebuchet MS", 9.75F);
            dataGridViewCellStyle10.ForeColor = System.Drawing.Color.Black;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle10;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(430, 567);
            this.dataGridView1.TabIndex = 814;
            this.dataGridView1.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_CellMouseClick);
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gainsboro;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(2, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(442, 2);
            this.panel3.TabIndex = 426;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Gainsboro;
            this.panel12.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel12.ForeColor = System.Drawing.Color.Gainsboro;
            this.panel12.Location = new System.Drawing.Point(2, 620);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(442, 2);
            this.panel12.TabIndex = 425;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Gainsboro;
            this.panel6.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel6.Location = new System.Drawing.Point(444, 0);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(2, 622);
            this.panel6.TabIndex = 423;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Gainsboro;
            this.panel7.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel7.Location = new System.Drawing.Point(0, 0);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(2, 622);
            this.panel7.TabIndex = 422;
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(133, 169);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(49, 18);
            this.lblUser.TabIndex = 810;
            this.lblUser.Text = "Label8";
            this.lblUser.Visible = false;
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.Color.Transparent;
            this.panel17.Controls.Add(this.label18);
            this.panel17.Controls.Add(this.panel90);
            this.panel17.Controls.Add(this.btndel);
            this.panel17.Controls.Add(this.btnUpdate);
            this.panel17.Controls.Add(this.btn_save);
            this.panel17.Controls.Add(this.label23);
            this.panel17.Controls.Add(this.add9);
            this.panel17.Controls.Add(this.add8);
            this.panel17.Controls.Add(this.label36);
            this.panel17.Controls.Add(this.label34);
            this.panel17.Controls.Add(this.label39);
            this.panel17.Controls.Add(this.label31);
            this.panel17.Controls.Add(this.panel87);
            this.panel17.Controls.Add(this.panel88);
            this.panel17.Controls.Add(this.label35);
            this.panel17.Controls.Add(this.label33);
            this.panel17.Controls.Add(this.panel85);
            this.panel17.Controls.Add(this.panel83);
            this.panel17.Controls.Add(this.panel86);
            this.panel17.Controls.Add(this.panel84);
            this.panel17.Controls.Add(this.label29);
            this.panel17.Controls.Add(this.label27);
            this.panel17.Controls.Add(this.panel82);
            this.panel17.Controls.Add(this.panel81);
            this.panel17.Controls.Add(this.label25);
            this.panel17.Controls.Add(this.panel80);
            this.panel17.Controls.Add(this.panel79);
            this.panel17.Controls.Add(this.label26);
            this.panel17.Controls.Add(this.add6);
            this.panel17.Controls.Add(this.label20);
            this.panel17.Controls.Add(this.panel71);
            this.panel17.Controls.Add(this.panel67);
            this.panel17.Controls.Add(this.label16);
            this.panel17.Controls.Add(this.panel68);
            this.panel17.Controls.Add(this.panel66);
            this.panel17.Controls.Add(this.label14);
            this.panel17.Controls.Add(this.panel65);
            this.panel17.Controls.Add(this.label12);
            this.panel17.Controls.Add(this.panel30);
            this.panel17.Controls.Add(this.panel23);
            this.panel17.Controls.Add(this.label11);
            this.panel17.Controls.Add(this.panel25);
            this.panel17.Controls.Add(this.label6);
            this.panel17.Controls.Add(this.label8);
            this.panel17.Controls.Add(this.add5);
            this.panel17.Controls.Add(this.add4);
            this.panel17.Controls.Add(this.add3);
            this.panel17.Controls.Add(this.add2);
            this.panel17.Controls.Add(this.add1);
            this.panel17.Controls.Add(this.panel18);
            this.panel17.Controls.Add(this.panel8);
            this.panel17.Controls.Add(this.panel24);
            this.panel17.Controls.Add(this.panel31);
            this.panel17.Controls.Add(this.panel32);
            this.panel17.Controls.Add(this.panel33);
            this.panel17.Controls.Add(this.panel63);
            this.panel17.Controls.Add(this.panel64);
            this.panel17.Controls.Add(this.label10);
            this.panel17.Controls.Add(this.label1);
            this.panel17.Controls.Add(this.label30);
            this.panel17.Controls.Add(this.label7);
            this.panel17.Controls.Add(this.label5);
            this.panel17.Controls.Add(this.label2);
            this.panel17.Controls.Add(this.label3);
            this.panel17.Controls.Add(this.label4);
            this.panel17.Controls.Add(this.panel29);
            this.panel17.Controls.Add(this.panel28);
            this.panel17.Controls.Add(this.panel27);
            this.panel17.Controls.Add(this.panel26);
            this.panel17.Controls.Add(this.panel69);
            this.panel17.Controls.Add(this.panel89);
            this.panel17.ForeColor = System.Drawing.Color.DarkGray;
            this.panel17.Location = new System.Drawing.Point(8, 12);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(620, 622);
            this.panel17.TabIndex = 826;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label18.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label18.Location = new System.Drawing.Point(10, 354);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(103, 18);
            this.label18.TabIndex = 1121;
            this.label18.Text = "Mf/Expire Date:";
            // 
            // panel90
            // 
            this.panel90.BackColor = System.Drawing.Color.Gainsboro;
            this.panel90.Controls.Add(this.dateTimePicker2);
            this.panel90.Controls.Add(this.dateTimePicker1);
            this.panel90.Location = new System.Drawing.Point(128, 349);
            this.panel90.Name = "panel90";
            this.panel90.Size = new System.Drawing.Size(186, 29);
            this.panel90.TabIndex = 1090;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CalendarFont = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.CustomFormat = "";
            this.dateTimePicker2.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(94, 2);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(90, 25);
            this.dateTimePicker2.TabIndex = 1011;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.CustomFormat = "";
            this.dateTimePicker1.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(2, 2);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(90, 25);
            this.dateTimePicker1.TabIndex = 1010;
            // 
            // btndel
            // 
            this.btndel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btndel.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.btndel.ForeColor = System.Drawing.Color.Black;
            this.btndel.Image = ((System.Drawing.Image)(resources.GetObject("btndel.Image")));
            this.btndel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btndel.Location = new System.Drawing.Point(509, 580);
            this.btndel.Name = "btndel";
            this.btndel.Size = new System.Drawing.Size(81, 34);
            this.btndel.TabIndex = 870;
            this.btndel.Text = "&Delete";
            this.btndel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btndel.UseVisualStyleBackColor = true;
            this.btndel.Click += new System.EventHandler(this.btndel_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdate.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.btnUpdate.ForeColor = System.Drawing.Color.Black;
            this.btnUpdate.Image = ((System.Drawing.Image)(resources.GetObject("btnUpdate.Image")));
            this.btnUpdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUpdate.Location = new System.Drawing.Point(418, 580);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(90, 34);
            this.btnUpdate.TabIndex = 1120;
            this.btnUpdate.Text = "&Update";
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btn_save
            // 
            this.btn_save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_save.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.ForeColor = System.Drawing.Color.Black;
            this.btn_save.Image = ((System.Drawing.Image)(resources.GetObject("btn_save.Image")));
            this.btn_save.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_save.Location = new System.Drawing.Point(341, 580);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(76, 34);
            this.btn_save.TabIndex = 868;
            this.btn_save.Text = "&Save";
            this.btn_save.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_save.UseVisualStyleBackColor = true;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label23.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label23.Location = new System.Drawing.Point(11, 391);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(96, 18);
            this.label23.TabIndex = 1119;
            this.label23.Text = "Pur Currency:";
            // 
            // add9
            // 
            this.add9.BackColor = System.Drawing.Color.DimGray;
            this.add9.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.add9.Image = ((System.Drawing.Image)(resources.GetObject("add9.Image")));
            this.add9.ImageActive = null;
            this.add9.Location = new System.Drawing.Point(295, 431);
            this.add9.Name = "add9";
            this.add9.Size = new System.Drawing.Size(19, 18);
            this.add9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.add9.TabIndex = 1118;
            this.add9.TabStop = false;
            this.add9.Zoom = 10;
            this.add9.Click += new System.EventHandler(this.add9_Click);
            // 
            // add8
            // 
            this.add8.BackColor = System.Drawing.Color.DimGray;
            this.add8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.add8.Image = ((System.Drawing.Image)(resources.GetObject("add8.Image")));
            this.add8.ImageActive = null;
            this.add8.Location = new System.Drawing.Point(295, 393);
            this.add8.Name = "add8";
            this.add8.Size = new System.Drawing.Size(19, 18);
            this.add8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.add8.TabIndex = 1117;
            this.add8.TabStop = false;
            this.add8.Zoom = 10;
            this.add8.Click += new System.EventHandler(this.add8_Click);
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label36.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label36.Location = new System.Drawing.Point(321, 549);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(92, 18);
            this.label36.TabIndex = 1112;
            this.label36.Text = "Select Status:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label34.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label34.Location = new System.Drawing.Point(335, 509);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(65, 18);
            this.label34.TabIndex = 1108;
            this.label34.Text = "Location:";
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label39.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label39.Location = new System.Drawing.Point(5, 587);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(109, 18);
            this.label39.TabIndex = 1110;
            this.label39.Text = "Openning Stock:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label31.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label31.Location = new System.Drawing.Point(325, 470);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(84, 18);
            this.label31.TabIndex = 1104;
            this.label31.Text = "Retail Price:";
            // 
            // panel87
            // 
            this.panel87.BackColor = System.Drawing.Color.Gainsboro;
            this.panel87.Controls.Add(this.combo_Status);
            this.panel87.Location = new System.Drawing.Point(425, 543);
            this.panel87.Name = "panel87";
            this.panel87.Size = new System.Drawing.Size(186, 29);
            this.panel87.TabIndex = 1111;
            // 
            // combo_Status
            // 
            this.combo_Status.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_Status.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_Status.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_Status.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_Status.FormattingEnabled = true;
            this.combo_Status.Items.AddRange(new object[] {
            "Active",
            "Unactive"});
            this.combo_Status.Location = new System.Drawing.Point(2, 2);
            this.combo_Status.Name = "combo_Status";
            this.combo_Status.Size = new System.Drawing.Size(182, 25);
            this.combo_Status.TabIndex = 996;
            this.combo_Status.Text = "---Select Status---";
            // 
            // panel88
            // 
            this.panel88.BackColor = System.Drawing.Color.Gainsboro;
            this.panel88.Controls.Add(this.txt_OpenningStock);
            this.panel88.Location = new System.Drawing.Point(128, 582);
            this.panel88.Name = "panel88";
            this.panel88.Size = new System.Drawing.Size(186, 29);
            this.panel88.TabIndex = 1109;
            // 
            // txt_OpenningStock
            // 
            this.txt_OpenningStock.BackColor = System.Drawing.Color.White;
            this.txt_OpenningStock.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_OpenningStock.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_OpenningStock.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_OpenningStock.Location = new System.Drawing.Point(2, 2);
            this.txt_OpenningStock.Name = "txt_OpenningStock";
            this.txt_OpenningStock.Size = new System.Drawing.Size(182, 25);
            this.txt_OpenningStock.TabIndex = 995;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label35.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label35.Location = new System.Drawing.Point(14, 548);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(90, 18);
            this.label35.TabIndex = 1106;
            this.label35.Text = "Add Profit %:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label33.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label33.Location = new System.Drawing.Point(9, 505);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(107, 18);
            this.label33.TabIndex = 1102;
            this.label33.Text = "Customer Price:";
            // 
            // panel85
            // 
            this.panel85.BackColor = System.Drawing.Color.Gainsboro;
            this.panel85.Controls.Add(this.txt_Location);
            this.panel85.Location = new System.Drawing.Point(425, 503);
            this.panel85.Name = "panel85";
            this.panel85.Size = new System.Drawing.Size(186, 29);
            this.panel85.TabIndex = 1107;
            // 
            // txt_Location
            // 
            this.txt_Location.BackColor = System.Drawing.Color.White;
            this.txt_Location.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Location.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_Location.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_Location.Location = new System.Drawing.Point(2, 2);
            this.txt_Location.Name = "txt_Location";
            this.txt_Location.Size = new System.Drawing.Size(182, 25);
            this.txt_Location.TabIndex = 994;
            // 
            // panel83
            // 
            this.panel83.BackColor = System.Drawing.Color.Gainsboro;
            this.panel83.Controls.Add(this.txt_RetailPrice);
            this.panel83.Location = new System.Drawing.Point(425, 465);
            this.panel83.Name = "panel83";
            this.panel83.Size = new System.Drawing.Size(186, 29);
            this.panel83.TabIndex = 1103;
            // 
            // txt_RetailPrice
            // 
            this.txt_RetailPrice.BackColor = System.Drawing.Color.White;
            this.txt_RetailPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_RetailPrice.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_RetailPrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_RetailPrice.Location = new System.Drawing.Point(2, 2);
            this.txt_RetailPrice.Name = "txt_RetailPrice";
            this.txt_RetailPrice.Size = new System.Drawing.Size(182, 25);
            this.txt_RetailPrice.TabIndex = 992;
            // 
            // panel86
            // 
            this.panel86.BackColor = System.Drawing.Color.Gainsboro;
            this.panel86.Controls.Add(this.txt_AddProfit);
            this.panel86.Location = new System.Drawing.Point(128, 543);
            this.panel86.Name = "panel86";
            this.panel86.Size = new System.Drawing.Size(186, 29);
            this.panel86.TabIndex = 1105;
            // 
            // txt_AddProfit
            // 
            this.txt_AddProfit.BackColor = System.Drawing.Color.White;
            this.txt_AddProfit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_AddProfit.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_AddProfit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_AddProfit.Location = new System.Drawing.Point(2, 2);
            this.txt_AddProfit.Name = "txt_AddProfit";
            this.txt_AddProfit.Size = new System.Drawing.Size(182, 25);
            this.txt_AddProfit.TabIndex = 995;
            // 
            // panel84
            // 
            this.panel84.BackColor = System.Drawing.Color.Gainsboro;
            this.panel84.Controls.Add(this.txt_CustomerPrice);
            this.panel84.Location = new System.Drawing.Point(128, 500);
            this.panel84.Name = "panel84";
            this.panel84.Size = new System.Drawing.Size(186, 29);
            this.panel84.TabIndex = 1101;
            // 
            // txt_CustomerPrice
            // 
            this.txt_CustomerPrice.BackColor = System.Drawing.Color.White;
            this.txt_CustomerPrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_CustomerPrice.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_CustomerPrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_CustomerPrice.Location = new System.Drawing.Point(2, 2);
            this.txt_CustomerPrice.Name = "txt_CustomerPrice";
            this.txt_CustomerPrice.Size = new System.Drawing.Size(182, 25);
            this.txt_CustomerPrice.TabIndex = 987;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label29.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label29.Location = new System.Drawing.Point(316, 432);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(106, 18);
            this.label29.TabIndex = 1100;
            this.label29.Text = "Purchase Price:";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label27.Location = new System.Drawing.Point(7, 467);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(116, 18);
            this.label27.TabIndex = 1098;
            this.label27.Text = "Whole Sale Price:";
            // 
            // panel82
            // 
            this.panel82.BackColor = System.Drawing.Color.Gainsboro;
            this.panel82.Controls.Add(this.txt_PurchasePrice);
            this.panel82.Location = new System.Drawing.Point(425, 427);
            this.panel82.Name = "panel82";
            this.panel82.Size = new System.Drawing.Size(186, 29);
            this.panel82.TabIndex = 1099;
            // 
            // txt_PurchasePrice
            // 
            this.txt_PurchasePrice.BackColor = System.Drawing.Color.White;
            this.txt_PurchasePrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_PurchasePrice.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_PurchasePrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_PurchasePrice.Location = new System.Drawing.Point(2, 2);
            this.txt_PurchasePrice.Name = "txt_PurchasePrice";
            this.txt_PurchasePrice.Size = new System.Drawing.Size(182, 25);
            this.txt_PurchasePrice.TabIndex = 1012;
            // 
            // panel81
            // 
            this.panel81.BackColor = System.Drawing.Color.Gainsboro;
            this.panel81.Controls.Add(this.txt_WholeSalePrice);
            this.panel81.Location = new System.Drawing.Point(128, 462);
            this.panel81.Name = "panel81";
            this.panel81.Size = new System.Drawing.Size(186, 29);
            this.panel81.TabIndex = 1097;
            // 
            // txt_WholeSalePrice
            // 
            this.txt_WholeSalePrice.BackColor = System.Drawing.Color.White;
            this.txt_WholeSalePrice.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_WholeSalePrice.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_WholeSalePrice.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_WholeSalePrice.Location = new System.Drawing.Point(2, 2);
            this.txt_WholeSalePrice.Name = "txt_WholeSalePrice";
            this.txt_WholeSalePrice.Size = new System.Drawing.Size(182, 25);
            this.txt_WholeSalePrice.TabIndex = 1011;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label25.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label25.Location = new System.Drawing.Point(7, 429);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(115, 18);
            this.label25.TabIndex = 1096;
            this.label25.Text = "Selling Currency:";
            // 
            // panel80
            // 
            this.panel80.BackColor = System.Drawing.Color.Gainsboro;
            this.panel80.Controls.Add(this.combo_SellingCurrency);
            this.panel80.Location = new System.Drawing.Point(128, 424);
            this.panel80.Name = "panel80";
            this.panel80.Size = new System.Drawing.Size(164, 29);
            this.panel80.TabIndex = 1095;
            // 
            // combo_SellingCurrency
            // 
            this.combo_SellingCurrency.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_SellingCurrency.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_SellingCurrency.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_SellingCurrency.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_SellingCurrency.FormattingEnabled = true;
            this.combo_SellingCurrency.Location = new System.Drawing.Point(2, 2);
            this.combo_SellingCurrency.Name = "combo_SellingCurrency";
            this.combo_SellingCurrency.Size = new System.Drawing.Size(160, 25);
            this.combo_SellingCurrency.TabIndex = 1010;
            this.combo_SellingCurrency.Text = "---Select Currency---";
            // 
            // panel79
            // 
            this.panel79.BackColor = System.Drawing.Color.Gainsboro;
            this.panel79.Controls.Add(this.combo_PurchaseCurency);
            this.panel79.Location = new System.Drawing.Point(128, 386);
            this.panel79.Name = "panel79";
            this.panel79.Size = new System.Drawing.Size(164, 29);
            this.panel79.TabIndex = 1093;
            // 
            // combo_PurchaseCurency
            // 
            this.combo_PurchaseCurency.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_PurchaseCurency.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_PurchaseCurency.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_PurchaseCurency.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_PurchaseCurency.FormattingEnabled = true;
            this.combo_PurchaseCurency.Location = new System.Drawing.Point(2, 2);
            this.combo_PurchaseCurency.Name = "combo_PurchaseCurency";
            this.combo_PurchaseCurency.Size = new System.Drawing.Size(160, 25);
            this.combo_PurchaseCurency.TabIndex = 1009;
            this.combo_PurchaseCurency.Text = "---Select Currency---";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label26.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label26.Location = new System.Drawing.Point(10, 317);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(98, 18);
            this.label26.TabIndex = 1092;
            this.label26.Text = "Reorder Level:";
            // 
            // add6
            // 
            this.add6.BackColor = System.Drawing.Color.DimGray;
            this.add6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.add6.Image = ((System.Drawing.Image)(resources.GetObject("add6.Image")));
            this.add6.ImageActive = null;
            this.add6.Location = new System.Drawing.Point(295, 246);
            this.add6.Name = "add6";
            this.add6.Size = new System.Drawing.Size(19, 18);
            this.add6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.add6.TabIndex = 1091;
            this.add6.TabStop = false;
            this.add6.Zoom = 10;
            this.add6.Click += new System.EventHandler(this.add6_Click);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.BackColor = System.Drawing.Color.Transparent;
            this.label20.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label20.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label20.Location = new System.Drawing.Point(17, 280);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(84, 18);
            this.label20.TabIndex = 1090;
            this.label20.Text = "Tax Amount:";
            // 
            // panel71
            // 
            this.panel71.BackColor = System.Drawing.Color.Gainsboro;
            this.panel71.Controls.Add(this.txt_ReorderLevel);
            this.panel71.Location = new System.Drawing.Point(128, 313);
            this.panel71.Name = "panel71";
            this.panel71.Size = new System.Drawing.Size(186, 29);
            this.panel71.TabIndex = 1089;
            // 
            // txt_ReorderLevel
            // 
            this.txt_ReorderLevel.BackColor = System.Drawing.Color.White;
            this.txt_ReorderLevel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ReorderLevel.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_ReorderLevel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_ReorderLevel.Location = new System.Drawing.Point(2, 2);
            this.txt_ReorderLevel.Name = "txt_ReorderLevel";
            this.txt_ReorderLevel.Size = new System.Drawing.Size(182, 25);
            this.txt_ReorderLevel.TabIndex = 1009;
            // 
            // panel67
            // 
            this.panel67.BackColor = System.Drawing.Color.Gainsboro;
            this.panel67.Controls.Add(this.txt_TaxAmount);
            this.panel67.Location = new System.Drawing.Point(128, 275);
            this.panel67.Name = "panel67";
            this.panel67.Size = new System.Drawing.Size(186, 29);
            this.panel67.TabIndex = 1086;
            // 
            // txt_TaxAmount
            // 
            this.txt_TaxAmount.BackColor = System.Drawing.Color.White;
            this.txt_TaxAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_TaxAmount.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_TaxAmount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_TaxAmount.Location = new System.Drawing.Point(2, 2);
            this.txt_TaxAmount.Name = "txt_TaxAmount";
            this.txt_TaxAmount.Size = new System.Drawing.Size(182, 25);
            this.txt_TaxAmount.TabIndex = 1008;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.Transparent;
            this.label16.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label16.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label16.Location = new System.Drawing.Point(4, 244);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(124, 18);
            this.label16.TabIndex = 1085;
            this.label16.Text = "Tax Percantage % :";
            // 
            // panel68
            // 
            this.panel68.BackColor = System.Drawing.Color.Gainsboro;
            this.panel68.Controls.Add(this.combo_TaxType);
            this.panel68.Location = new System.Drawing.Point(128, 239);
            this.panel68.Name = "panel68";
            this.panel68.Size = new System.Drawing.Size(164, 29);
            this.panel68.TabIndex = 1084;
            // 
            // combo_TaxType
            // 
            this.combo_TaxType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_TaxType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_TaxType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_TaxType.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_TaxType.FormattingEnabled = true;
            this.combo_TaxType.Location = new System.Drawing.Point(2, 2);
            this.combo_TaxType.Name = "combo_TaxType";
            this.combo_TaxType.Size = new System.Drawing.Size(160, 25);
            this.combo_TaxType.TabIndex = 1009;
            this.combo_TaxType.Text = "---Select Tax Type---";
            // 
            // panel66
            // 
            this.panel66.BackColor = System.Drawing.Color.Gainsboro;
            this.panel66.Controls.Add(this.txt_CompanyProduct);
            this.panel66.Location = new System.Drawing.Point(425, 239);
            this.panel66.Name = "panel66";
            this.panel66.Size = new System.Drawing.Size(186, 29);
            this.panel66.TabIndex = 1074;
            // 
            // txt_CompanyProduct
            // 
            this.txt_CompanyProduct.BackColor = System.Drawing.Color.White;
            this.txt_CompanyProduct.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_CompanyProduct.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_CompanyProduct.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_CompanyProduct.Location = new System.Drawing.Point(2, 2);
            this.txt_CompanyProduct.Name = "txt_CompanyProduct";
            this.txt_CompanyProduct.Size = new System.Drawing.Size(182, 25);
            this.txt_CompanyProduct.TabIndex = 986;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.BackColor = System.Drawing.Color.Transparent;
            this.label14.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label14.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label14.Location = new System.Drawing.Point(325, 245);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(89, 18);
            this.label14.TabIndex = 1073;
            this.label14.Text = "Company Pro";
            // 
            // panel65
            // 
            this.panel65.BackColor = System.Drawing.Color.Gainsboro;
            this.panel65.Controls.Add(this.txt_QtyPerUnit);
            this.panel65.Location = new System.Drawing.Point(425, 201);
            this.panel65.Name = "panel65";
            this.panel65.Size = new System.Drawing.Size(186, 29);
            this.panel65.TabIndex = 1072;
            // 
            // txt_QtyPerUnit
            // 
            this.txt_QtyPerUnit.BackColor = System.Drawing.Color.White;
            this.txt_QtyPerUnit.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_QtyPerUnit.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_QtyPerUnit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_QtyPerUnit.Location = new System.Drawing.Point(2, 2);
            this.txt_QtyPerUnit.Name = "txt_QtyPerUnit";
            this.txt_QtyPerUnit.Size = new System.Drawing.Size(182, 25);
            this.txt_QtyPerUnit.TabIndex = 1010;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label12.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label12.Location = new System.Drawing.Point(325, 207);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(88, 18);
            this.label12.TabIndex = 1071;
            this.label12.Text = "Qty Per Unit:";
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.Color.Gainsboro;
            this.panel30.Controls.Add(this.txt_Description);
            this.panel30.Location = new System.Drawing.Point(128, 201);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(186, 29);
            this.panel30.TabIndex = 1055;
            // 
            // txt_Description
            // 
            this.txt_Description.BackColor = System.Drawing.Color.White;
            this.txt_Description.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_Description.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_Description.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_Description.Location = new System.Drawing.Point(2, 2);
            this.txt_Description.Multiline = true;
            this.txt_Description.Name = "txt_Description";
            this.txt_Description.Size = new System.Drawing.Size(182, 25);
            this.txt_Description.TabIndex = 980;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.Color.Gainsboro;
            this.panel23.Controls.Add(this.txt_ProductnameEng);
            this.panel23.Location = new System.Drawing.Point(425, 163);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(186, 29);
            this.panel23.TabIndex = 1051;
            // 
            // txt_ProductnameEng
            // 
            this.txt_ProductnameEng.BackColor = System.Drawing.Color.White;
            this.txt_ProductnameEng.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ProductnameEng.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_ProductnameEng.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_ProductnameEng.Location = new System.Drawing.Point(2, 2);
            this.txt_ProductnameEng.Name = "txt_ProductnameEng";
            this.txt_ProductnameEng.Size = new System.Drawing.Size(182, 25);
            this.txt_ProductnameEng.TabIndex = 1009;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Transparent;
            this.label11.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label11.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label11.Location = new System.Drawing.Point(20, 203);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(83, 18);
            this.label11.TabIndex = 1053;
            this.label11.Text = "Description:";
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.Gainsboro;
            this.panel25.Controls.Add(this.txt_ProductnameArabic);
            this.panel25.Location = new System.Drawing.Point(128, 163);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(186, 29);
            this.panel25.TabIndex = 1050;
            // 
            // txt_ProductnameArabic
            // 
            this.txt_ProductnameArabic.BackColor = System.Drawing.Color.White;
            this.txt_ProductnameArabic.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_ProductnameArabic.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_ProductnameArabic.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_ProductnameArabic.Location = new System.Drawing.Point(2, 2);
            this.txt_ProductnameArabic.Multiline = true;
            this.txt_ProductnameArabic.Name = "txt_ProductnameArabic";
            this.txt_ProductnameArabic.Size = new System.Drawing.Size(182, 25);
            this.txt_ProductnameArabic.TabIndex = 1008;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label6.Location = new System.Drawing.Point(323, 168);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(93, 18);
            this.label6.TabIndex = 1049;
            this.label6.Text = "Pro Name Eng";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label8.Location = new System.Drawing.Point(4, 168);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(115, 18);
            this.label8.TabIndex = 1048;
            this.label8.Text = "Pro Name Arabic:";
            // 
            // add5
            // 
            this.add5.BackColor = System.Drawing.Color.DimGray;
            this.add5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.add5.Image = ((System.Drawing.Image)(resources.GetObject("add5.Image")));
            this.add5.ImageActive = null;
            this.add5.Location = new System.Drawing.Point(592, 132);
            this.add5.Name = "add5";
            this.add5.Size = new System.Drawing.Size(19, 18);
            this.add5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.add5.TabIndex = 1047;
            this.add5.TabStop = false;
            this.add5.Zoom = 10;
            this.add5.Click += new System.EventHandler(this.add5_Click);
            // 
            // add4
            // 
            this.add4.BackColor = System.Drawing.Color.DimGray;
            this.add4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.add4.Image = ((System.Drawing.Image)(resources.GetObject("add4.Image")));
            this.add4.ImageActive = null;
            this.add4.Location = new System.Drawing.Point(295, 132);
            this.add4.Name = "add4";
            this.add4.Size = new System.Drawing.Size(19, 18);
            this.add4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.add4.TabIndex = 1046;
            this.add4.TabStop = false;
            this.add4.Zoom = 10;
            this.add4.Click += new System.EventHandler(this.add4_Click);
            // 
            // add3
            // 
            this.add3.BackColor = System.Drawing.Color.DimGray;
            this.add3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.add3.Image = ((System.Drawing.Image)(resources.GetObject("add3.Image")));
            this.add3.ImageActive = null;
            this.add3.Location = new System.Drawing.Point(592, 96);
            this.add3.Name = "add3";
            this.add3.Size = new System.Drawing.Size(19, 18);
            this.add3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.add3.TabIndex = 1045;
            this.add3.TabStop = false;
            this.add3.Zoom = 10;
            this.add3.Click += new System.EventHandler(this.add3_Click);
            // 
            // add2
            // 
            this.add2.BackColor = System.Drawing.Color.DimGray;
            this.add2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.add2.Image = ((System.Drawing.Image)(resources.GetObject("add2.Image")));
            this.add2.ImageActive = null;
            this.add2.Location = new System.Drawing.Point(295, 96);
            this.add2.Name = "add2";
            this.add2.Size = new System.Drawing.Size(19, 18);
            this.add2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.add2.TabIndex = 1044;
            this.add2.TabStop = false;
            this.add2.Zoom = 10;
            this.add2.Click += new System.EventHandler(this.add2_Click);
            // 
            // add1
            // 
            this.add1.BackColor = System.Drawing.Color.DimGray;
            this.add1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.add1.Image = ((System.Drawing.Image)(resources.GetObject("add1.Image")));
            this.add1.ImageActive = null;
            this.add1.Location = new System.Drawing.Point(592, 59);
            this.add1.Name = "add1";
            this.add1.Size = new System.Drawing.Size(19, 18);
            this.add1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.add1.TabIndex = 1043;
            this.add1.TabStop = false;
            this.add1.Zoom = 10;
            this.add1.Click += new System.EventHandler(this.add1_Click);
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.Color.Gainsboro;
            this.panel18.Controls.Add(this.combo_Unit);
            this.panel18.Location = new System.Drawing.Point(425, 126);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(164, 29);
            this.panel18.TabIndex = 1039;
            // 
            // combo_Unit
            // 
            this.combo_Unit.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_Unit.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_Unit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_Unit.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_Unit.FormattingEnabled = true;
            this.combo_Unit.Location = new System.Drawing.Point(2, 2);
            this.combo_Unit.Name = "combo_Unit";
            this.combo_Unit.Size = new System.Drawing.Size(160, 25);
            this.combo_Unit.TabIndex = 3;
            this.combo_Unit.Text = "--- Select Unit---";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Gainsboro;
            this.panel8.Controls.Add(this.combo_Color);
            this.panel8.Location = new System.Drawing.Point(128, 126);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(164, 29);
            this.panel8.TabIndex = 1038;
            // 
            // combo_Color
            // 
            this.combo_Color.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_Color.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_Color.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_Color.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_Color.FormattingEnabled = true;
            this.combo_Color.Location = new System.Drawing.Point(2, 2);
            this.combo_Color.Name = "combo_Color";
            this.combo_Color.Size = new System.Drawing.Size(160, 25);
            this.combo_Color.TabIndex = 3;
            this.combo_Color.Text = "--- Select Color---";
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.Color.Gainsboro;
            this.panel24.Controls.Add(this.combo_Brand);
            this.panel24.Location = new System.Drawing.Point(425, 89);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(164, 29);
            this.panel24.TabIndex = 1037;
            // 
            // combo_Brand
            // 
            this.combo_Brand.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_Brand.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_Brand.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_Brand.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_Brand.FormattingEnabled = true;
            this.combo_Brand.Location = new System.Drawing.Point(2, 2);
            this.combo_Brand.Name = "combo_Brand";
            this.combo_Brand.Size = new System.Drawing.Size(160, 25);
            this.combo_Brand.TabIndex = 3;
            this.combo_Brand.Text = "--- Select Brand---";
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.Color.Gainsboro;
            this.panel31.Controls.Add(this.combo_Category);
            this.panel31.Location = new System.Drawing.Point(128, 89);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(164, 29);
            this.panel31.TabIndex = 1035;
            // 
            // combo_Category
            // 
            this.combo_Category.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_Category.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_Category.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_Category.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_Category.FormattingEnabled = true;
            this.combo_Category.Location = new System.Drawing.Point(2, 2);
            this.combo_Category.Name = "combo_Category";
            this.combo_Category.Size = new System.Drawing.Size(160, 25);
            this.combo_Category.TabIndex = 3;
            this.combo_Category.Text = "--- Select Categories---";
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.Gainsboro;
            this.panel32.Controls.Add(this.combo_Store);
            this.panel32.Location = new System.Drawing.Point(425, 52);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(164, 29);
            this.panel32.TabIndex = 1034;
            // 
            // combo_Store
            // 
            this.combo_Store.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_Store.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_Store.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_Store.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_Store.FormattingEnabled = true;
            this.combo_Store.Location = new System.Drawing.Point(2, 2);
            this.combo_Store.Name = "combo_Store";
            this.combo_Store.Size = new System.Drawing.Size(160, 25);
            this.combo_Store.TabIndex = 2;
            this.combo_Store.Text = "--- Select Store---";
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.Color.Gainsboro;
            this.panel33.Controls.Add(this.txt_Productcode);
            this.panel33.Location = new System.Drawing.Point(128, 52);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(186, 29);
            this.panel33.TabIndex = 1033;
            // 
            // txt_Productcode
            // 
            this.txt_Productcode.BackColor = System.Drawing.Color.White;
            this.txt_Productcode.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_Productcode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_Productcode.Location = new System.Drawing.Point(2, 2);
            this.txt_Productcode.Name = "txt_Productcode";
            this.txt_Productcode.Size = new System.Drawing.Size(182, 25);
            this.txt_Productcode.TabIndex = 0;
            // 
            // panel63
            // 
            this.panel63.BackColor = System.Drawing.Color.Gainsboro;
            this.panel63.Controls.Add(this.txt_Barcode2);
            this.panel63.Location = new System.Drawing.Point(425, 16);
            this.panel63.Name = "panel63";
            this.panel63.Size = new System.Drawing.Size(186, 29);
            this.panel63.TabIndex = 1032;
            // 
            // txt_Barcode2
            // 
            this.txt_Barcode2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.txt_Barcode2.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_Barcode2.ForeColor = System.Drawing.Color.Black;
            this.txt_Barcode2.Location = new System.Drawing.Point(2, 2);
            this.txt_Barcode2.Name = "txt_Barcode2";
            this.txt_Barcode2.Size = new System.Drawing.Size(182, 25);
            this.txt_Barcode2.TabIndex = 3;
            // 
            // panel64
            // 
            this.panel64.BackColor = System.Drawing.Color.Gainsboro;
            this.panel64.Controls.Add(this.txt_Barcode1);
            this.panel64.Location = new System.Drawing.Point(128, 16);
            this.panel64.Name = "panel64";
            this.panel64.Size = new System.Drawing.Size(186, 29);
            this.panel64.TabIndex = 1031;
            // 
            // txt_Barcode1
            // 
            this.txt_Barcode1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.txt_Barcode1.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_Barcode1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_Barcode1.Location = new System.Drawing.Point(2, 2);
            this.txt_Barcode1.Name = "txt_Barcode1";
            this.txt_Barcode1.Size = new System.Drawing.Size(182, 25);
            this.txt_Barcode1.TabIndex = 2;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.BackColor = System.Drawing.Color.Transparent;
            this.label10.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label10.Location = new System.Drawing.Point(326, 57);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(86, 18);
            this.label10.TabIndex = 1030;
            this.label10.Text = "Select Store:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label1.Location = new System.Drawing.Point(325, 131);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(88, 18);
            this.label1.TabIndex = 1028;
            this.label1.Text = "Type of Unit:";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Transparent;
            this.label30.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label30.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label30.Location = new System.Drawing.Point(18, 131);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(86, 18);
            this.label30.TabIndex = 1027;
            this.label30.Text = "Select Color:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label7.Location = new System.Drawing.Point(324, 95);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(91, 18);
            this.label7.TabIndex = 1026;
            this.label7.Text = "Select Brand:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label5.Location = new System.Drawing.Point(7, 94);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(108, 18);
            this.label5.TabIndex = 1025;
            this.label5.Text = "Select Category:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label2.Location = new System.Drawing.Point(13, 57);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(96, 18);
            this.label2.TabIndex = 1024;
            this.label2.Text = "Product Code:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label3.Location = new System.Drawing.Point(322, 21);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 18);
            this.label3.TabIndex = 1023;
            this.label3.Text = "Barcode No 2:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label4.Location = new System.Drawing.Point(14, 21);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 18);
            this.label4.TabIndex = 1022;
            this.label4.Text = "Barcode No 1:";
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.Color.Gainsboro;
            this.panel29.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel29.Location = new System.Drawing.Point(2, 0);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(616, 2);
            this.panel29.TabIndex = 426;
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.Gainsboro;
            this.panel28.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel28.ForeColor = System.Drawing.Color.Gainsboro;
            this.panel28.Location = new System.Drawing.Point(2, 620);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(616, 2);
            this.panel28.TabIndex = 425;
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.Color.Gainsboro;
            this.panel27.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel27.Location = new System.Drawing.Point(618, 0);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(2, 622);
            this.panel27.TabIndex = 423;
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.Gainsboro;
            this.panel26.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel26.Location = new System.Drawing.Point(0, 0);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(2, 622);
            this.panel26.TabIndex = 422;
            // 
            // panel69
            // 
            this.panel69.BackColor = System.Drawing.Color.Transparent;
            this.panel69.Controls.Add(this.panel91);
            this.panel69.Controls.Add(this.label22);
            this.panel69.Controls.Add(this.panel78);
            this.panel69.Controls.Add(this.label21);
            this.panel69.Controls.Add(this.panel77);
            this.panel69.Controls.Add(this.label17);
            this.panel69.Controls.Add(this.panel70);
            this.panel69.Controls.Add(this.add7);
            this.panel69.Controls.Add(this.label19);
            this.panel69.Controls.Add(this.panel72);
            this.panel69.Controls.Add(this.panel73);
            this.panel69.Controls.Add(this.panel74);
            this.panel69.Controls.Add(this.panel75);
            this.panel69.Controls.Add(this.panel76);
            this.panel69.Location = new System.Drawing.Point(320, 252);
            this.panel69.Name = "panel69";
            this.panel69.Size = new System.Drawing.Size(295, 170);
            this.panel69.TabIndex = 1088;
            // 
            // panel91
            // 
            this.panel91.BackColor = System.Drawing.Color.Gainsboro;
            this.panel91.Controls.Add(this.txt_PreferredVender);
            this.panel91.Location = new System.Drawing.Point(105, 134);
            this.panel91.Name = "panel91";
            this.panel91.Size = new System.Drawing.Size(186, 29);
            this.panel91.TabIndex = 1092;
            // 
            // txt_PreferredVender
            // 
            this.txt_PreferredVender.BackColor = System.Drawing.Color.White;
            this.txt_PreferredVender.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_PreferredVender.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_PreferredVender.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_PreferredVender.Location = new System.Drawing.Point(2, 2);
            this.txt_PreferredVender.Name = "txt_PreferredVender";
            this.txt_PreferredVender.Size = new System.Drawing.Size(182, 25);
            this.txt_PreferredVender.TabIndex = 1009;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label22.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label22.Location = new System.Drawing.Point(4, 139);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(99, 18);
            this.label22.TabIndex = 1093;
            this.label22.Text = "Preferred Ven:";
            // 
            // panel78
            // 
            this.panel78.BackColor = System.Drawing.Color.Gainsboro;
            this.panel78.Controls.Add(this.txt_NextShoppingDiscount);
            this.panel78.Location = new System.Drawing.Point(199, 97);
            this.panel78.Name = "panel78";
            this.panel78.Size = new System.Drawing.Size(92, 29);
            this.panel78.TabIndex = 1091;
            // 
            // txt_NextShoppingDiscount
            // 
            this.txt_NextShoppingDiscount.BackColor = System.Drawing.Color.White;
            this.txt_NextShoppingDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_NextShoppingDiscount.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_NextShoppingDiscount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_NextShoppingDiscount.Location = new System.Drawing.Point(2, 2);
            this.txt_NextShoppingDiscount.Name = "txt_NextShoppingDiscount";
            this.txt_NextShoppingDiscount.Size = new System.Drawing.Size(88, 25);
            this.txt_NextShoppingDiscount.TabIndex = 1009;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label21.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label21.Location = new System.Drawing.Point(6, 88);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(98, 36);
            this.label21.TabIndex = 1090;
            this.label21.Text = "Direct | \r\nNext Discount:";
            // 
            // panel77
            // 
            this.panel77.BackColor = System.Drawing.Color.Gainsboro;
            this.panel77.Controls.Add(this.txt_DirectDiscount);
            this.panel77.Location = new System.Drawing.Point(105, 97);
            this.panel77.Name = "panel77";
            this.panel77.Size = new System.Drawing.Size(92, 29);
            this.panel77.TabIndex = 1089;
            // 
            // txt_DirectDiscount
            // 
            this.txt_DirectDiscount.BackColor = System.Drawing.Color.White;
            this.txt_DirectDiscount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_DirectDiscount.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_DirectDiscount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_DirectDiscount.Location = new System.Drawing.Point(2, 2);
            this.txt_DirectDiscount.Name = "txt_DirectDiscount";
            this.txt_DirectDiscount.Size = new System.Drawing.Size(88, 25);
            this.txt_DirectDiscount.TabIndex = 995;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.BackColor = System.Drawing.Color.Transparent;
            this.label17.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label17.Location = new System.Drawing.Point(5, 64);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(81, 18);
            this.label17.TabIndex = 1088;
            this.label17.Text = "Dis Amount:";
            // 
            // panel70
            // 
            this.panel70.BackColor = System.Drawing.Color.Gainsboro;
            this.panel70.Controls.Add(this.txt_DiscountAmount);
            this.panel70.Location = new System.Drawing.Point(105, 59);
            this.panel70.Name = "panel70";
            this.panel70.Size = new System.Drawing.Size(186, 29);
            this.panel70.TabIndex = 1087;
            // 
            // txt_DiscountAmount
            // 
            this.txt_DiscountAmount.BackColor = System.Drawing.Color.White;
            this.txt_DiscountAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_DiscountAmount.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_DiscountAmount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_DiscountAmount.Location = new System.Drawing.Point(2, 2);
            this.txt_DiscountAmount.Name = "txt_DiscountAmount";
            this.txt_DiscountAmount.Size = new System.Drawing.Size(182, 25);
            this.txt_DiscountAmount.TabIndex = 994;
            // 
            // add7
            // 
            this.add7.BackColor = System.Drawing.Color.DimGray;
            this.add7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.add7.Image = ((System.Drawing.Image)(resources.GetObject("add7.Image")));
            this.add7.ImageActive = null;
            this.add7.Location = new System.Drawing.Point(271, 29);
            this.add7.Name = "add7";
            this.add7.Size = new System.Drawing.Size(19, 18);
            this.add7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.add7.TabIndex = 1067;
            this.add7.TabStop = false;
            this.add7.Zoom = 10;
            this.add7.Click += new System.EventHandler(this.add7_Click);
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.BackColor = System.Drawing.Color.Transparent;
            this.label19.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label19.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label19.Location = new System.Drawing.Point(4, 28);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(99, 18);
            this.label19.TabIndex = 1063;
            this.label19.Text = "Discount Type:";
            // 
            // panel72
            // 
            this.panel72.BackColor = System.Drawing.Color.Gainsboro;
            this.panel72.Controls.Add(this.combo_DiscountType);
            this.panel72.Location = new System.Drawing.Point(105, 23);
            this.panel72.Name = "panel72";
            this.panel72.Size = new System.Drawing.Size(164, 29);
            this.panel72.TabIndex = 960;
            // 
            // combo_DiscountType
            // 
            this.combo_DiscountType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_DiscountType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_DiscountType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_DiscountType.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_DiscountType.FormattingEnabled = true;
            this.combo_DiscountType.Location = new System.Drawing.Point(2, 2);
            this.combo_DiscountType.Name = "combo_DiscountType";
            this.combo_DiscountType.Size = new System.Drawing.Size(160, 25);
            this.combo_DiscountType.TabIndex = 993;
            this.combo_DiscountType.Text = "-Select Discount Type-";
            // 
            // panel73
            // 
            this.panel73.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel73.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel73.Location = new System.Drawing.Point(2, 0);
            this.panel73.Name = "panel73";
            this.panel73.Size = new System.Drawing.Size(291, 2);
            this.panel73.TabIndex = 426;
            // 
            // panel74
            // 
            this.panel74.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel74.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel74.Location = new System.Drawing.Point(2, 168);
            this.panel74.Name = "panel74";
            this.panel74.Size = new System.Drawing.Size(291, 2);
            this.panel74.TabIndex = 425;
            // 
            // panel75
            // 
            this.panel75.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel75.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel75.Location = new System.Drawing.Point(293, 0);
            this.panel75.Name = "panel75";
            this.panel75.Size = new System.Drawing.Size(2, 170);
            this.panel75.TabIndex = 423;
            // 
            // panel76
            // 
            this.panel76.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel76.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel76.Location = new System.Drawing.Point(0, 0);
            this.panel76.Name = "panel76";
            this.panel76.Size = new System.Drawing.Size(2, 170);
            this.panel76.TabIndex = 422;
            // 
            // panel89
            // 
            this.panel89.BackColor = System.Drawing.Color.Transparent;
            this.panel89.Controls.Add(this.panel95);
            this.panel89.Location = new System.Drawing.Point(317, 580);
            this.panel89.Name = "panel89";
            this.panel89.Size = new System.Drawing.Size(295, 22);
            this.panel89.TabIndex = 1094;
            // 
            // panel95
            // 
            this.panel95.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.panel95.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel95.Location = new System.Drawing.Point(0, 20);
            this.panel95.Name = "panel95";
            this.panel95.Size = new System.Drawing.Size(295, 2);
            this.panel95.TabIndex = 425;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel11.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel11.Location = new System.Drawing.Point(2, 0);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(1080, 2);
            this.panel11.TabIndex = 368;
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel14.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel14.Location = new System.Drawing.Point(0, 0);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(2, 636);
            this.panel14.TabIndex = 336;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel13.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel13.Location = new System.Drawing.Point(0, 636);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(1082, 2);
            this.panel13.TabIndex = 335;
            // 
            // panel44
            // 
            this.panel44.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.panel44.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel44.Location = new System.Drawing.Point(1082, 0);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(2, 638);
            this.panel44.TabIndex = 334;
            // 
            // tabControl1
            // 
            this.tabControl1.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Font = new System.Drawing.Font("Trebuchet MS", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tabControl1.Location = new System.Drawing.Point(2, 31);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(1098, 678);
            this.tabControl1.TabIndex = 299;
            // 
            // tblItemMasterTableAdapter
            // 
            this.tblItemMasterTableAdapter.ClearBeforeFill = true;
            // 
            // ProductMaster
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1102, 711);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Name = "ProductMaster";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "ProductMaster";
            this.Activated += new System.EventHandler(this.ProductMaster_Activated);
            this.Load += new System.EventHandler(this.ProductMaster_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.ProductMaster_KeyDown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.close)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvExcelData)).EndInit();
            this.panel9.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgw)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblItemMasterBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.inventory_DBDataSet)).EndInit();
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel51.ResumeLayout(false);
            this.panel52.ResumeLayout(false);
            this.panel57.ResumeLayout(false);
            this.panel62.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.u.ResumeLayout(false);
            this.u.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel90.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.add9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.add8)).EndInit();
            this.panel87.ResumeLayout(false);
            this.panel88.ResumeLayout(false);
            this.panel88.PerformLayout();
            this.panel85.ResumeLayout(false);
            this.panel85.PerformLayout();
            this.panel83.ResumeLayout(false);
            this.panel83.PerformLayout();
            this.panel86.ResumeLayout(false);
            this.panel86.PerformLayout();
            this.panel84.ResumeLayout(false);
            this.panel84.PerformLayout();
            this.panel82.ResumeLayout(false);
            this.panel82.PerformLayout();
            this.panel81.ResumeLayout(false);
            this.panel81.PerformLayout();
            this.panel80.ResumeLayout(false);
            this.panel79.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.add6)).EndInit();
            this.panel71.ResumeLayout(false);
            this.panel71.PerformLayout();
            this.panel67.ResumeLayout(false);
            this.panel67.PerformLayout();
            this.panel68.ResumeLayout(false);
            this.panel66.ResumeLayout(false);
            this.panel66.PerformLayout();
            this.panel65.ResumeLayout(false);
            this.panel65.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel25.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.add5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.add4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.add3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.add2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.add1)).EndInit();
            this.panel18.ResumeLayout(false);
            this.panel8.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel31.ResumeLayout(false);
            this.panel32.ResumeLayout(false);
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.panel63.ResumeLayout(false);
            this.panel63.PerformLayout();
            this.panel64.ResumeLayout(false);
            this.panel64.PerformLayout();
            this.panel69.ResumeLayout(false);
            this.panel69.PerformLayout();
            this.panel91.ResumeLayout(false);
            this.panel91.PerformLayout();
            this.panel78.ResumeLayout(false);
            this.panel78.PerformLayout();
            this.panel77.ResumeLayout(false);
            this.panel77.PerformLayout();
            this.panel70.ResumeLayout(false);
            this.panel70.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.add7)).EndInit();
            this.panel72.ResumeLayout(false);
            this.panel89.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.Panel u;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.TabControl tabControl1;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private System.Windows.Forms.Label label24;
        private Bunifu.Framework.UI.BunifuImageButton close;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel7;
        internal System.Windows.Forms.Label lblUser;
        private System.Windows.Forms.TextBox txtID;
        private System.Windows.Forms.DataGridView dataGridView1;
        internal System.Windows.Forms.DataGridView dgvExcelData;
        internal System.Windows.Forms.Button btnReset;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.TextBox txtFilePath;
        internal System.Windows.Forms.Button btnGetData;
        internal System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.Panel panel57;
        private System.Windows.Forms.Panel panel58;
        private System.Windows.Forms.Panel panel59;
        private System.Windows.Forms.Panel panel60;
        private System.Windows.Forms.Panel panel61;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Panel panel52;
        internal System.Windows.Forms.DateTimePicker dateTimePicker3;
        private System.Windows.Forms.Panel panel62;
        internal System.Windows.Forms.DateTimePicker dateTimePicker4;
        internal System.Windows.Forms.Button btnfetch;
        internal System.Windows.Forms.Button btn_export;
        internal System.Windows.Forms.DataGridView dgw;
        private Inventory_DBDataSet inventory_DBDataSet;
        private System.Windows.Forms.BindingSource tblItemMasterBindingSource;
        private Inventory_DBDataSetTableAdapters.tblItemMasterTableAdapter tblItemMasterTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn barcode1DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn barcode2DataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn codeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameArabicDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nameEngDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn storeTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn brandNameDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn categoryDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn unitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn colorDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn descriptionDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn qtyPerUnitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn companyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn venderDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn discountTypeDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn directDiscountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nextShoppingDiscountDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn taxPercentDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn reorderLevelDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn manufacturingDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn expireDateDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchaseCurrencyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn sellingCurrencyDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn wholeSalePriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn purchasePriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn retailPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn customerPriceDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn addProfitDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn statusDataGridViewTextBoxColumn;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.TextBox txt_Description;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.TextBox txt_ProductnameEng;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.TextBox txt_ProductnameArabic;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private Bunifu.Framework.UI.BunifuImageButton add5;
        private Bunifu.Framework.UI.BunifuImageButton add4;
        private Bunifu.Framework.UI.BunifuImageButton add3;
        private Bunifu.Framework.UI.BunifuImageButton add2;
        private Bunifu.Framework.UI.BunifuImageButton add1;
        private System.Windows.Forms.Panel panel18;
        public System.Windows.Forms.ComboBox combo_Unit;
        private System.Windows.Forms.Panel panel8;
        public System.Windows.Forms.ComboBox combo_Color;
        private System.Windows.Forms.Panel panel24;
        public System.Windows.Forms.ComboBox combo_Brand;
        private System.Windows.Forms.Panel panel31;
        public System.Windows.Forms.ComboBox combo_Category;
        private System.Windows.Forms.Panel panel32;
        public System.Windows.Forms.ComboBox combo_Store;
        private System.Windows.Forms.Panel panel33;
        public System.Windows.Forms.TextBox txt_Productcode;
        private System.Windows.Forms.Panel panel63;
        private System.Windows.Forms.Panel panel64;
        public System.Windows.Forms.TextBox txt_Barcode1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel65;
        private System.Windows.Forms.TextBox txt_QtyPerUnit;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel66;
        private System.Windows.Forms.TextBox txt_CompanyProduct;
        private System.Windows.Forms.Label label14;
        private Bunifu.Framework.UI.BunifuImageButton add6;
        private System.Windows.Forms.Label label20;
        public System.Windows.Forms.Panel panel71;
        private System.Windows.Forms.Panel panel69;
        private Bunifu.Framework.UI.BunifuImageButton add7;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel72;
        private System.Windows.Forms.Panel panel73;
        private System.Windows.Forms.Panel panel74;
        private System.Windows.Forms.Panel panel75;
        private System.Windows.Forms.Panel panel76;
        private System.Windows.Forms.Panel panel67;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel68;
        private System.Windows.Forms.ComboBox combo_TaxType;
        private System.Windows.Forms.ComboBox combo_DiscountType;
        private System.Windows.Forms.TextBox txt_TaxAmount;
        private System.Windows.Forms.Panel panel70;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel77;
        private System.Windows.Forms.TextBox txt_DiscountAmount;
        private System.Windows.Forms.TextBox txt_DirectDiscount;
        private System.Windows.Forms.TextBox txt_ReorderLevel;
        private System.Windows.Forms.Label label26;
        public System.Windows.Forms.Panel panel78;
        private System.Windows.Forms.TextBox txt_NextShoppingDiscount;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label25;
        public System.Windows.Forms.Panel panel80;
        public System.Windows.Forms.Panel panel79;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label31;
        public System.Windows.Forms.Panel panel87;
        public System.Windows.Forms.Panel panel88;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label33;
        public System.Windows.Forms.Panel panel85;
        public System.Windows.Forms.Panel panel83;
        public System.Windows.Forms.Panel panel86;
        public System.Windows.Forms.Panel panel84;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label27;
        public System.Windows.Forms.Panel panel82;
        public System.Windows.Forms.Panel panel81;
        private System.Windows.Forms.ComboBox combo_PurchaseCurency;
        private Bunifu.Framework.UI.BunifuImageButton add9;
        private Bunifu.Framework.UI.BunifuImageButton add8;
        private System.Windows.Forms.ComboBox combo_SellingCurrency;
        private System.Windows.Forms.TextBox txt_WholeSalePrice;
        private System.Windows.Forms.TextBox txt_PurchasePrice;
        private System.Windows.Forms.TextBox txt_CustomerPrice;
        private System.Windows.Forms.TextBox txt_RetailPrice;
        private System.Windows.Forms.TextBox txt_AddProfit;
        private System.Windows.Forms.TextBox txt_Location;
        private System.Windows.Forms.TextBox txt_OpenningStock;
        private System.Windows.Forms.ComboBox combo_Status;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel89;
        private System.Windows.Forms.Panel panel95;
        public System.Windows.Forms.Button btn_save;
        internal System.Windows.Forms.Button btnUpdate;
        public System.Windows.Forms.Button btndel;
        private System.Windows.Forms.Button btn_print;
        private System.Windows.Forms.ComboBox combo_search_type;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.TextBox txt_Barcode2;
        public System.Windows.Forms.Panel panel90;
        internal System.Windows.Forms.DateTimePicker dateTimePicker2;
        internal System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Label label18;
        public System.Windows.Forms.Panel panel91;
        private System.Windows.Forms.TextBox txt_PreferredVender;
    }
}