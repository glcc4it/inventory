﻿namespace Loop_Inventory
{
    partial class Saleproduct
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Saleproduct));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btn_add = new System.Windows.Forms.Button();
            this.btnperview = new System.Windows.Forms.Button();
            this.btnprint = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Productcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Barcode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Product = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Saleprice = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Quantity = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Unit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Total = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.label15 = new System.Windows.Forms.Label();
            this.btndel = new System.Windows.Forms.Button();
            this.btnget = new System.Windows.Forms.Button();
            this.btn_save = new System.Windows.Forms.Button();
            this.txt_amount = new System.Windows.Forms.TextBox();
            this.txt_tax_amount = new System.Windows.Forms.TextBox();
            this.txt_dis_amount = new System.Windows.Forms.TextBox();
            this.txt_total_amount = new System.Windows.Forms.TextBox();
            this.panel13 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.txt_qty = new System.Windows.Forms.TextBox();
            this.txt_comment = new System.Windows.Forms.TextBox();
            this.txt_dues = new System.Windows.Forms.TextBox();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel32 = new System.Windows.Forms.Panel();
            this.label34 = new System.Windows.Forms.Label();
            this.panel31 = new System.Windows.Forms.Panel();
            this.label33 = new System.Windows.Forms.Label();
            this.combo_TaxType = new System.Windows.Forms.ComboBox();
            this.combo_DiscountType = new System.Windows.Forms.ComboBox();
            this.combo_PaymentMethod = new System.Windows.Forms.ComboBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.panel30 = new System.Windows.Forms.Panel();
            this.label32 = new System.Windows.Forms.Label();
            this.panel29 = new System.Windows.Forms.Panel();
            this.label31 = new System.Windows.Forms.Label();
            this.txt_total_items = new System.Windows.Forms.TextBox();
            this.panel23 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.lblBalance = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.txt_greeting = new System.Windows.Forms.TextBox();
            this.txt_footer_message = new System.Windows.Forms.TextBox();
            this.txt_rec_amount = new System.Windows.Forms.TextBox();
            this.txt_new_bal = new System.Windows.Forms.TextBox();
            this.txt_old_bal = new System.Windows.Forms.TextBox();
            this.panel19 = new System.Windows.Forms.Panel();
            this.label21 = new System.Windows.Forms.Label();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label16 = new System.Windows.Forms.Label();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label19 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label17 = new System.Windows.Forms.Label();
            this.panel20 = new System.Windows.Forms.Panel();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.txt_Total = new System.Windows.Forms.TextBox();
            this.txt_price = new System.Windows.Forms.TextBox();
            this.txt_Barcode2 = new System.Windows.Forms.TextBox();
            this.txt_pro_name = new System.Windows.Forms.TextBox();
            this.txt_barcode = new System.Windows.Forms.TextBox();
            this.combo_bil_type = new System.Windows.Forms.ComboBox();
            this.combo_salesman = new System.Windows.Forms.ComboBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.txt_invoice_no = new System.Windows.Forms.TextBox();
            this.bunifuImageButton1 = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bunifuImageButton38 = new Bunifu.Framework.UI.BunifuImageButton();
            this.label24 = new System.Windows.Forms.Label();
            this.bunifuImageButton5 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton6 = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.bunifuImageButton10 = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label14 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.panel7 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.panel21 = new System.Windows.Forms.Panel();
            this.btnupdate = new System.Windows.Forms.Button();
            this.btnLoadTransaction = new System.Windows.Forms.Button();
            this.btnHoldTransaction = new System.Windows.Forms.Button();
            this.btnRate = new System.Windows.Forms.Button();
            this.btnChangeQty = new System.Windows.Forms.Button();
            this.btnLogout = new System.Windows.Forms.Button();
            this.btnBulkProduct = new System.Windows.Forms.Button();
            this.btnOpenCashDrawer = new System.Windows.Forms.Button();
            this.btnTouchscreen = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.panel28 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.panel44 = new System.Windows.Forms.Panel();
            this.txt_Address2 = new System.Windows.Forms.TextBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Paymode = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Amount = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.CTYpe = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.btn_close = new System.Windows.Forms.Button();
            this.btn_remove = new System.Windows.Forms.Button();
            this.Btn_clear = new System.Windows.Forms.Button();
            this.Btn_savePrint = new System.Windows.Forms.Button();
            this.btn_bank = new System.Windows.Forms.Button();
            this.btn_wallet = new System.Windows.Forms.Button();
            this.btn_credit = new System.Windows.Forms.Button();
            this.Btn_Cash = new System.Windows.Forms.Button();
            this.Btn_100 = new System.Windows.Forms.Button();
            this.Btn_0 = new System.Windows.Forms.Button();
            this.Btn_Dot = new System.Windows.Forms.Button();
            this.Btn_ten = new System.Windows.Forms.Button();
            this.Btn_50 = new System.Windows.Forms.Button();
            this.Btn_9 = new System.Windows.Forms.Button();
            this.Btn_8 = new System.Windows.Forms.Button();
            this.Btn_7 = new System.Windows.Forms.Button();
            this.Btn_20 = new System.Windows.Forms.Button();
            this.Btn_6 = new System.Windows.Forms.Button();
            this.Btn_5 = new System.Windows.Forms.Button();
            this.Btn_4 = new System.Windows.Forms.Button();
            this.Btn_10 = new System.Windows.Forms.Button();
            this.Btn_3 = new System.Windows.Forms.Button();
            this.Btn_2 = new System.Windows.Forms.Button();
            this.Btn_1 = new System.Windows.Forms.Button();
            this.txt_cus_mob = new System.Windows.Forms.TextBox();
            this.combo_Store = new System.Windows.Forms.ComboBox();
            this.combo_Unit = new System.Windows.Forms.ComboBox();
            this.combo_Servername = new System.Windows.Forms.ComboBox();
            this.combo_Pricinglevel = new System.Windows.Forms.ComboBox();
            this.bunifuImageButton3 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton2 = new Bunifu.Framework.UI.BunifuImageButton();
            this.txtCus_ID = new System.Windows.Forms.TextBox();
            this.combo_Currency = new System.Windows.Forms.ComboBox();
            this.txt_pro_code = new System.Windows.Forms.TextBox();
            this.bunifuImageButton4 = new Bunifu.Framework.UI.BunifuImageButton();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.panel18 = new System.Windows.Forms.Panel();
            this.label20 = new System.Windows.Forms.Label();
            this.panel24 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.panel27 = new System.Windows.Forms.Panel();
            this.label27 = new System.Windows.Forms.Label();
            this.btnnew = new System.Windows.Forms.Button();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.lblUser = new System.Windows.Forms.Label();
            this.txtCustomerID = new System.Windows.Forms.TextBox();
            this.txtinvoice = new System.Windows.Forms.TextBox();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel13.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel14.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel16.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton38)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton10)).BeginInit();
            this.panel12.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel44.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton4)).BeginInit();
            this.panel18.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // btn_add
            // 
            this.btn_add.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btn_add.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_add.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            this.btn_add.Image = ((System.Drawing.Image)(resources.GetObject("btn_add.Image")));
            this.btn_add.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_add.Location = new System.Drawing.Point(585, 568);
            this.btn_add.Name = "btn_add";
            this.btn_add.Size = new System.Drawing.Size(121, 36);
            this.btn_add.TabIndex = 865;
            this.btn_add.Text = "        Add to cart";
            this.btn_add.UseVisualStyleBackColor = false;
            this.btn_add.Click += new System.EventHandler(this.btn_add_Click);
            // 
            // btnperview
            // 
            this.btnperview.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnperview.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnperview.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnperview.Image = ((System.Drawing.Image)(resources.GetObject("btnperview.Image")));
            this.btnperview.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnperview.Location = new System.Drawing.Point(459, 568);
            this.btnperview.Name = "btnperview";
            this.btnperview.Size = new System.Drawing.Size(125, 36);
            this.btnperview.TabIndex = 864;
            this.btnperview.Text = "      Print Perview";
            this.btnperview.UseVisualStyleBackColor = false;
            this.btnperview.Click += new System.EventHandler(this.button10_Click);
            // 
            // btnprint
            // 
            this.btnprint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnprint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnprint.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnprint.Image = ((System.Drawing.Image)(resources.GetObject("btnprint.Image")));
            this.btnprint.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnprint.Location = new System.Drawing.Point(360, 568);
            this.btnprint.Name = "btnprint";
            this.btnprint.Size = new System.Drawing.Size(98, 36);
            this.btnprint.TabIndex = 863;
            this.btnprint.Text = "      Print";
            this.btnprint.UseVisualStyleBackColor = false;
            this.btnprint.Click += new System.EventHandler(this.button11_Click);
            // 
            // dataGridView1
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.OldLace;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Productcode,
            this.Barcode,
            this.Product,
            this.Saleprice,
            this.Quantity,
            this.Unit,
            this.Total});
            this.dataGridView1.Location = new System.Drawing.Point(5, 169);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle3;
            this.dataGridView1.Size = new System.Drawing.Size(701, 169);
            this.dataGridView1.TabIndex = 858;
            // 
            // Productcode
            // 
            this.Productcode.DataPropertyName = "Productcode";
            this.Productcode.HeaderText = "Productcode";
            this.Productcode.Name = "Productcode";
            // 
            // Barcode
            // 
            this.Barcode.DataPropertyName = "Barcode";
            this.Barcode.HeaderText = "Barcode";
            this.Barcode.Name = "Barcode";
            // 
            // Product
            // 
            this.Product.DataPropertyName = "Product";
            this.Product.HeaderText = "Product";
            this.Product.Name = "Product";
            // 
            // Saleprice
            // 
            this.Saleprice.DataPropertyName = "Saleprice";
            this.Saleprice.HeaderText = "Price";
            this.Saleprice.Name = "Saleprice";
            // 
            // Quantity
            // 
            this.Quantity.DataPropertyName = "Quantity";
            this.Quantity.HeaderText = "Quantity";
            this.Quantity.Name = "Quantity";
            // 
            // Unit
            // 
            this.Unit.DataPropertyName = "Unit";
            this.Unit.HeaderText = "Typeofunit";
            this.Unit.Name = "Unit";
            // 
            // Total
            // 
            this.Total.DataPropertyName = "Total";
            this.Total.HeaderText = "Total";
            this.Total.Name = "Total";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.Black;
            this.label15.Location = new System.Drawing.Point(3, 5);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(53, 18);
            this.label15.TabIndex = 327;
            this.label15.Text = "Tax (%)";
            // 
            // btndel
            // 
            this.btndel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btndel.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btndel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btndel.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            this.btndel.ForeColor = System.Drawing.Color.Black;
            this.btndel.Image = ((System.Drawing.Image)(resources.GetObject("btndel.Image")));
            this.btndel.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btndel.Location = new System.Drawing.Point(289, 568);
            this.btndel.Name = "btndel";
            this.btndel.Size = new System.Drawing.Size(70, 36);
            this.btndel.TabIndex = 862;
            this.btndel.Text = "&Delete";
            this.btndel.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btndel.UseVisualStyleBackColor = false;
            // 
            // btnget
            // 
            this.btnget.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnget.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnget.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnget.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnget.ForeColor = System.Drawing.Color.Black;
            this.btnget.Image = ((System.Drawing.Image)(resources.GetObject("btnget.Image")));
            this.btnget.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnget.Location = new System.Drawing.Point(147, 568);
            this.btnget.Name = "btnget";
            this.btnget.Size = new System.Drawing.Size(70, 36);
            this.btnget.TabIndex = 861;
            this.btnget.Text = "&GetData";
            this.btnget.UseVisualStyleBackColor = false;
            // 
            // btn_save
            // 
            this.btn_save.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btn_save.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btn_save.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_save.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_save.ForeColor = System.Drawing.Color.Black;
            this.btn_save.Image = ((System.Drawing.Image)(resources.GetObject("btn_save.Image")));
            this.btn_save.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_save.Location = new System.Drawing.Point(76, 568);
            this.btn_save.Name = "btn_save";
            this.btn_save.Size = new System.Drawing.Size(70, 36);
            this.btn_save.TabIndex = 860;
            this.btn_save.Text = "&Save";
            this.btn_save.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btn_save.UseVisualStyleBackColor = false;
            this.btn_save.Click += new System.EventHandler(this.btn_save_Click);
            // 
            // txt_amount
            // 
            this.txt_amount.Font = new System.Drawing.Font("Trebuchet MS", 14.25F);
            this.txt_amount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_amount.Location = new System.Drawing.Point(616, 139);
            this.txt_amount.Name = "txt_amount";
            this.txt_amount.Size = new System.Drawing.Size(90, 30);
            this.txt_amount.TabIndex = 857;
            // 
            // txt_tax_amount
            // 
            this.txt_tax_amount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_tax_amount.Font = new System.Drawing.Font("Trebuchet MS", 14.25F);
            this.txt_tax_amount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_tax_amount.Location = new System.Drawing.Point(112, 215);
            this.txt_tax_amount.Name = "txt_tax_amount";
            this.txt_tax_amount.Size = new System.Drawing.Size(142, 30);
            this.txt_tax_amount.TabIndex = 439;
            // 
            // txt_dis_amount
            // 
            this.txt_dis_amount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_dis_amount.Font = new System.Drawing.Font("Trebuchet MS", 14.25F);
            this.txt_dis_amount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_dis_amount.Location = new System.Drawing.Point(112, 145);
            this.txt_dis_amount.Name = "txt_dis_amount";
            this.txt_dis_amount.Size = new System.Drawing.Size(142, 30);
            this.txt_dis_amount.TabIndex = 437;
            // 
            // txt_total_amount
            // 
            this.txt_total_amount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_total_amount.Font = new System.Drawing.Font("Trebuchet MS", 14.25F);
            this.txt_total_amount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_total_amount.Location = new System.Drawing.Point(112, 75);
            this.txt_total_amount.Name = "txt_total_amount";
            this.txt_total_amount.Size = new System.Drawing.Size(142, 30);
            this.txt_total_amount.TabIndex = 428;
            // 
            // panel13
            // 
            this.panel13.BackColor = System.Drawing.SystemColors.Control;
            this.panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel13.Controls.Add(this.label15);
            this.panel13.Location = new System.Drawing.Point(8, 180);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(105, 30);
            this.panel13.TabIndex = 426;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Control;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.label1);
            this.panel4.Location = new System.Drawing.Point(8, 110);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(105, 30);
            this.panel4.TabIndex = 425;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(3, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 18);
            this.label1.TabIndex = 327;
            this.label1.Text = "Discount (%)";
            // 
            // txt_qty
            // 
            this.txt_qty.Font = new System.Drawing.Font("Trebuchet MS", 14.25F);
            this.txt_qty.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_qty.Location = new System.Drawing.Point(460, 139);
            this.txt_qty.Name = "txt_qty";
            this.txt_qty.Size = new System.Drawing.Size(60, 30);
            this.txt_qty.TabIndex = 855;
            this.txt_qty.TextChanged += new System.EventHandler(this.txt_qty_TextChanged);
            this.txt_qty.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_qty_KeyDown);
            // 
            // txt_comment
            // 
            this.txt_comment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_comment.Font = new System.Drawing.Font("Trebuchet MS", 14.25F);
            this.txt_comment.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_comment.Location = new System.Drawing.Point(112, 531);
            this.txt_comment.Name = "txt_comment";
            this.txt_comment.Size = new System.Drawing.Size(142, 30);
            this.txt_comment.TabIndex = 446;
            // 
            // txt_dues
            // 
            this.txt_dues.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_dues.Font = new System.Drawing.Font("Trebuchet MS", 14.25F);
            this.txt_dues.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_dues.Location = new System.Drawing.Point(112, 498);
            this.txt_dues.Name = "txt_dues";
            this.txt_dues.Size = new System.Drawing.Size(142, 30);
            this.txt_dues.TabIndex = 445;
            // 
            // panel22
            // 
            this.panel22.BackColor = System.Drawing.Color.Transparent;
            this.panel22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel22.Controls.Add(this.panel32);
            this.panel22.Controls.Add(this.panel31);
            this.panel22.Controls.Add(this.combo_TaxType);
            this.panel22.Controls.Add(this.combo_DiscountType);
            this.panel22.Controls.Add(this.combo_PaymentMethod);
            this.panel22.Controls.Add(this.textBox2);
            this.panel22.Controls.Add(this.panel30);
            this.panel22.Controls.Add(this.panel29);
            this.panel22.Controls.Add(this.txt_total_items);
            this.panel22.Controls.Add(this.panel23);
            this.panel22.Controls.Add(this.lblBalance);
            this.panel22.Controls.Add(this.label28);
            this.panel22.Controls.Add(this.panel25);
            this.panel22.Controls.Add(this.txt_greeting);
            this.panel22.Controls.Add(this.txt_footer_message);
            this.panel22.Controls.Add(this.txt_comment);
            this.panel22.Controls.Add(this.txt_dues);
            this.panel22.Controls.Add(this.txt_rec_amount);
            this.panel22.Controls.Add(this.txt_new_bal);
            this.panel22.Controls.Add(this.txt_old_bal);
            this.panel22.Controls.Add(this.txt_tax_amount);
            this.panel22.Controls.Add(this.txt_dis_amount);
            this.panel22.Controls.Add(this.txt_total_amount);
            this.panel22.Controls.Add(this.panel13);
            this.panel22.Controls.Add(this.panel4);
            this.panel22.Controls.Add(this.panel19);
            this.panel22.Controls.Add(this.panel14);
            this.panel22.Controls.Add(this.panel17);
            this.panel22.Controls.Add(this.panel15);
            this.panel22.Controls.Add(this.panel20);
            this.panel22.Controls.Add(this.label23);
            this.panel22.Controls.Add(this.panel16);
            this.panel22.Controls.Add(this.txt_Total);
            this.panel22.Location = new System.Drawing.Point(727, 38);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(264, 652);
            this.panel22.TabIndex = 391;
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.SystemColors.Control;
            this.panel32.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel32.Controls.Add(this.label34);
            this.panel32.Location = new System.Drawing.Point(8, 215);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(105, 30);
            this.panel32.TabIndex = 427;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.Black;
            this.label34.Location = new System.Drawing.Point(3, 5);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(76, 18);
            this.label34.TabIndex = 327;
            this.label34.Text = "Tax Amont:";
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.SystemColors.Control;
            this.panel31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel31.Controls.Add(this.label33);
            this.panel31.Location = new System.Drawing.Point(8, 145);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(105, 30);
            this.panel31.TabIndex = 426;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.Black;
            this.label33.Location = new System.Drawing.Point(3, 5);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(81, 18);
            this.label33.TabIndex = 327;
            this.label33.Text = "Dis Amount:";
            // 
            // combo_TaxType
            // 
            this.combo_TaxType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_TaxType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_TaxType.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_TaxType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.combo_TaxType.FormattingEnabled = true;
            this.combo_TaxType.Location = new System.Drawing.Point(112, 180);
            this.combo_TaxType.Name = "combo_TaxType";
            this.combo_TaxType.Size = new System.Drawing.Size(142, 30);
            this.combo_TaxType.TabIndex = 1037;
            this.combo_TaxType.Text = "-Select Tax Type-";
            // 
            // combo_DiscountType
            // 
            this.combo_DiscountType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_DiscountType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_DiscountType.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_DiscountType.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.combo_DiscountType.FormattingEnabled = true;
            this.combo_DiscountType.Location = new System.Drawing.Point(112, 110);
            this.combo_DiscountType.Name = "combo_DiscountType";
            this.combo_DiscountType.Size = new System.Drawing.Size(142, 30);
            this.combo_DiscountType.TabIndex = 1036;
            this.combo_DiscountType.Text = "-Select Dis Type-";
            // 
            // combo_PaymentMethod
            // 
            this.combo_PaymentMethod.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_PaymentMethod.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_PaymentMethod.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_PaymentMethod.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.combo_PaymentMethod.FormattingEnabled = true;
            this.combo_PaymentMethod.Items.AddRange(new object[] {
            "Traeasury",
            "Bank",
            "Account",
            "Wellet"});
            this.combo_PaymentMethod.Location = new System.Drawing.Point(112, 364);
            this.combo_PaymentMethod.Name = "combo_PaymentMethod";
            this.combo_PaymentMethod.Size = new System.Drawing.Size(142, 30);
            this.combo_PaymentMethod.TabIndex = 1035;
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.textBox2.Font = new System.Drawing.Font("Trebuchet MS", 14.25F);
            this.textBox2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBox2.Location = new System.Drawing.Point(112, 40);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(142, 30);
            this.textBox2.TabIndex = 838;
            // 
            // panel30
            // 
            this.panel30.BackColor = System.Drawing.SystemColors.Control;
            this.panel30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel30.Controls.Add(this.label32);
            this.panel30.Location = new System.Drawing.Point(8, 364);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(105, 30);
            this.panel30.TabIndex = 443;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.Black;
            this.label32.Location = new System.Drawing.Point(2, 5);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(83, 18);
            this.label32.TabIndex = 327;
            this.label32.Text = "Pay Method:";
            // 
            // panel29
            // 
            this.panel29.BackColor = System.Drawing.SystemColors.Control;
            this.panel29.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel29.Controls.Add(this.label31);
            this.panel29.Location = new System.Drawing.Point(8, 40);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(105, 30);
            this.panel29.TabIndex = 837;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label31.ForeColor = System.Drawing.Color.Black;
            this.label31.Location = new System.Drawing.Point(2, 5);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(82, 18);
            this.label31.TabIndex = 327;
            this.label31.Text = "No of Items:";
            // 
            // txt_total_items
            // 
            this.txt_total_items.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_total_items.Font = new System.Drawing.Font("Trebuchet MS", 14.25F);
            this.txt_total_items.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_total_items.Location = new System.Drawing.Point(112, 5);
            this.txt_total_items.Name = "txt_total_items";
            this.txt_total_items.Size = new System.Drawing.Size(142, 30);
            this.txt_total_items.TabIndex = 836;
            // 
            // panel23
            // 
            this.panel23.BackColor = System.Drawing.SystemColors.Control;
            this.panel23.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel23.Controls.Add(this.label26);
            this.panel23.Location = new System.Drawing.Point(8, 5);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(105, 30);
            this.panel23.TabIndex = 835;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(2, 5);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(102, 18);
            this.label26.TabIndex = 327;
            this.label26.Text = "No of Quantity:";
            // 
            // lblBalance
            // 
            this.lblBalance.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.lblBalance.AutoSize = true;
            this.lblBalance.BackColor = System.Drawing.Color.Transparent;
            this.lblBalance.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBalance.ForeColor = System.Drawing.Color.Maroon;
            this.lblBalance.Location = new System.Drawing.Point(133, 625);
            this.lblBalance.Name = "lblBalance";
            this.lblBalance.Size = new System.Drawing.Size(32, 24);
            this.lblBalance.TabIndex = 834;
            this.lblBalance.Text = "00";
            // 
            // label28
            // 
            this.label28.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label28.Location = new System.Drawing.Point(44, 624);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(92, 24);
            this.label28.TabIndex = 833;
            this.label28.Text = "Balance :";
            // 
            // panel25
            // 
            this.panel25.BackColor = System.Drawing.Color.Transparent;
            this.panel25.Controls.Add(this.panel26);
            this.panel25.ForeColor = System.Drawing.Color.Black;
            this.panel25.Location = new System.Drawing.Point(8, 636);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(246, 11);
            this.panel25.TabIndex = 832;
            // 
            // panel26
            // 
            this.panel26.BackColor = System.Drawing.Color.Gray;
            this.panel26.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel26.Location = new System.Drawing.Point(0, 0);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(246, 2);
            this.panel26.TabIndex = 426;
            // 
            // txt_greeting
            // 
            this.txt_greeting.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_greeting.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_greeting.Location = new System.Drawing.Point(8, 592);
            this.txt_greeting.Name = "txt_greeting";
            this.txt_greeting.Size = new System.Drawing.Size(246, 26);
            this.txt_greeting.TabIndex = 831;
            this.txt_greeting.Text = "* * Thank You.. Visit Again * *";
            // 
            // txt_footer_message
            // 
            this.txt_footer_message.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_footer_message.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_footer_message.Location = new System.Drawing.Point(8, 564);
            this.txt_footer_message.Name = "txt_footer_message";
            this.txt_footer_message.Size = new System.Drawing.Size(246, 26);
            this.txt_footer_message.TabIndex = 830;
            this.txt_footer_message.Text = "* * Please verify your items before leave * *";
            // 
            // txt_rec_amount
            // 
            this.txt_rec_amount.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.txt_rec_amount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_rec_amount.Font = new System.Drawing.Font("Trebuchet MS", 14.25F);
            this.txt_rec_amount.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_rec_amount.Location = new System.Drawing.Point(112, 465);
            this.txt_rec_amount.Name = "txt_rec_amount";
            this.txt_rec_amount.Size = new System.Drawing.Size(142, 30);
            this.txt_rec_amount.TabIndex = 444;
            this.txt_rec_amount.TextChanged += new System.EventHandler(this.txt_rec_amount_TextChanged);
            // 
            // txt_new_bal
            // 
            this.txt_new_bal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_new_bal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_new_bal.Font = new System.Drawing.Font("Trebuchet MS", 14.25F);
            this.txt_new_bal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_new_bal.Location = new System.Drawing.Point(112, 432);
            this.txt_new_bal.Name = "txt_new_bal";
            this.txt_new_bal.ReadOnly = true;
            this.txt_new_bal.Size = new System.Drawing.Size(142, 30);
            this.txt_new_bal.TabIndex = 443;
            // 
            // txt_old_bal
            // 
            this.txt_old_bal.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.txt_old_bal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txt_old_bal.Font = new System.Drawing.Font("Trebuchet MS", 14.25F);
            this.txt_old_bal.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_old_bal.Location = new System.Drawing.Point(112, 399);
            this.txt_old_bal.Name = "txt_old_bal";
            this.txt_old_bal.ReadOnly = true;
            this.txt_old_bal.Size = new System.Drawing.Size(142, 30);
            this.txt_old_bal.TabIndex = 442;
            // 
            // panel19
            // 
            this.panel19.BackColor = System.Drawing.SystemColors.Control;
            this.panel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel19.Controls.Add(this.label21);
            this.panel19.Location = new System.Drawing.Point(8, 75);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(105, 30);
            this.panel19.TabIndex = 424;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.Black;
            this.label21.Location = new System.Drawing.Point(3, 5);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(69, 18);
            this.label21.TabIndex = 327;
            this.label21.Text = "Sub Total:";
            // 
            // panel14
            // 
            this.panel14.BackColor = System.Drawing.SystemColors.Control;
            this.panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel14.Controls.Add(this.label16);
            this.panel14.Location = new System.Drawing.Point(8, 531);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(105, 30);
            this.panel14.TabIndex = 421;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(3, 5);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(76, 18);
            this.label16.TabIndex = 327;
            this.label16.Text = "Comments:";
            // 
            // panel17
            // 
            this.panel17.BackColor = System.Drawing.SystemColors.Control;
            this.panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel17.Controls.Add(this.label19);
            this.panel17.Location = new System.Drawing.Point(8, 465);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(105, 30);
            this.panel17.TabIndex = 362;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.Black;
            this.label19.Location = new System.Drawing.Point(3, 5);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(92, 18);
            this.label19.TabIndex = 327;
            this.label19.Text = "Recved Amnt:";
            // 
            // panel15
            // 
            this.panel15.BackColor = System.Drawing.SystemColors.Control;
            this.panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel15.Controls.Add(this.label17);
            this.panel15.Location = new System.Drawing.Point(8, 399);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(105, 30);
            this.panel15.TabIndex = 354;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.Black;
            this.label17.Location = new System.Drawing.Point(2, 5);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(86, 18);
            this.label17.TabIndex = 327;
            this.label17.Text = "Old Balance:";
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.SystemColors.Control;
            this.panel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel20.Controls.Add(this.label22);
            this.panel20.Location = new System.Drawing.Point(8, 498);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(105, 30);
            this.panel20.TabIndex = 399;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.Black;
            this.label22.Location = new System.Drawing.Point(3, 5);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(92, 18);
            this.label22.TabIndex = 327;
            this.label22.Text = "Dues Amount:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.Black;
            this.label23.Location = new System.Drawing.Point(4, 249);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(136, 24);
            this.label23.TabIndex = 328;
            this.label23.Text = "Total Amount:";
            // 
            // panel16
            // 
            this.panel16.BackColor = System.Drawing.SystemColors.Control;
            this.panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel16.Controls.Add(this.label18);
            this.panel16.Location = new System.Drawing.Point(8, 432);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(105, 30);
            this.panel16.TabIndex = 358;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Black;
            this.label18.Location = new System.Drawing.Point(2, 5);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(91, 18);
            this.label18.TabIndex = 327;
            this.label18.Text = "New Balance:";
            // 
            // txt_Total
            // 
            this.txt_Total.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_Total.Font = new System.Drawing.Font("Trebuchet MS", 48F);
            this.txt_Total.ForeColor = System.Drawing.Color.Blue;
            this.txt_Total.Location = new System.Drawing.Point(8, 277);
            this.txt_Total.Multiline = true;
            this.txt_Total.Name = "txt_Total";
            this.txt_Total.Size = new System.Drawing.Size(246, 81);
            this.txt_Total.TabIndex = 440;
            this.txt_Total.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_Total.TextChanged += new System.EventHandler(this.txt_net_amount_TextChanged);
            // 
            // txt_price
            // 
            this.txt_price.Font = new System.Drawing.Font("Trebuchet MS", 14.25F);
            this.txt_price.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_price.Location = new System.Drawing.Point(366, 139);
            this.txt_price.Name = "txt_price";
            this.txt_price.Size = new System.Drawing.Size(92, 30);
            this.txt_price.TabIndex = 854;
            // 
            // txt_Barcode2
            // 
            this.txt_Barcode2.Font = new System.Drawing.Font("Trebuchet MS", 14.25F);
            this.txt_Barcode2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_Barcode2.Location = new System.Drawing.Point(272, 139);
            this.txt_Barcode2.Name = "txt_Barcode2";
            this.txt_Barcode2.Size = new System.Drawing.Size(92, 30);
            this.txt_Barcode2.TabIndex = 853;
            // 
            // txt_pro_name
            // 
            this.txt_pro_name.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_pro_name.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_pro_name.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_pro_name.Location = new System.Drawing.Point(114, 139);
            this.txt_pro_name.Name = "txt_pro_name";
            this.txt_pro_name.Size = new System.Drawing.Size(156, 30);
            this.txt_pro_name.TabIndex = 852;
            this.txt_pro_name.TextChanged += new System.EventHandler(this.txt_pro_name_TextChanged);
            this.txt_pro_name.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txt_pro_name_KeyDown);
            // 
            // txt_barcode
            // 
            this.txt_barcode.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_barcode.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_barcode.Location = new System.Drawing.Point(5, 139);
            this.txt_barcode.Name = "txt_barcode";
            this.txt_barcode.Size = new System.Drawing.Size(107, 30);
            this.txt_barcode.TabIndex = 851;
            // 
            // combo_bil_type
            // 
            this.combo_bil_type.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_bil_type.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_bil_type.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_bil_type.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.combo_bil_type.FormattingEnabled = true;
            this.combo_bil_type.Items.AddRange(new object[] {
            "Cash Sale",
            "Credit Sale"});
            this.combo_bil_type.Location = new System.Drawing.Point(79, 40);
            this.combo_bil_type.Name = "combo_bil_type";
            this.combo_bil_type.Size = new System.Drawing.Size(145, 30);
            this.combo_bil_type.TabIndex = 848;
            this.combo_bil_type.Text = "- Transaction-";
            this.combo_bil_type.SelectedIndexChanged += new System.EventHandler(this.combo_bil_type_SelectedIndexChanged);
            // 
            // combo_salesman
            // 
            this.combo_salesman.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_salesman.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_salesman.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_salesman.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.combo_salesman.FormattingEnabled = true;
            this.combo_salesman.Location = new System.Drawing.Point(554, 5);
            this.combo_salesman.Name = "combo_salesman";
            this.combo_salesman.Size = new System.Drawing.Size(130, 30);
            this.combo_salesman.TabIndex = 847;
            this.combo_salesman.Text = "- Select Saleman-";
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Arial Narrow", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker1.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(318, 5);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(152, 30);
            this.dateTimePicker1.TabIndex = 828;
            // 
            // txt_invoice_no
            // 
            this.txt_invoice_no.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.txt_invoice_no.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_invoice_no.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_invoice_no.Location = new System.Drawing.Point(79, 5);
            this.txt_invoice_no.Name = "txt_invoice_no";
            this.txt_invoice_no.Size = new System.Drawing.Size(145, 30);
            this.txt_invoice_no.TabIndex = 827;
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.BackColor = System.Drawing.Color.DimGray;
            this.bunifuImageButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.Location = new System.Drawing.Point(684, 5);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Size = new System.Drawing.Size(22, 30);
            this.bunifuImageButton1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton1.TabIndex = 826;
            this.bunifuImageButton1.TabStop = false;
            this.bunifuImageButton1.Zoom = 10;
            this.bunifuImageButton1.Click += new System.EventHandler(this.bunifuImageButton1_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.Blue;
            this.panel1.Controls.Add(this.bunifuImageButton38);
            this.panel1.Controls.Add(this.label24);
            this.panel1.Controls.Add(this.bunifuImageButton5);
            this.panel1.Controls.Add(this.bunifuImageButton6);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1000, 31);
            this.panel1.TabIndex = 386;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseDown);
            this.panel1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseMove);
            this.panel1.MouseUp += new System.Windows.Forms.MouseEventHandler(this.panel1_MouseUp);
            // 
            // bunifuImageButton38
            // 
            this.bunifuImageButton38.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.bunifuImageButton38.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton38.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton38.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton38.Image")));
            this.bunifuImageButton38.ImageActive = null;
            this.bunifuImageButton38.Location = new System.Drawing.Point(5, 5);
            this.bunifuImageButton38.Name = "bunifuImageButton38";
            this.bunifuImageButton38.Size = new System.Drawing.Size(20, 21);
            this.bunifuImageButton38.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton38.TabIndex = 380;
            this.bunifuImageButton38.TabStop = false;
            this.bunifuImageButton38.Zoom = 10;
            // 
            // label24
            // 
            this.label24.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.Transparent;
            this.label24.Location = new System.Drawing.Point(28, 5);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(137, 20);
            this.label24.TabIndex = 290;
            this.label24.Text = "Daily Sale Product";
            this.label24.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            // 
            // bunifuImageButton5
            // 
            this.bunifuImageButton5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton5.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton5.Image")));
            this.bunifuImageButton5.ImageActive = null;
            this.bunifuImageButton5.Location = new System.Drawing.Point(954, 5);
            this.bunifuImageButton5.Name = "bunifuImageButton5";
            this.bunifuImageButton5.Size = new System.Drawing.Size(22, 22);
            this.bunifuImageButton5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton5.TabIndex = 230;
            this.bunifuImageButton5.TabStop = false;
            this.bunifuImageButton5.Zoom = 10;
            this.bunifuImageButton5.Click += new System.EventHandler(this.bunifuImageButton5_Click);
            // 
            // bunifuImageButton6
            // 
            this.bunifuImageButton6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton6.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton6.Image")));
            this.bunifuImageButton6.ImageActive = null;
            this.bunifuImageButton6.Location = new System.Drawing.Point(975, 5);
            this.bunifuImageButton6.Name = "bunifuImageButton6";
            this.bunifuImageButton6.Size = new System.Drawing.Size(22, 22);
            this.bunifuImageButton6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton6.TabIndex = 229;
            this.bunifuImageButton6.TabStop = false;
            this.bunifuImageButton6.Zoom = 10;
            this.bunifuImageButton6.Click += new System.EventHandler(this.bunifuImageButton6_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.Blue;
            this.panel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel2.Location = new System.Drawing.Point(0, 696);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1000, 5);
            this.panel2.TabIndex = 389;
            // 
            // bunifuImageButton10
            // 
            this.bunifuImageButton10.BackColor = System.Drawing.Color.DimGray;
            this.bunifuImageButton10.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton10.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton10.Image")));
            this.bunifuImageButton10.ImageActive = null;
            this.bunifuImageButton10.Location = new System.Drawing.Point(445, 40);
            this.bunifuImageButton10.Name = "bunifuImageButton10";
            this.bunifuImageButton10.Size = new System.Drawing.Size(23, 30);
            this.bunifuImageButton10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton10.TabIndex = 824;
            this.bunifuImageButton10.TabStop = false;
            this.bunifuImageButton10.Zoom = 10;
            this.bunifuImageButton10.Click += new System.EventHandler(this.bunifuImageButton10_Click);
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.SystemColors.Control;
            this.panel12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel12.Controls.Add(this.label14);
            this.panel12.Location = new System.Drawing.Point(468, 40);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(88, 30);
            this.panel12.TabIndex = 394;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(5, 6);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(78, 16);
            this.label14.TabIndex = 327;
            this.label14.Text = "Select Store:";
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Blue;
            this.panel11.Controls.Add(this.label12);
            this.panel11.Controls.Add(this.label7);
            this.panel11.Controls.Add(this.label6);
            this.panel11.Controls.Add(this.label5);
            this.panel11.Controls.Add(this.label4);
            this.panel11.Controls.Add(this.label11);
            this.panel11.Controls.Add(this.label13);
            this.panel11.Location = new System.Drawing.Point(5, 110);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(701, 24);
            this.panel11.TabIndex = 393;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(264, 3);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(95, 18);
            this.label12.TabIndex = 325;
            this.label12.Text = "Barcode No 2:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(609, 3);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(60, 18);
            this.label7.TabIndex = 324;
            this.label7.Text = "Amount:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(515, 3);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(39, 18);
            this.label6.TabIndex = 323;
            this.label6.Text = "Unit:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(452, 3);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(34, 18);
            this.label5.TabIndex = 322;
            this.label5.Text = "Qty:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(361, 3);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(75, 18);
            this.label4.TabIndex = 321;
            this.label4.Text = "Unit Price:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(106, 3);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(84, 18);
            this.label11.TabIndex = 320;
            this.label11.Text = "Items Name:";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(1, 3);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(83, 18);
            this.label13.TabIndex = 318;
            this.label13.Text = "Barcode No:";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.SystemColors.Control;
            this.panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel8.Controls.Add(this.label10);
            this.panel8.Location = new System.Drawing.Point(469, 5);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(86, 30);
            this.panel8.TabIndex = 371;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(2, 6);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(82, 16);
            this.label10.TabIndex = 327;
            this.label10.Text = "Saleman Nme:";
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.SystemColors.Control;
            this.panel9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel9.Controls.Add(this.label2);
            this.panel9.Location = new System.Drawing.Point(5, 40);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(75, 30);
            this.panel9.TabIndex = 379;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(1, 6);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(75, 16);
            this.label2.TabIndex = 325;
            this.label2.Text = "Transaction:";
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.SystemColors.Control;
            this.panel10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel10.Controls.Add(this.label3);
            this.panel10.Location = new System.Drawing.Point(223, 40);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(95, 30);
            this.panel10.TabIndex = 381;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(0, 6);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(95, 16);
            this.label3.TabIndex = 325;
            this.label3.Text = "Customer Name:";
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.SystemColors.Control;
            this.panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel7.Controls.Add(this.label9);
            this.panel7.Location = new System.Drawing.Point(223, 5);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(96, 30);
            this.panel7.TabIndex = 370;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(7, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(79, 16);
            this.label9.TabIndex = 326;
            this.label9.Text = "Invoice Date:";
            // 
            // panel21
            // 
            this.panel21.BackColor = System.Drawing.Color.Transparent;
            this.panel21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel21.Controls.Add(this.btnupdate);
            this.panel21.Controls.Add(this.btnLoadTransaction);
            this.panel21.Controls.Add(this.btnHoldTransaction);
            this.panel21.Controls.Add(this.btnRate);
            this.panel21.Controls.Add(this.btnChangeQty);
            this.panel21.Controls.Add(this.btnLogout);
            this.panel21.Controls.Add(this.btnBulkProduct);
            this.panel21.Controls.Add(this.btnOpenCashDrawer);
            this.panel21.Controls.Add(this.btnTouchscreen);
            this.panel21.Controls.Add(this.button5);
            this.panel21.Controls.Add(this.button4);
            this.panel21.Controls.Add(this.button3);
            this.panel21.Controls.Add(this.button2);
            this.panel21.Controls.Add(this.button1);
            this.panel21.Controls.Add(this.dataGridView1);
            this.panel21.Controls.Add(this.label30);
            this.panel21.Controls.Add(this.label29);
            this.panel21.Controls.Add(this.panel28);
            this.panel21.Controls.Add(this.panel44);
            this.panel21.Controls.Add(this.dataGridView2);
            this.panel21.Controls.Add(this.btn_close);
            this.panel21.Controls.Add(this.btn_remove);
            this.panel21.Controls.Add(this.Btn_clear);
            this.panel21.Controls.Add(this.Btn_savePrint);
            this.panel21.Controls.Add(this.btn_bank);
            this.panel21.Controls.Add(this.btn_wallet);
            this.panel21.Controls.Add(this.btn_credit);
            this.panel21.Controls.Add(this.Btn_Cash);
            this.panel21.Controls.Add(this.Btn_100);
            this.panel21.Controls.Add(this.Btn_0);
            this.panel21.Controls.Add(this.Btn_Dot);
            this.panel21.Controls.Add(this.Btn_ten);
            this.panel21.Controls.Add(this.Btn_50);
            this.panel21.Controls.Add(this.Btn_9);
            this.panel21.Controls.Add(this.Btn_8);
            this.panel21.Controls.Add(this.Btn_7);
            this.panel21.Controls.Add(this.Btn_20);
            this.panel21.Controls.Add(this.Btn_6);
            this.panel21.Controls.Add(this.Btn_5);
            this.panel21.Controls.Add(this.Btn_4);
            this.panel21.Controls.Add(this.Btn_10);
            this.panel21.Controls.Add(this.Btn_3);
            this.panel21.Controls.Add(this.Btn_2);
            this.panel21.Controls.Add(this.Btn_1);
            this.panel21.Controls.Add(this.txt_cus_mob);
            this.panel21.Controls.Add(this.combo_Store);
            this.panel21.Controls.Add(this.combo_Unit);
            this.panel21.Controls.Add(this.combo_Servername);
            this.panel21.Controls.Add(this.combo_Pricinglevel);
            this.panel21.Controls.Add(this.bunifuImageButton3);
            this.panel21.Controls.Add(this.bunifuImageButton2);
            this.panel21.Controls.Add(this.txtCus_ID);
            this.panel21.Controls.Add(this.combo_Currency);
            this.panel21.Controls.Add(this.txt_pro_code);
            this.panel21.Controls.Add(this.bunifuImageButton4);
            this.panel21.Controls.Add(this.txtCustomerName);
            this.panel21.Controls.Add(this.panel18);
            this.panel21.Controls.Add(this.panel24);
            this.panel21.Controls.Add(this.btn_add);
            this.panel21.Controls.Add(this.panel27);
            this.panel21.Controls.Add(this.btnperview);
            this.panel21.Controls.Add(this.btnprint);
            this.panel21.Controls.Add(this.btndel);
            this.panel21.Controls.Add(this.btnget);
            this.panel21.Controls.Add(this.btn_save);
            this.panel21.Controls.Add(this.btnnew);
            this.panel21.Controls.Add(this.txt_amount);
            this.panel21.Controls.Add(this.txt_qty);
            this.panel21.Controls.Add(this.txt_price);
            this.panel21.Controls.Add(this.txt_Barcode2);
            this.panel21.Controls.Add(this.txt_pro_name);
            this.panel21.Controls.Add(this.txt_barcode);
            this.panel21.Controls.Add(this.combo_bil_type);
            this.panel21.Controls.Add(this.combo_salesman);
            this.panel21.Controls.Add(this.dateTimePicker1);
            this.panel21.Controls.Add(this.txt_invoice_no);
            this.panel21.Controls.Add(this.bunifuImageButton1);
            this.panel21.Controls.Add(this.bunifuImageButton10);
            this.panel21.Controls.Add(this.panel12);
            this.panel21.Controls.Add(this.panel11);
            this.panel21.Controls.Add(this.panel10);
            this.panel21.Controls.Add(this.panel9);
            this.panel21.Controls.Add(this.panel8);
            this.panel21.Controls.Add(this.panel7);
            this.panel21.Controls.Add(this.panel5);
            this.panel21.Controls.Add(this.lblUser);
            this.panel21.Controls.Add(this.txtCustomerID);
            this.panel21.Controls.Add(this.txtinvoice);
            this.panel21.Location = new System.Drawing.Point(10, 38);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(712, 652);
            this.panel21.TabIndex = 390;
            // 
            // btnupdate
            // 
            this.btnupdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnupdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnupdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnupdate.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnupdate.ForeColor = System.Drawing.Color.Black;
            this.btnupdate.Image = ((System.Drawing.Image)(resources.GetObject("btnupdate.Image")));
            this.btnupdate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnupdate.Location = new System.Drawing.Point(218, 568);
            this.btnupdate.Name = "btnupdate";
            this.btnupdate.Size = new System.Drawing.Size(70, 36);
            this.btnupdate.TabIndex = 971;
            this.btnupdate.Text = "   Update";
            this.btnupdate.UseVisualStyleBackColor = false;
            // 
            // btnLoadTransaction
            // 
            this.btnLoadTransaction.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnLoadTransaction.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLoadTransaction.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLoadTransaction.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Bold);
            this.btnLoadTransaction.ForeColor = System.Drawing.Color.Black;
            this.btnLoadTransaction.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLoadTransaction.Location = new System.Drawing.Point(585, 605);
            this.btnLoadTransaction.Name = "btnLoadTransaction";
            this.btnLoadTransaction.Size = new System.Drawing.Size(121, 40);
            this.btnLoadTransaction.TabIndex = 970;
            this.btnLoadTransaction.Text = "Load Transaction";
            this.btnLoadTransaction.UseVisualStyleBackColor = false;
            // 
            // btnHoldTransaction
            // 
            this.btnHoldTransaction.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnHoldTransaction.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnHoldTransaction.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnHoldTransaction.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Bold);
            this.btnHoldTransaction.ForeColor = System.Drawing.Color.Black;
            this.btnHoldTransaction.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnHoldTransaction.Location = new System.Drawing.Point(459, 605);
            this.btnHoldTransaction.Name = "btnHoldTransaction";
            this.btnHoldTransaction.Size = new System.Drawing.Size(125, 40);
            this.btnHoldTransaction.TabIndex = 969;
            this.btnHoldTransaction.Text = "Hold Transaction";
            this.btnHoldTransaction.UseVisualStyleBackColor = false;
            // 
            // btnRate
            // 
            this.btnRate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnRate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnRate.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Bold);
            this.btnRate.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnRate.Location = new System.Drawing.Point(360, 605);
            this.btnRate.Name = "btnRate";
            this.btnRate.Size = new System.Drawing.Size(98, 40);
            this.btnRate.TabIndex = 968;
            this.btnRate.Text = "Change Rate";
            this.btnRate.UseVisualStyleBackColor = false;
            // 
            // btnChangeQty
            // 
            this.btnChangeQty.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnChangeQty.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnChangeQty.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Bold);
            this.btnChangeQty.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnChangeQty.Location = new System.Drawing.Point(289, 605);
            this.btnChangeQty.Name = "btnChangeQty";
            this.btnChangeQty.Size = new System.Drawing.Size(70, 40);
            this.btnChangeQty.TabIndex = 966;
            this.btnChangeQty.Text = "Change Qty";
            this.btnChangeQty.UseVisualStyleBackColor = false;
            // 
            // btnLogout
            // 
            this.btnLogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnLogout.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnLogout.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLogout.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Bold);
            this.btnLogout.ForeColor = System.Drawing.Color.Black;
            this.btnLogout.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnLogout.Location = new System.Drawing.Point(218, 605);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(70, 40);
            this.btnLogout.TabIndex = 965;
            this.btnLogout.Text = "Logout";
            this.btnLogout.UseVisualStyleBackColor = false;
            // 
            // btnBulkProduct
            // 
            this.btnBulkProduct.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnBulkProduct.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBulkProduct.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnBulkProduct.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Bold);
            this.btnBulkProduct.ForeColor = System.Drawing.Color.Black;
            this.btnBulkProduct.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBulkProduct.Location = new System.Drawing.Point(147, 605);
            this.btnBulkProduct.Name = "btnBulkProduct";
            this.btnBulkProduct.Size = new System.Drawing.Size(70, 40);
            this.btnBulkProduct.TabIndex = 964;
            this.btnBulkProduct.Text = "Bulk Product";
            this.btnBulkProduct.UseVisualStyleBackColor = false;
            // 
            // btnOpenCashDrawer
            // 
            this.btnOpenCashDrawer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnOpenCashDrawer.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnOpenCashDrawer.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOpenCashDrawer.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Bold);
            this.btnOpenCashDrawer.ForeColor = System.Drawing.Color.Black;
            this.btnOpenCashDrawer.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOpenCashDrawer.Location = new System.Drawing.Point(76, 605);
            this.btnOpenCashDrawer.Name = "btnOpenCashDrawer";
            this.btnOpenCashDrawer.Size = new System.Drawing.Size(70, 40);
            this.btnOpenCashDrawer.TabIndex = 963;
            this.btnOpenCashDrawer.Text = "Open Cash Drawer";
            this.btnOpenCashDrawer.UseVisualStyleBackColor = false;
            // 
            // btnTouchscreen
            // 
            this.btnTouchscreen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.btnTouchscreen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnTouchscreen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTouchscreen.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Bold);
            this.btnTouchscreen.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnTouchscreen.Location = new System.Drawing.Point(5, 605);
            this.btnTouchscreen.Name = "btnTouchscreen";
            this.btnTouchscreen.Size = new System.Drawing.Size(70, 40);
            this.btnTouchscreen.TabIndex = 962;
            this.btnTouchscreen.Text = "Touch Screen";
            this.btnTouchscreen.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button5.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button5.Location = new System.Drawing.Point(289, 339);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(70, 40);
            this.button5.TabIndex = 959;
            this.button5.Text = "Bill Notes";
            this.button5.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button4.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button4.Location = new System.Drawing.Point(218, 339);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(70, 40);
            this.button4.TabIndex = 958;
            this.button4.Text = "Bill Discount";
            this.button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.Location = new System.Drawing.Point(147, 339);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(70, 40);
            this.button3.TabIndex = 957;
            this.button3.Text = "Bill Reprint";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(76, 339);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(70, 40);
            this.button2.TabIndex = 956;
            this.button2.Text = "Delete Row";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Trebuchet MS", 6.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(5, 339);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(70, 40);
            this.button1.TabIndex = 955;
            this.button1.Text = "Lock Screen";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Transparent;
            this.label30.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label30.Location = new System.Drawing.Point(523, 349);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(91, 18);
            this.label30.TabIndex = 954;
            this.label30.Text = "Change Here:";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.BackColor = System.Drawing.Color.Transparent;
            this.label29.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.label29.Location = new System.Drawing.Point(362, 349);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(67, 18);
            this.label29.TabIndex = 952;
            this.label29.Text = "Total Pay:";
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.Gainsboro;
            this.panel28.Controls.Add(this.textBox1);
            this.panel28.Location = new System.Drawing.Point(616, 344);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(90, 29);
            this.panel28.TabIndex = 953;
            // 
            // textBox1
            // 
            this.textBox1.BackColor = System.Drawing.Color.White;
            this.textBox1.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.textBox1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.textBox1.Location = new System.Drawing.Point(2, 2);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(86, 25);
            this.textBox1.TabIndex = 0;
            this.textBox1.Text = "0.000";
            // 
            // panel44
            // 
            this.panel44.BackColor = System.Drawing.Color.Gainsboro;
            this.panel44.Controls.Add(this.txt_Address2);
            this.panel44.Location = new System.Drawing.Point(432, 344);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(90, 29);
            this.panel44.TabIndex = 951;
            // 
            // txt_Address2
            // 
            this.txt_Address2.BackColor = System.Drawing.Color.White;
            this.txt_Address2.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_Address2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_Address2.Location = new System.Drawing.Point(2, 2);
            this.txt_Address2.Name = "txt_Address2";
            this.txt_Address2.Size = new System.Drawing.Size(86, 25);
            this.txt_Address2.TabIndex = 0;
            this.txt_Address2.Text = "0.000";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            dataGridViewCellStyle4.BackColor = System.Drawing.Color.OldLace;
            this.dataGridView2.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView2.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle5.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.Color.LightSteelBlue;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle5;
            this.dataGridView2.ColumnHeadersHeight = 24;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Paymode,
            this.Amount,
            this.CTYpe});
            this.dataGridView2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.dataGridView2.EnableHeadersVisualStyles = false;
            this.dataGridView2.GridColor = System.Drawing.Color.White;
            this.dataGridView2.Location = new System.Drawing.Point(431, 380);
            this.dataGridView2.MultiSelect = false;
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Single;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.Color.Orange;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dataGridView2.RowHeadersWidth = 25;
            this.dataGridView2.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridViewCellStyle7.BackColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.Color.White;
            this.dataGridView2.RowsDefaultCellStyle = dataGridViewCellStyle7;
            this.dataGridView2.RowTemplate.Height = 18;
            this.dataGridView2.RowTemplate.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.ScrollBars = System.Windows.Forms.ScrollBars.Horizontal;
            this.dataGridView2.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView2.Size = new System.Drawing.Size(275, 187);
            this.dataGridView2.TabIndex = 950;
            // 
            // Paymode
            // 
            this.Paymode.HeaderText = "P.Mode";
            this.Paymode.Name = "Paymode";
            this.Paymode.ReadOnly = true;
            // 
            // Amount
            // 
            this.Amount.HeaderText = "Amount";
            this.Amount.Name = "Amount";
            this.Amount.ReadOnly = true;
            // 
            // CTYpe
            // 
            this.CTYpe.HeaderText = "C.Type";
            this.CTYpe.Name = "CTYpe";
            this.CTYpe.ReadOnly = true;
            // 
            // btn_close
            // 
            this.btn_close.BackColor = System.Drawing.Color.NavajoWhite;
            this.btn_close.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_close.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_close.Location = new System.Drawing.Point(360, 521);
            this.btn_close.Name = "btn_close";
            this.btn_close.Size = new System.Drawing.Size(70, 46);
            this.btn_close.TabIndex = 949;
            this.btn_close.Text = "Close";
            this.btn_close.UseVisualStyleBackColor = false;
            // 
            // btn_remove
            // 
            this.btn_remove.BackColor = System.Drawing.Color.White;
            this.btn_remove.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_remove.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_remove.Location = new System.Drawing.Point(360, 474);
            this.btn_remove.Name = "btn_remove";
            this.btn_remove.Size = new System.Drawing.Size(70, 46);
            this.btn_remove.TabIndex = 948;
            this.btn_remove.Text = "Remove";
            this.btn_remove.UseVisualStyleBackColor = false;
            // 
            // Btn_clear
            // 
            this.Btn_clear.BackColor = System.Drawing.Color.White;
            this.Btn_clear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_clear.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.Btn_clear.Location = new System.Drawing.Point(360, 427);
            this.Btn_clear.Name = "Btn_clear";
            this.Btn_clear.Size = new System.Drawing.Size(70, 46);
            this.Btn_clear.TabIndex = 947;
            this.Btn_clear.Text = "Clear";
            this.Btn_clear.UseVisualStyleBackColor = false;
            // 
            // Btn_savePrint
            // 
            this.Btn_savePrint.BackColor = System.Drawing.Color.White;
            this.Btn_savePrint.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_savePrint.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_savePrint.Location = new System.Drawing.Point(360, 380);
            this.Btn_savePrint.Name = "Btn_savePrint";
            this.Btn_savePrint.Size = new System.Drawing.Size(70, 46);
            this.Btn_savePrint.TabIndex = 946;
            this.Btn_savePrint.Text = "Save + Print";
            this.Btn_savePrint.UseVisualStyleBackColor = false;
            // 
            // btn_bank
            // 
            this.btn_bank.BackColor = System.Drawing.Color.White;
            this.btn_bank.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_bank.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_bank.Location = new System.Drawing.Point(5, 521);
            this.btn_bank.Name = "btn_bank";
            this.btn_bank.Size = new System.Drawing.Size(70, 46);
            this.btn_bank.TabIndex = 945;
            this.btn_bank.Text = "Bank";
            this.btn_bank.UseVisualStyleBackColor = false;
            // 
            // btn_wallet
            // 
            this.btn_wallet.BackColor = System.Drawing.Color.White;
            this.btn_wallet.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_wallet.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_wallet.Location = new System.Drawing.Point(5, 474);
            this.btn_wallet.Name = "btn_wallet";
            this.btn_wallet.Size = new System.Drawing.Size(70, 46);
            this.btn_wallet.TabIndex = 944;
            this.btn_wallet.Text = "Wellet";
            this.btn_wallet.UseVisualStyleBackColor = false;
            // 
            // btn_credit
            // 
            this.btn_credit.BackColor = System.Drawing.Color.White;
            this.btn_credit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_credit.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.btn_credit.Location = new System.Drawing.Point(5, 427);
            this.btn_credit.Name = "btn_credit";
            this.btn_credit.Size = new System.Drawing.Size(70, 46);
            this.btn_credit.TabIndex = 943;
            this.btn_credit.Text = "Credit";
            this.btn_credit.UseVisualStyleBackColor = false;
            // 
            // Btn_Cash
            // 
            this.Btn_Cash.BackColor = System.Drawing.Color.White;
            this.Btn_Cash.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Cash.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold);
            this.Btn_Cash.Location = new System.Drawing.Point(5, 380);
            this.Btn_Cash.Name = "Btn_Cash";
            this.Btn_Cash.Size = new System.Drawing.Size(70, 46);
            this.Btn_Cash.TabIndex = 942;
            this.Btn_Cash.Text = "Cash";
            this.Btn_Cash.UseVisualStyleBackColor = false;
            // 
            // Btn_100
            // 
            this.Btn_100.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_100.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_100.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.Btn_100.Location = new System.Drawing.Point(289, 521);
            this.Btn_100.Name = "Btn_100";
            this.Btn_100.Size = new System.Drawing.Size(70, 46);
            this.Btn_100.TabIndex = 941;
            this.Btn_100.Text = "100";
            this.Btn_100.UseVisualStyleBackColor = false;
            // 
            // Btn_0
            // 
            this.Btn_0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_0.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_0.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.Btn_0.Location = new System.Drawing.Point(218, 521);
            this.Btn_0.Name = "Btn_0";
            this.Btn_0.Size = new System.Drawing.Size(70, 46);
            this.Btn_0.TabIndex = 940;
            this.Btn_0.Text = "0";
            this.Btn_0.UseVisualStyleBackColor = false;
            // 
            // Btn_Dot
            // 
            this.Btn_Dot.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_Dot.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_Dot.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.Btn_Dot.Location = new System.Drawing.Point(147, 521);
            this.Btn_Dot.Name = "Btn_Dot";
            this.Btn_Dot.Size = new System.Drawing.Size(70, 46);
            this.Btn_Dot.TabIndex = 939;
            this.Btn_Dot.Text = ".";
            this.Btn_Dot.UseVisualStyleBackColor = false;
            // 
            // Btn_ten
            // 
            this.Btn_ten.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_ten.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_ten.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.Btn_ten.Location = new System.Drawing.Point(76, 521);
            this.Btn_ten.Name = "Btn_ten";
            this.Btn_ten.Size = new System.Drawing.Size(70, 46);
            this.Btn_ten.TabIndex = 938;
            this.Btn_ten.Text = "x";
            this.Btn_ten.UseVisualStyleBackColor = false;
            // 
            // Btn_50
            // 
            this.Btn_50.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_50.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_50.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.Btn_50.Location = new System.Drawing.Point(289, 474);
            this.Btn_50.Name = "Btn_50";
            this.Btn_50.Size = new System.Drawing.Size(70, 46);
            this.Btn_50.TabIndex = 937;
            this.Btn_50.Text = "50";
            this.Btn_50.UseVisualStyleBackColor = false;
            // 
            // Btn_9
            // 
            this.Btn_9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_9.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_9.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.Btn_9.Location = new System.Drawing.Point(218, 474);
            this.Btn_9.Name = "Btn_9";
            this.Btn_9.Size = new System.Drawing.Size(70, 46);
            this.Btn_9.TabIndex = 936;
            this.Btn_9.Text = "9";
            this.Btn_9.UseVisualStyleBackColor = false;
            // 
            // Btn_8
            // 
            this.Btn_8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_8.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_8.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.Btn_8.Location = new System.Drawing.Point(147, 474);
            this.Btn_8.Name = "Btn_8";
            this.Btn_8.Size = new System.Drawing.Size(70, 46);
            this.Btn_8.TabIndex = 935;
            this.Btn_8.Text = "8";
            this.Btn_8.UseVisualStyleBackColor = false;
            // 
            // Btn_7
            // 
            this.Btn_7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_7.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.Btn_7.Location = new System.Drawing.Point(76, 474);
            this.Btn_7.Name = "Btn_7";
            this.Btn_7.Size = new System.Drawing.Size(70, 46);
            this.Btn_7.TabIndex = 934;
            this.Btn_7.Text = "7";
            this.Btn_7.UseVisualStyleBackColor = false;
            // 
            // Btn_20
            // 
            this.Btn_20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_20.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_20.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.Btn_20.Location = new System.Drawing.Point(289, 427);
            this.Btn_20.Name = "Btn_20";
            this.Btn_20.Size = new System.Drawing.Size(70, 46);
            this.Btn_20.TabIndex = 933;
            this.Btn_20.Text = "20";
            this.Btn_20.UseVisualStyleBackColor = false;
            // 
            // Btn_6
            // 
            this.Btn_6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_6.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.Btn_6.Location = new System.Drawing.Point(218, 427);
            this.Btn_6.Name = "Btn_6";
            this.Btn_6.Size = new System.Drawing.Size(70, 46);
            this.Btn_6.TabIndex = 932;
            this.Btn_6.Text = "6";
            this.Btn_6.UseVisualStyleBackColor = false;
            // 
            // Btn_5
            // 
            this.Btn_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_5.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.Btn_5.Location = new System.Drawing.Point(147, 427);
            this.Btn_5.Name = "Btn_5";
            this.Btn_5.Size = new System.Drawing.Size(70, 46);
            this.Btn_5.TabIndex = 931;
            this.Btn_5.Text = "5";
            this.Btn_5.UseVisualStyleBackColor = false;
            // 
            // Btn_4
            // 
            this.Btn_4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_4.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.Btn_4.Location = new System.Drawing.Point(76, 427);
            this.Btn_4.Name = "Btn_4";
            this.Btn_4.Size = new System.Drawing.Size(70, 46);
            this.Btn_4.TabIndex = 930;
            this.Btn_4.Text = "4";
            this.Btn_4.UseVisualStyleBackColor = false;
            // 
            // Btn_10
            // 
            this.Btn_10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_10.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_10.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.Btn_10.Location = new System.Drawing.Point(289, 380);
            this.Btn_10.Name = "Btn_10";
            this.Btn_10.Size = new System.Drawing.Size(70, 46);
            this.Btn_10.TabIndex = 929;
            this.Btn_10.Text = "10";
            this.Btn_10.UseVisualStyleBackColor = false;
            // 
            // Btn_3
            // 
            this.Btn_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_3.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.Btn_3.Location = new System.Drawing.Point(218, 380);
            this.Btn_3.Name = "Btn_3";
            this.Btn_3.Size = new System.Drawing.Size(70, 46);
            this.Btn_3.TabIndex = 928;
            this.Btn_3.Text = "3";
            this.Btn_3.UseVisualStyleBackColor = false;
            // 
            // Btn_2
            // 
            this.Btn_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_2.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold);
            this.Btn_2.Location = new System.Drawing.Point(147, 380);
            this.Btn_2.Name = "Btn_2";
            this.Btn_2.Size = new System.Drawing.Size(70, 46);
            this.Btn_2.TabIndex = 927;
            this.Btn_2.Text = "2";
            this.Btn_2.UseVisualStyleBackColor = false;
            // 
            // Btn_1
            // 
            this.Btn_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.Btn_1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_1.Font = new System.Drawing.Font("Trebuchet MS", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_1.Location = new System.Drawing.Point(76, 380);
            this.Btn_1.Name = "Btn_1";
            this.Btn_1.Size = new System.Drawing.Size(70, 46);
            this.Btn_1.TabIndex = 926;
            this.Btn_1.Text = "1";
            this.Btn_1.UseVisualStyleBackColor = false;
            // 
            // txt_cus_mob
            // 
            this.txt_cus_mob.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txt_cus_mob.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_cus_mob.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_cus_mob.Location = new System.Drawing.Point(317, 232);
            this.txt_cus_mob.Name = "txt_cus_mob";
            this.txt_cus_mob.Size = new System.Drawing.Size(128, 30);
            this.txt_cus_mob.TabIndex = 893;
            // 
            // combo_Store
            // 
            this.combo_Store.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_Store.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_Store.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_Store.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.combo_Store.FormattingEnabled = true;
            this.combo_Store.Location = new System.Drawing.Point(554, 40);
            this.combo_Store.Name = "combo_Store";
            this.combo_Store.Size = new System.Drawing.Size(130, 30);
            this.combo_Store.TabIndex = 892;
            this.combo_Store.Text = "- Select Store-";
            // 
            // combo_Unit
            // 
            this.combo_Unit.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_Unit.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_Unit.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_Unit.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.combo_Unit.FormattingEnabled = true;
            this.combo_Unit.Location = new System.Drawing.Point(522, 139);
            this.combo_Unit.Name = "combo_Unit";
            this.combo_Unit.Size = new System.Drawing.Size(92, 30);
            this.combo_Unit.TabIndex = 891;
            // 
            // combo_Servername
            // 
            this.combo_Servername.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_Servername.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_Servername.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_Servername.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.combo_Servername.FormattingEnabled = true;
            this.combo_Servername.Location = new System.Drawing.Point(554, 75);
            this.combo_Servername.Name = "combo_Servername";
            this.combo_Servername.Size = new System.Drawing.Size(130, 30);
            this.combo_Servername.TabIndex = 889;
            this.combo_Servername.Text = "- Select Server-";
            // 
            // combo_Pricinglevel
            // 
            this.combo_Pricinglevel.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_Pricinglevel.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_Pricinglevel.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_Pricinglevel.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.combo_Pricinglevel.FormattingEnabled = true;
            this.combo_Pricinglevel.Location = new System.Drawing.Point(317, 75);
            this.combo_Pricinglevel.Name = "combo_Pricinglevel";
            this.combo_Pricinglevel.Size = new System.Drawing.Size(128, 30);
            this.combo_Pricinglevel.TabIndex = 888;
            this.combo_Pricinglevel.Text = "- Select PriceLevel-";
            // 
            // bunifuImageButton3
            // 
            this.bunifuImageButton3.BackColor = System.Drawing.Color.DimGray;
            this.bunifuImageButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton3.Image")));
            this.bunifuImageButton3.ImageActive = null;
            this.bunifuImageButton3.Location = new System.Drawing.Point(684, 75);
            this.bunifuImageButton3.Name = "bunifuImageButton3";
            this.bunifuImageButton3.Size = new System.Drawing.Size(23, 30);
            this.bunifuImageButton3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton3.TabIndex = 887;
            this.bunifuImageButton3.TabStop = false;
            this.bunifuImageButton3.Zoom = 10;
            // 
            // bunifuImageButton2
            // 
            this.bunifuImageButton2.BackColor = System.Drawing.Color.DimGray;
            this.bunifuImageButton2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton2.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton2.Image")));
            this.bunifuImageButton2.ImageActive = null;
            this.bunifuImageButton2.Location = new System.Drawing.Point(684, 40);
            this.bunifuImageButton2.Name = "bunifuImageButton2";
            this.bunifuImageButton2.Size = new System.Drawing.Size(23, 30);
            this.bunifuImageButton2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton2.TabIndex = 879;
            this.bunifuImageButton2.TabStop = false;
            this.bunifuImageButton2.Zoom = 10;
            // 
            // txtCus_ID
            // 
            this.txtCus_ID.Location = new System.Drawing.Point(176, 251);
            this.txtCus_ID.Name = "txtCus_ID";
            this.txtCus_ID.Size = new System.Drawing.Size(70, 20);
            this.txtCus_ID.TabIndex = 878;
            this.txtCus_ID.Visible = false;
            // 
            // combo_Currency
            // 
            this.combo_Currency.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_Currency.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_Currency.Font = new System.Drawing.Font("Trebuchet MS", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_Currency.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.combo_Currency.FormattingEnabled = true;
            this.combo_Currency.Location = new System.Drawing.Point(79, 75);
            this.combo_Currency.Name = "combo_Currency";
            this.combo_Currency.Size = new System.Drawing.Size(145, 30);
            this.combo_Currency.TabIndex = 884;
            this.combo_Currency.Text = "- Select Currency-";
            // 
            // txt_pro_code
            // 
            this.txt_pro_code.Location = new System.Drawing.Point(487, 318);
            this.txt_pro_code.Name = "txt_pro_code";
            this.txt_pro_code.Size = new System.Drawing.Size(70, 20);
            this.txt_pro_code.TabIndex = 877;
            this.txt_pro_code.Visible = false;
            // 
            // bunifuImageButton4
            // 
            this.bunifuImageButton4.BackColor = System.Drawing.Color.DimGray;
            this.bunifuImageButton4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton4.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton4.Image")));
            this.bunifuImageButton4.ImageActive = null;
            this.bunifuImageButton4.Location = new System.Drawing.Point(445, 75);
            this.bunifuImageButton4.Name = "bunifuImageButton4";
            this.bunifuImageButton4.Size = new System.Drawing.Size(23, 30);
            this.bunifuImageButton4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton4.TabIndex = 883;
            this.bunifuImageButton4.TabStop = false;
            this.bunifuImageButton4.Zoom = 10;
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.txtCustomerName.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txtCustomerName.Location = new System.Drawing.Point(317, 40);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(128, 30);
            this.txtCustomerName.TabIndex = 874;
            // 
            // panel18
            // 
            this.panel18.BackColor = System.Drawing.SystemColors.Control;
            this.panel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel18.Controls.Add(this.label20);
            this.panel18.Location = new System.Drawing.Point(468, 75);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(88, 30);
            this.panel18.TabIndex = 882;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.Black;
            this.label20.Location = new System.Drawing.Point(5, 6);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(80, 16);
            this.label20.TabIndex = 327;
            this.label20.Text = "Server Name:";
            // 
            // panel24
            // 
            this.panel24.BackColor = System.Drawing.SystemColors.Control;
            this.panel24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel24.Controls.Add(this.label25);
            this.panel24.Location = new System.Drawing.Point(223, 75);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(95, 30);
            this.panel24.TabIndex = 881;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.Black;
            this.label25.Location = new System.Drawing.Point(6, 6);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(81, 16);
            this.label25.TabIndex = 325;
            this.label25.Text = "Pricing Level:";
            // 
            // panel27
            // 
            this.panel27.BackColor = System.Drawing.SystemColors.Control;
            this.panel27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel27.Controls.Add(this.label27);
            this.panel27.Location = new System.Drawing.Point(5, 75);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(75, 30);
            this.panel27.TabIndex = 880;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.Black;
            this.label27.Location = new System.Drawing.Point(5, 6);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(64, 16);
            this.label27.TabIndex = 325;
            this.label27.Text = "Currency:";
            // 
            // btnnew
            // 
            this.btnnew.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnnew.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnnew.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnnew.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold);
            this.btnnew.Image = ((System.Drawing.Image)(resources.GetObject("btnnew.Image")));
            this.btnnew.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnnew.Location = new System.Drawing.Point(5, 568);
            this.btnnew.Name = "btnnew";
            this.btnnew.Size = new System.Drawing.Size(70, 36);
            this.btnnew.TabIndex = 859;
            this.btnnew.Text = "&New";
            this.btnnew.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnnew.UseVisualStyleBackColor = false;
            this.btnnew.Click += new System.EventHandler(this.btn_new_Click);
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.SystemColors.Control;
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.label8);
            this.panel5.Location = new System.Drawing.Point(5, 5);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(75, 30);
            this.panel5.TabIndex = 368;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(4, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(66, 16);
            this.label8.TabIndex = 325;
            this.label8.Text = "Invoce No:";
            // 
            // lblUser
            // 
            this.lblUser.AutoSize = true;
            this.lblUser.Location = new System.Drawing.Point(436, 290);
            this.lblUser.Name = "lblUser";
            this.lblUser.Size = new System.Drawing.Size(39, 13);
            this.lblUser.TabIndex = 873;
            this.lblUser.Text = "Label8";
            this.lblUser.Visible = false;
            // 
            // txtCustomerID
            // 
            this.txtCustomerID.BackColor = System.Drawing.SystemColors.Control;
            this.txtCustomerID.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCustomerID.Location = new System.Drawing.Point(306, 290);
            this.txtCustomerID.Name = "txtCustomerID";
            this.txtCustomerID.ReadOnly = true;
            this.txtCustomerID.Size = new System.Drawing.Size(98, 21);
            this.txtCustomerID.TabIndex = 875;
            // 
            // txtinvoice
            // 
            this.txtinvoice.Location = new System.Drawing.Point(487, 251);
            this.txtinvoice.Name = "txtinvoice";
            this.txtinvoice.Size = new System.Drawing.Size(70, 20);
            this.txtinvoice.TabIndex = 876;
            this.txtinvoice.Visible = false;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Blue;
            this.panel3.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel3.Location = new System.Drawing.Point(0, 31);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(5, 665);
            this.panel3.TabIndex = 392;
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Blue;
            this.panel6.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel6.Location = new System.Drawing.Point(995, 31);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(5, 665);
            this.panel6.TabIndex = 393;
            // 
            // Saleproduct
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(1000, 701);
            this.Controls.Add(this.panel6);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel22);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel21);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.KeyPreview = true;
            this.Name = "Saleproduct";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Saleproduct";
            this.Activated += new System.EventHandler(this.Saleproduct_Activated);
            this.Load += new System.EventHandler(this.Saleproduct_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Saleproduct_KeyDown);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel22.ResumeLayout(false);
            this.panel22.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel30.ResumeLayout(false);
            this.panel30.PerformLayout();
            this.panel29.ResumeLayout(false);
            this.panel29.PerformLayout();
            this.panel23.ResumeLayout(false);
            this.panel23.PerformLayout();
            this.panel25.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel19.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel20.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton1)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton38)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton10)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel7.ResumeLayout(false);
            this.panel7.PerformLayout();
            this.panel21.ResumeLayout(false);
            this.panel21.PerformLayout();
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel44.ResumeLayout(false);
            this.panel44.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton4)).EndInit();
            this.panel18.ResumeLayout(false);
            this.panel18.PerformLayout();
            this.panel24.ResumeLayout(false);
            this.panel24.PerformLayout();
            this.panel27.ResumeLayout(false);
            this.panel27.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnperview;
        private System.Windows.Forms.Button btnprint;
        private System.Windows.Forms.Label label15;
        internal System.Windows.Forms.Button btnget;
        private System.Windows.Forms.TextBox txt_amount;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txt_qty;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.TextBox txt_price;
        private System.Windows.Forms.TextBox txt_Barcode2;
        private System.Windows.Forms.TextBox txt_pro_name;
        private System.Windows.Forms.TextBox txt_barcode;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton1;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton38;
        private System.Windows.Forms.Label label24;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton5;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton6;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton10;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Panel panel5;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel6;
        internal System.Windows.Forms.Label lblUser;
        public System.Windows.Forms.TextBox txtCustomerName;
        public System.Windows.Forms.Label lblBalance;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel26;
        public System.Windows.Forms.TextBox txtCustomerID;
        public System.Windows.Forms.TextBox txtinvoice;
        public System.Windows.Forms.Panel panel22;
        public System.Windows.Forms.Button btndel;
        public System.Windows.Forms.Button btn_add;
        public System.Windows.Forms.Button btn_save;
        public System.Windows.Forms.DataGridView dataGridView1;
        public System.Windows.Forms.TextBox txt_tax_amount;
        public System.Windows.Forms.TextBox txt_dis_amount;
        public System.Windows.Forms.TextBox txt_total_amount;
        public System.Windows.Forms.TextBox txt_comment;
        public System.Windows.Forms.TextBox txt_dues;
        public System.Windows.Forms.TextBox txt_rec_amount;
        public System.Windows.Forms.TextBox txt_new_bal;
        public System.Windows.Forms.TextBox txt_old_bal;
        public System.Windows.Forms.TextBox txt_Total;
        public System.Windows.Forms.ComboBox combo_bil_type;
        public System.Windows.Forms.ComboBox combo_salesman;
        public System.Windows.Forms.DateTimePicker dateTimePicker1;
        public System.Windows.Forms.TextBox txt_invoice_no;
        public System.Windows.Forms.TextBox txt_pro_code;
        private System.Windows.Forms.DataGridViewTextBoxColumn Productcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn Barcode;
        private System.Windows.Forms.DataGridViewTextBoxColumn Product;
        private System.Windows.Forms.DataGridViewTextBoxColumn Saleprice;
        private System.Windows.Forms.DataGridViewTextBoxColumn Quantity;
        private System.Windows.Forms.DataGridViewTextBoxColumn Unit;
        private System.Windows.Forms.DataGridViewTextBoxColumn Total;
        public System.Windows.Forms.TextBox txt_total_items;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Label label26;
        internal System.Windows.Forms.TextBox txtCus_ID;
        private System.Windows.Forms.Label label8;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton2;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton3;
        public System.Windows.Forms.ComboBox combo_Currency;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton4;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.Label label27;
        public System.Windows.Forms.ComboBox combo_Servername;
        public System.Windows.Forms.ComboBox combo_Pricinglevel;
        public System.Windows.Forms.ComboBox combo_Unit;
        public System.Windows.Forms.ComboBox combo_Store;
        public System.Windows.Forms.TextBox txt_cus_mob;
        private System.Windows.Forms.TextBox txt_greeting;
        private System.Windows.Forms.TextBox txt_footer_message;
        private System.Windows.Forms.Button btn_close;
        private System.Windows.Forms.Button btn_remove;
        private System.Windows.Forms.Button Btn_clear;
        private System.Windows.Forms.Button Btn_savePrint;
        private System.Windows.Forms.Button btn_bank;
        private System.Windows.Forms.Button btn_wallet;
        private System.Windows.Forms.Button btn_credit;
        private System.Windows.Forms.Button Btn_Cash;
        private System.Windows.Forms.Button Btn_100;
        private System.Windows.Forms.Button Btn_0;
        private System.Windows.Forms.Button Btn_Dot;
        private System.Windows.Forms.Button Btn_ten;
        private System.Windows.Forms.Button Btn_50;
        private System.Windows.Forms.Button Btn_9;
        private System.Windows.Forms.Button Btn_8;
        private System.Windows.Forms.Button Btn_7;
        private System.Windows.Forms.Button Btn_20;
        private System.Windows.Forms.Button Btn_6;
        private System.Windows.Forms.Button Btn_5;
        private System.Windows.Forms.Button Btn_4;
        private System.Windows.Forms.Button Btn_10;
        private System.Windows.Forms.Button Btn_3;
        private System.Windows.Forms.Button Btn_2;
        private System.Windows.Forms.Button Btn_1;
        internal System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Paymode;
        private System.Windows.Forms.DataGridViewTextBoxColumn Amount;
        private System.Windows.Forms.DataGridViewTextBoxColumn CTYpe;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.TextBox txt_Address2;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.TextBox textBox1;
        public System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Label label32;
        public System.Windows.Forms.ComboBox combo_PaymentMethod;
        public System.Windows.Forms.ComboBox combo_TaxType;
        public System.Windows.Forms.ComboBox combo_DiscountType;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        internal System.Windows.Forms.Button btnnew;
        public System.Windows.Forms.Button btnLoadTransaction;
        public System.Windows.Forms.Button btnHoldTransaction;
        public System.Windows.Forms.Button btnRate;
        private System.Windows.Forms.Button btnChangeQty;
        public System.Windows.Forms.Button btnLogout;
        internal System.Windows.Forms.Button btnBulkProduct;
        public System.Windows.Forms.Button btnOpenCashDrawer;
        internal System.Windows.Forms.Button btnTouchscreen;
        internal System.Windows.Forms.Button btnupdate;
    }
}