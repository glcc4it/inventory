﻿namespace Loop_Inventory
{
    partial class Item_Master
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Item_Master));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bunifuImageButton7 = new Bunifu.Framework.UI.BunifuImageButton();
            this.linkLabel1 = new System.Windows.Forms.LinkLabel();
            this.btn_delete = new System.Windows.Forms.LinkLabel();
            this.bunifuImageButton8 = new Bunifu.Framework.UI.BunifuImageButton();
            this.lnk_exprt = new System.Windows.Forms.LinkLabel();
            this.bunifuImageButton11 = new Bunifu.Framework.UI.BunifuImageButton();
            this.lnk_stock_updte = new System.Windows.Forms.LinkLabel();
            this.lnk_sve = new System.Windows.Forms.LinkLabel();
            this.bunifuImageButton12 = new Bunifu.Framework.UI.BunifuImageButton();
            this.bunifuImageButton13 = new Bunifu.Framework.UI.BunifuImageButton();
            this.lnk_sale_rpt = new System.Windows.Forms.LinkLabel();
            this.bunifuImageButton14 = new Bunifu.Framework.UI.BunifuImageButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.tcMain = new System.Windows.Forms.TabControl();
            this.Registration = new System.Windows.Forms.TabPage();
            this.txtID = new System.Windows.Forms.TextBox();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.btn_print = new System.Windows.Forms.Button();
            this.combo_search_type = new System.Windows.Forms.ComboBox();
            this.txt_search = new System.Windows.Forms.TextBox();
            this.panel37 = new System.Windows.Forms.Panel();
            this.combo_Status = new System.Windows.Forms.ComboBox();
            this.panel38 = new System.Windows.Forms.Panel();
            this.txt_AddProfit = new System.Windows.Forms.TextBox();
            this.panel35 = new System.Windows.Forms.Panel();
            this.txt_Location = new System.Windows.Forms.TextBox();
            this.panel36 = new System.Windows.Forms.Panel();
            this.txt_RetailPrice = new System.Windows.Forms.TextBox();
            this.panel33 = new System.Windows.Forms.Panel();
            this.txt_CustomerPrice = new System.Windows.Forms.TextBox();
            this.panel34 = new System.Windows.Forms.Panel();
            this.txt_PurchasePrice = new System.Windows.Forms.TextBox();
            this.panel31 = new System.Windows.Forms.Panel();
            this.txt_WholeSalePrice = new System.Windows.Forms.TextBox();
            this.panel32 = new System.Windows.Forms.Panel();
            this.combo_SellingCurrency = new System.Windows.Forms.ComboBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.combo_PurchaseCurency = new System.Windows.Forms.ComboBox();
            this.panel6 = new System.Windows.Forms.Panel();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.panel7 = new System.Windows.Forms.Panel();
            this.dateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.panel28 = new System.Windows.Forms.Panel();
            this.label26 = new System.Windows.Forms.Label();
            this.txt_ReorderLevel = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label35 = new System.Windows.Forms.Label();
            this.panel43 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.txt_TaxPercentage = new System.Windows.Forms.TextBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.txt_NextShoppingDiscount = new System.Windows.Forms.TextBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.txt_DirectDiscount = new System.Windows.Forms.TextBox();
            this.panel20 = new System.Windows.Forms.Panel();
            this.combo_DiscountType = new System.Windows.Forms.ComboBox();
            this.panel39 = new System.Windows.Forms.Panel();
            this.txt_PreferredVender = new System.Windows.Forms.TextBox();
            this.panel41 = new System.Windows.Forms.Panel();
            this.txt_CompanyProduct = new System.Windows.Forms.TextBox();
            this.panel45 = new System.Windows.Forms.Panel();
            this.txt_QtyPerUnit = new System.Windows.Forms.TextBox();
            this.panel46 = new System.Windows.Forms.Panel();
            this.txt_Description = new System.Windows.Forms.TextBox();
            this.panel47 = new System.Windows.Forms.Panel();
            this.combo_Unit = new System.Windows.Forms.ComboBox();
            this.panel48 = new System.Windows.Forms.Panel();
            this.combo_Color = new System.Windows.Forms.ComboBox();
            this.panel49 = new System.Windows.Forms.Panel();
            this.combo_Brand = new System.Windows.Forms.ComboBox();
            this.panel50 = new System.Windows.Forms.Panel();
            this.combo_Category = new System.Windows.Forms.ComboBox();
            this.panel51 = new System.Windows.Forms.Panel();
            this.combo_Store = new System.Windows.Forms.ComboBox();
            this.panel52 = new System.Windows.Forms.Panel();
            this.txt_ProductnameEng = new System.Windows.Forms.TextBox();
            this.panel53 = new System.Windows.Forms.Panel();
            this.txt_ProductnameArabic = new System.Windows.Forms.TextBox();
            this.panel54 = new System.Windows.Forms.Panel();
            this.txt_Productcode = new System.Windows.Forms.TextBox();
            this.panel55 = new System.Windows.Forms.Panel();
            this.txt_Barcode2 = new System.Windows.Forms.TextBox();
            this.panel56 = new System.Windows.Forms.Panel();
            this.txt_Barcode1 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.bunifuImageButton3 = new Bunifu.Framework.UI.BunifuImageButton();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.bunifuImageButton15 = new Bunifu.Framework.UI.BunifuImageButton();
            this.lblModalNo = new System.Windows.Forms.Label();
            this.lblUnit = new System.Windows.Forms.Label();
            this.lblGroup = new System.Windows.Forms.Label();
            this.lblBrand = new System.Windows.Forms.Label();
            this.lblProductCode = new System.Windows.Forms.Label();
            this.lblName = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton14)).BeginInit();
            this.tcMain.SuspendLayout();
            this.Registration.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel37.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel34.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel11.SuspendLayout();
            this.panel12.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel39.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel45.SuspendLayout();
            this.panel46.SuspendLayout();
            this.panel47.SuspendLayout();
            this.panel48.SuspendLayout();
            this.panel49.SuspendLayout();
            this.panel50.SuspendLayout();
            this.panel51.SuspendLayout();
            this.panel52.SuspendLayout();
            this.panel53.SuspendLayout();
            this.panel54.SuspendLayout();
            this.panel55.SuspendLayout();
            this.panel56.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton15)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1287, 31);
            this.panel1.TabIndex = 292;
            // 
            // bunifuImageButton7
            // 
            this.bunifuImageButton7.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton7.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton7.Image")));
            this.bunifuImageButton7.ImageActive = null;
            this.bunifuImageButton7.Location = new System.Drawing.Point(676, 590);
            this.bunifuImageButton7.Name = "bunifuImageButton7";
            this.bunifuImageButton7.Size = new System.Drawing.Size(35, 35);
            this.bunifuImageButton7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton7.TabIndex = 44;
            this.bunifuImageButton7.TabStop = false;
            this.bunifuImageButton7.Zoom = 10;
            // 
            // linkLabel1
            // 
            this.linkLabel1.AutoSize = true;
            this.linkLabel1.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLabel1.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.linkLabel1.LinkColor = System.Drawing.Color.White;
            this.linkLabel1.Location = new System.Drawing.Point(716, 601);
            this.linkLabel1.Name = "linkLabel1";
            this.linkLabel1.Size = new System.Drawing.Size(34, 15);
            this.linkLabel1.TabIndex = 43;
            this.linkLabel1.TabStop = true;
            this.linkLabel1.Text = "Print";
            // 
            // btn_delete
            // 
            this.btn_delete.AutoSize = true;
            this.btn_delete.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_delete.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.btn_delete.LinkColor = System.Drawing.Color.White;
            this.btn_delete.Location = new System.Drawing.Point(325, 601);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(87, 15);
            this.btn_delete.TabIndex = 34;
            this.btn_delete.TabStop = true;
            this.btn_delete.Text = "Delete Record";
            this.btn_delete.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.btn_delete_LinkClicked);
            // 
            // bunifuImageButton8
            // 
            this.bunifuImageButton8.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton8.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton8.Image")));
            this.bunifuImageButton8.ImageActive = null;
            this.bunifuImageButton8.Location = new System.Drawing.Point(285, 590);
            this.bunifuImageButton8.Name = "bunifuImageButton8";
            this.bunifuImageButton8.Size = new System.Drawing.Size(35, 35);
            this.bunifuImageButton8.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton8.TabIndex = 42;
            this.bunifuImageButton8.TabStop = false;
            this.bunifuImageButton8.Zoom = 10;
            // 
            // lnk_exprt
            // 
            this.lnk_exprt.AutoSize = true;
            this.lnk_exprt.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnk_exprt.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lnk_exprt.LinkColor = System.Drawing.Color.White;
            this.lnk_exprt.Location = new System.Drawing.Point(190, 601);
            this.lnk_exprt.Name = "lnk_exprt";
            this.lnk_exprt.Size = new System.Drawing.Size(91, 15);
            this.lnk_exprt.TabIndex = 33;
            this.lnk_exprt.TabStop = true;
            this.lnk_exprt.Text = "Update Record";
            this.lnk_exprt.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnk_exprt_LinkClicked);
            // 
            // bunifuImageButton11
            // 
            this.bunifuImageButton11.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton11.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton11.Image")));
            this.bunifuImageButton11.ImageActive = null;
            this.bunifuImageButton11.Location = new System.Drawing.Point(150, 590);
            this.bunifuImageButton11.Name = "bunifuImageButton11";
            this.bunifuImageButton11.Size = new System.Drawing.Size(35, 35);
            this.bunifuImageButton11.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton11.TabIndex = 41;
            this.bunifuImageButton11.TabStop = false;
            this.bunifuImageButton11.Zoom = 10;
            // 
            // lnk_stock_updte
            // 
            this.lnk_stock_updte.AutoSize = true;
            this.lnk_stock_updte.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnk_stock_updte.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lnk_stock_updte.LinkColor = System.Drawing.Color.White;
            this.lnk_stock_updte.Location = new System.Drawing.Point(580, 601);
            this.lnk_stock_updte.Name = "lnk_stock_updte";
            this.lnk_stock_updte.Size = new System.Drawing.Size(95, 15);
            this.lnk_stock_updte.TabIndex = 36;
            this.lnk_stock_updte.TabStop = true;
            this.lnk_stock_updte.Text = "Export to Excel ";
            this.lnk_stock_updte.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnk_stock_updte_LinkClicked);
            // 
            // lnk_sve
            // 
            this.lnk_sve.AutoSize = true;
            this.lnk_sve.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnk_sve.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lnk_sve.LinkColor = System.Drawing.Color.White;
            this.lnk_sve.Location = new System.Drawing.Point(65, 601);
            this.lnk_sve.Name = "lnk_sve";
            this.lnk_sve.Size = new System.Drawing.Size(79, 15);
            this.lnk_sve.TabIndex = 32;
            this.lnk_sve.TabStop = true;
            this.lnk_sve.Text = "Save Record";
            this.lnk_sve.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnk_sve_LinkClicked);
            // 
            // bunifuImageButton12
            // 
            this.bunifuImageButton12.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton12.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton12.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton12.Image")));
            this.bunifuImageButton12.ImageActive = null;
            this.bunifuImageButton12.Location = new System.Drawing.Point(26, 590);
            this.bunifuImageButton12.Name = "bunifuImageButton12";
            this.bunifuImageButton12.Size = new System.Drawing.Size(35, 35);
            this.bunifuImageButton12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton12.TabIndex = 38;
            this.bunifuImageButton12.TabStop = false;
            this.bunifuImageButton12.Zoom = 10;
            // 
            // bunifuImageButton13
            // 
            this.bunifuImageButton13.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton13.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton13.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton13.Image")));
            this.bunifuImageButton13.ImageActive = null;
            this.bunifuImageButton13.Location = new System.Drawing.Point(541, 590);
            this.bunifuImageButton13.Name = "bunifuImageButton13";
            this.bunifuImageButton13.Size = new System.Drawing.Size(35, 35);
            this.bunifuImageButton13.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton13.TabIndex = 40;
            this.bunifuImageButton13.TabStop = false;
            this.bunifuImageButton13.Zoom = 10;
            // 
            // lnk_sale_rpt
            // 
            this.lnk_sale_rpt.AutoSize = true;
            this.lnk_sale_rpt.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lnk_sale_rpt.LinkBehavior = System.Windows.Forms.LinkBehavior.NeverUnderline;
            this.lnk_sale_rpt.LinkColor = System.Drawing.Color.White;
            this.lnk_sale_rpt.Location = new System.Drawing.Point(455, 601);
            this.lnk_sale_rpt.Name = "lnk_sale_rpt";
            this.lnk_sale_rpt.Size = new System.Drawing.Size(81, 15);
            this.lnk_sale_rpt.TabIndex = 35;
            this.lnk_sale_rpt.TabStop = true;
            this.lnk_sale_rpt.Text = "Clear Record";
            this.lnk_sale_rpt.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.lnk_sale_rpt_LinkClicked);
            // 
            // bunifuImageButton14
            // 
            this.bunifuImageButton14.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton14.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton14.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton14.Image")));
            this.bunifuImageButton14.ImageActive = null;
            this.bunifuImageButton14.Location = new System.Drawing.Point(416, 590);
            this.bunifuImageButton14.Name = "bunifuImageButton14";
            this.bunifuImageButton14.Size = new System.Drawing.Size(35, 35);
            this.bunifuImageButton14.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.bunifuImageButton14.TabIndex = 39;
            this.bunifuImageButton14.TabStop = false;
            this.bunifuImageButton14.Zoom = 10;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.panel4.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel4.Location = new System.Drawing.Point(0, 31);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(5, 680);
            this.panel4.TabIndex = 294;
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.panel5.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel5.Location = new System.Drawing.Point(1277, 31);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(10, 680);
            this.panel5.TabIndex = 295;
            // 
            // panel10
            // 
            this.panel10.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(102)))), ((int)(((byte)(204)))));
            this.panel10.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel10.Location = new System.Drawing.Point(5, 706);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(1272, 5);
            this.panel10.TabIndex = 296;
            // 
            // tcMain
            // 
            this.tcMain.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.tcMain.Controls.Add(this.Registration);
            this.tcMain.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tcMain.Font = new System.Drawing.Font("Trebuchet MS", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tcMain.HotTrack = true;
            this.tcMain.Location = new System.Drawing.Point(5, 31);
            this.tcMain.Name = "tcMain";
            this.tcMain.SelectedIndex = 0;
            this.tcMain.Size = new System.Drawing.Size(1272, 675);
            this.tcMain.TabIndex = 297;
            this.tcMain.TabStop = false;
            // 
            // Registration
            // 
            this.Registration.BackColor = System.Drawing.Color.Lavender;
            this.Registration.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Registration.Controls.Add(this.bunifuImageButton7);
            this.Registration.Controls.Add(this.txtID);
            this.Registration.Controls.Add(this.dataGridView1);
            this.Registration.Controls.Add(this.linkLabel1);
            this.Registration.Controls.Add(this.btn_print);
            this.Registration.Controls.Add(this.combo_search_type);
            this.Registration.Controls.Add(this.btn_delete);
            this.Registration.Controls.Add(this.txt_search);
            this.Registration.Controls.Add(this.panel37);
            this.Registration.Controls.Add(this.bunifuImageButton8);
            this.Registration.Controls.Add(this.panel38);
            this.Registration.Controls.Add(this.panel35);
            this.Registration.Controls.Add(this.lnk_exprt);
            this.Registration.Controls.Add(this.panel36);
            this.Registration.Controls.Add(this.bunifuImageButton11);
            this.Registration.Controls.Add(this.panel33);
            this.Registration.Controls.Add(this.bunifuImageButton14);
            this.Registration.Controls.Add(this.panel34);
            this.Registration.Controls.Add(this.lnk_stock_updte);
            this.Registration.Controls.Add(this.panel31);
            this.Registration.Controls.Add(this.lnk_sale_rpt);
            this.Registration.Controls.Add(this.panel32);
            this.Registration.Controls.Add(this.lnk_sve);
            this.Registration.Controls.Add(this.panel3);
            this.Registration.Controls.Add(this.bunifuImageButton13);
            this.Registration.Controls.Add(this.panel6);
            this.Registration.Controls.Add(this.bunifuImageButton12);
            this.Registration.Controls.Add(this.panel7);
            this.Registration.Controls.Add(this.panel28);
            this.Registration.Controls.Add(this.panel9);
            this.Registration.Controls.Add(this.panel11);
            this.Registration.Controls.Add(this.panel12);
            this.Registration.Controls.Add(this.panel20);
            this.Registration.Controls.Add(this.panel39);
            this.Registration.Controls.Add(this.panel41);
            this.Registration.Controls.Add(this.panel45);
            this.Registration.Controls.Add(this.panel46);
            this.Registration.Controls.Add(this.panel47);
            this.Registration.Controls.Add(this.panel48);
            this.Registration.Controls.Add(this.panel49);
            this.Registration.Controls.Add(this.panel50);
            this.Registration.Controls.Add(this.panel51);
            this.Registration.Controls.Add(this.panel52);
            this.Registration.Controls.Add(this.panel53);
            this.Registration.Controls.Add(this.panel54);
            this.Registration.Controls.Add(this.panel55);
            this.Registration.Controls.Add(this.panel56);
            this.Registration.Controls.Add(this.label24);
            this.Registration.Controls.Add(this.label25);
            this.Registration.Controls.Add(this.label2);
            this.Registration.Controls.Add(this.label3);
            this.Registration.Controls.Add(this.label12);
            this.Registration.Controls.Add(this.label4);
            this.Registration.Controls.Add(this.label5);
            this.Registration.Controls.Add(this.label6);
            this.Registration.Controls.Add(this.label7);
            this.Registration.Controls.Add(this.label8);
            this.Registration.Controls.Add(this.label22);
            this.Registration.Controls.Add(this.label23);
            this.Registration.Controls.Add(this.label28);
            this.Registration.Controls.Add(this.label31);
            this.Registration.Controls.Add(this.label32);
            this.Registration.Controls.Add(this.label33);
            this.Registration.Controls.Add(this.label34);
            this.Registration.Controls.Add(this.label36);
            this.Registration.Controls.Add(this.label37);
            this.Registration.Controls.Add(this.label38);
            this.Registration.Controls.Add(this.bunifuImageButton3);
            this.Registration.Controls.Add(this.label39);
            this.Registration.Controls.Add(this.label40);
            this.Registration.Controls.Add(this.label41);
            this.Registration.Controls.Add(this.label42);
            this.Registration.Controls.Add(this.bunifuImageButton15);
            this.Registration.Controls.Add(this.lblModalNo);
            this.Registration.Controls.Add(this.lblUnit);
            this.Registration.Controls.Add(this.lblGroup);
            this.Registration.Controls.Add(this.lblBrand);
            this.Registration.Controls.Add(this.lblProductCode);
            this.Registration.Controls.Add(this.lblName);
            this.Registration.Font = new System.Drawing.Font("Segoe UI", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Registration.Location = new System.Drawing.Point(4, 30);
            this.Registration.Name = "Registration";
            this.Registration.Padding = new System.Windows.Forms.Padding(3);
            this.Registration.Size = new System.Drawing.Size(1264, 641);
            this.Registration.TabIndex = 0;
            this.Registration.Text = "Main Details";
            // 
            // txtID
            // 
            this.txtID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.txtID.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txtID.ForeColor = System.Drawing.Color.Black;
            this.txtID.Location = new System.Drawing.Point(352, 10);
            this.txtID.Name = "txtID";
            this.txtID.ReadOnly = true;
            this.txtID.Size = new System.Drawing.Size(10, 25);
            this.txtID.TabIndex = 3;
            // 
            // dataGridView1
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.OldLace;
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.BackgroundColor = System.Drawing.Color.White;
            this.dataGridView1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(749, 47);
            this.dataGridView1.Name = "dataGridView1";
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Trebuchet MS", 9.75F);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.Black;
            this.dataGridView1.RowsDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(486, 536);
            this.dataGridView1.TabIndex = 1020;
            this.dataGridView1.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dataGridView1_CellMouseClick);
            // 
            // btn_print
            // 
            this.btn_print.BackColor = System.Drawing.Color.Blue;
            this.btn_print.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_print.Font = new System.Drawing.Font("Trebuchet MS", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_print.ForeColor = System.Drawing.Color.White;
            this.btn_print.Location = new System.Drawing.Point(1035, 16);
            this.btn_print.Name = "btn_print";
            this.btn_print.Size = new System.Drawing.Size(63, 25);
            this.btn_print.TabIndex = 1019;
            this.btn_print.Text = "Search";
            this.btn_print.UseVisualStyleBackColor = false;
            this.btn_print.Click += new System.EventHandler(this.btn_print_Click);
            // 
            // combo_search_type
            // 
            this.combo_search_type.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_search_type.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_search_type.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_search_type.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_search_type.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.combo_search_type.FormattingEnabled = true;
            this.combo_search_type.Items.AddRange(new object[] {
            "Barcode",
            "Name"});
            this.combo_search_type.Location = new System.Drawing.Point(749, 16);
            this.combo_search_type.Name = "combo_search_type";
            this.combo_search_type.Size = new System.Drawing.Size(142, 25);
            this.combo_search_type.TabIndex = 1018;
            this.combo_search_type.Text = "--- Select Field---";
            // 
            // txt_search
            // 
            this.txt_search.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_search.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.txt_search.Location = new System.Drawing.Point(892, 16);
            this.txt_search.Name = "txt_search";
            this.txt_search.Size = new System.Drawing.Size(142, 25);
            this.txt_search.TabIndex = 1017;
            // 
            // panel37
            // 
            this.panel37.BackColor = System.Drawing.Color.Gainsboro;
            this.panel37.Controls.Add(this.combo_Status);
            this.panel37.Location = new System.Drawing.Point(523, 554);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(194, 29);
            this.panel37.TabIndex = 1016;
            // 
            // combo_Status
            // 
            this.combo_Status.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_Status.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_Status.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_Status.DropDownHeight = 200;
            this.combo_Status.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_Status.ForeColor = System.Drawing.Color.Black;
            this.combo_Status.FormattingEnabled = true;
            this.combo_Status.IntegralHeight = false;
            this.combo_Status.ItemHeight = 17;
            this.combo_Status.Items.AddRange(new object[] {
            "Active",
            "Unactive"});
            this.combo_Status.Location = new System.Drawing.Point(2, 2);
            this.combo_Status.MaxDropDownItems = 50;
            this.combo_Status.Name = "combo_Status";
            this.combo_Status.Size = new System.Drawing.Size(190, 25);
            this.combo_Status.TabIndex = 575;
            this.combo_Status.Text = "--- Select Status---";
            // 
            // panel38
            // 
            this.panel38.BackColor = System.Drawing.Color.Gainsboro;
            this.panel38.Controls.Add(this.txt_AddProfit);
            this.panel38.Location = new System.Drawing.Point(146, 554);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(194, 29);
            this.panel38.TabIndex = 1015;
            // 
            // txt_AddProfit
            // 
            this.txt_AddProfit.BackColor = System.Drawing.Color.White;
            this.txt_AddProfit.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_AddProfit.ForeColor = System.Drawing.Color.Black;
            this.txt_AddProfit.Location = new System.Drawing.Point(2, 2);
            this.txt_AddProfit.Name = "txt_AddProfit";
            this.txt_AddProfit.Size = new System.Drawing.Size(190, 25);
            this.txt_AddProfit.TabIndex = 3;
            // 
            // panel35
            // 
            this.panel35.BackColor = System.Drawing.Color.Gainsboro;
            this.panel35.Controls.Add(this.txt_Location);
            this.panel35.Location = new System.Drawing.Point(523, 515);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(194, 29);
            this.panel35.TabIndex = 1014;
            // 
            // txt_Location
            // 
            this.txt_Location.BackColor = System.Drawing.Color.White;
            this.txt_Location.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_Location.ForeColor = System.Drawing.Color.Black;
            this.txt_Location.Location = new System.Drawing.Point(2, 2);
            this.txt_Location.Name = "txt_Location";
            this.txt_Location.Size = new System.Drawing.Size(190, 25);
            this.txt_Location.TabIndex = 3;
            // 
            // panel36
            // 
            this.panel36.BackColor = System.Drawing.Color.Gainsboro;
            this.panel36.Controls.Add(this.txt_RetailPrice);
            this.panel36.Location = new System.Drawing.Point(146, 515);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(194, 29);
            this.panel36.TabIndex = 1013;
            // 
            // txt_RetailPrice
            // 
            this.txt_RetailPrice.BackColor = System.Drawing.Color.White;
            this.txt_RetailPrice.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_RetailPrice.ForeColor = System.Drawing.Color.Black;
            this.txt_RetailPrice.Location = new System.Drawing.Point(2, 2);
            this.txt_RetailPrice.Name = "txt_RetailPrice";
            this.txt_RetailPrice.Size = new System.Drawing.Size(190, 25);
            this.txt_RetailPrice.TabIndex = 3;
            // 
            // panel33
            // 
            this.panel33.BackColor = System.Drawing.Color.Gainsboro;
            this.panel33.Controls.Add(this.txt_CustomerPrice);
            this.panel33.Location = new System.Drawing.Point(523, 477);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(194, 29);
            this.panel33.TabIndex = 1012;
            // 
            // txt_CustomerPrice
            // 
            this.txt_CustomerPrice.BackColor = System.Drawing.Color.White;
            this.txt_CustomerPrice.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_CustomerPrice.ForeColor = System.Drawing.Color.Black;
            this.txt_CustomerPrice.Location = new System.Drawing.Point(2, 2);
            this.txt_CustomerPrice.Name = "txt_CustomerPrice";
            this.txt_CustomerPrice.Size = new System.Drawing.Size(190, 25);
            this.txt_CustomerPrice.TabIndex = 3;
            // 
            // panel34
            // 
            this.panel34.BackColor = System.Drawing.Color.Gainsboro;
            this.panel34.Controls.Add(this.txt_PurchasePrice);
            this.panel34.Location = new System.Drawing.Point(146, 477);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(194, 29);
            this.panel34.TabIndex = 1011;
            // 
            // txt_PurchasePrice
            // 
            this.txt_PurchasePrice.BackColor = System.Drawing.Color.White;
            this.txt_PurchasePrice.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_PurchasePrice.ForeColor = System.Drawing.Color.Black;
            this.txt_PurchasePrice.Location = new System.Drawing.Point(2, 2);
            this.txt_PurchasePrice.Name = "txt_PurchasePrice";
            this.txt_PurchasePrice.Size = new System.Drawing.Size(190, 25);
            this.txt_PurchasePrice.TabIndex = 3;
            // 
            // panel31
            // 
            this.panel31.BackColor = System.Drawing.Color.Gainsboro;
            this.panel31.Controls.Add(this.txt_WholeSalePrice);
            this.panel31.Location = new System.Drawing.Point(523, 439);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(194, 29);
            this.panel31.TabIndex = 1010;
            // 
            // txt_WholeSalePrice
            // 
            this.txt_WholeSalePrice.BackColor = System.Drawing.Color.White;
            this.txt_WholeSalePrice.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_WholeSalePrice.ForeColor = System.Drawing.Color.Black;
            this.txt_WholeSalePrice.Location = new System.Drawing.Point(2, 2);
            this.txt_WholeSalePrice.Name = "txt_WholeSalePrice";
            this.txt_WholeSalePrice.Size = new System.Drawing.Size(190, 25);
            this.txt_WholeSalePrice.TabIndex = 3;
            // 
            // panel32
            // 
            this.panel32.BackColor = System.Drawing.Color.Gainsboro;
            this.panel32.Controls.Add(this.combo_SellingCurrency);
            this.panel32.Location = new System.Drawing.Point(146, 439);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(194, 29);
            this.panel32.TabIndex = 1009;
            // 
            // combo_SellingCurrency
            // 
            this.combo_SellingCurrency.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_SellingCurrency.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_SellingCurrency.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_SellingCurrency.DropDownHeight = 200;
            this.combo_SellingCurrency.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_SellingCurrency.ForeColor = System.Drawing.Color.Black;
            this.combo_SellingCurrency.FormattingEnabled = true;
            this.combo_SellingCurrency.IntegralHeight = false;
            this.combo_SellingCurrency.ItemHeight = 17;
            this.combo_SellingCurrency.Items.AddRange(new object[] {
            "USD"});
            this.combo_SellingCurrency.Location = new System.Drawing.Point(2, 2);
            this.combo_SellingCurrency.MaxDropDownItems = 50;
            this.combo_SellingCurrency.Name = "combo_SellingCurrency";
            this.combo_SellingCurrency.Size = new System.Drawing.Size(190, 25);
            this.combo_SellingCurrency.TabIndex = 574;
            this.combo_SellingCurrency.Text = "--- Select Currency---";
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.Gainsboro;
            this.panel3.Controls.Add(this.combo_PurchaseCurency);
            this.panel3.Location = new System.Drawing.Point(523, 402);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(194, 29);
            this.panel3.TabIndex = 1008;
            // 
            // combo_PurchaseCurency
            // 
            this.combo_PurchaseCurency.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_PurchaseCurency.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_PurchaseCurency.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_PurchaseCurency.DropDownHeight = 200;
            this.combo_PurchaseCurency.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_PurchaseCurency.ForeColor = System.Drawing.Color.Black;
            this.combo_PurchaseCurency.FormattingEnabled = true;
            this.combo_PurchaseCurency.IntegralHeight = false;
            this.combo_PurchaseCurency.ItemHeight = 17;
            this.combo_PurchaseCurency.Items.AddRange(new object[] {
            "USD"});
            this.combo_PurchaseCurency.Location = new System.Drawing.Point(2, 2);
            this.combo_PurchaseCurency.MaxDropDownItems = 50;
            this.combo_PurchaseCurency.Name = "combo_PurchaseCurency";
            this.combo_PurchaseCurency.Size = new System.Drawing.Size(190, 25);
            this.combo_PurchaseCurency.TabIndex = 573;
            this.combo_PurchaseCurency.Text = "--- Select Currency---";
            // 
            // panel6
            // 
            this.panel6.BackColor = System.Drawing.Color.Gainsboro;
            this.panel6.Controls.Add(this.dateTimePicker1);
            this.panel6.Location = new System.Drawing.Point(146, 402);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(194, 29);
            this.panel6.TabIndex = 1007;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CalendarFont = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker1.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker1.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(2, 2);
            this.dateTimePicker1.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(190, 25);
            this.dateTimePicker1.TabIndex = 8;
            // 
            // panel7
            // 
            this.panel7.BackColor = System.Drawing.Color.Gainsboro;
            this.panel7.Controls.Add(this.dateTimePicker2);
            this.panel7.Location = new System.Drawing.Point(523, 365);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(194, 29);
            this.panel7.TabIndex = 1006;
            // 
            // dateTimePicker2
            // 
            this.dateTimePicker2.CalendarFont = new System.Drawing.Font("Arial Narrow", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateTimePicker2.CustomFormat = "dd/MM/yyyy";
            this.dateTimePicker2.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.dateTimePicker2.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker2.Location = new System.Drawing.Point(2, 2);
            this.dateTimePicker2.Margin = new System.Windows.Forms.Padding(2);
            this.dateTimePicker2.Name = "dateTimePicker2";
            this.dateTimePicker2.Size = new System.Drawing.Size(190, 25);
            this.dateTimePicker2.TabIndex = 7;
            // 
            // panel28
            // 
            this.panel28.BackColor = System.Drawing.Color.Gainsboro;
            this.panel28.Controls.Add(this.label26);
            this.panel28.Controls.Add(this.txt_ReorderLevel);
            this.panel28.Controls.Add(this.label27);
            this.panel28.Controls.Add(this.panel8);
            this.panel28.Location = new System.Drawing.Point(146, 365);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(194, 29);
            this.panel28.TabIndex = 1005;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Transparent;
            this.label26.Font = new System.Drawing.Font("Trebuchet MS", 9.75F);
            this.label26.ForeColor = System.Drawing.Color.Black;
            this.label26.Location = new System.Drawing.Point(-58, 324);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(192, 18);
            this.label26.TabIndex = 926;
            this.label26.Text = "Powered By Glcc Of IT Solutions";
            // 
            // txt_ReorderLevel
            // 
            this.txt_ReorderLevel.BackColor = System.Drawing.Color.White;
            this.txt_ReorderLevel.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_ReorderLevel.ForeColor = System.Drawing.Color.Black;
            this.txt_ReorderLevel.Location = new System.Drawing.Point(2, 2);
            this.txt_ReorderLevel.Name = "txt_ReorderLevel";
            this.txt_ReorderLevel.Size = new System.Drawing.Size(190, 25);
            this.txt_ReorderLevel.TabIndex = 2;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.BackColor = System.Drawing.Color.Transparent;
            this.label27.Font = new System.Drawing.Font("Trebuchet MS", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.label27.Location = new System.Drawing.Point(-74, 299);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(230, 24);
            this.label27.TabIndex = 925;
            this.label27.Text = "LOOP STOCK INVENTORY";
            // 
            // panel8
            // 
            this.panel8.BackColor = System.Drawing.Color.Transparent;
            this.panel8.Controls.Add(this.label35);
            this.panel8.Controls.Add(this.panel43);
            this.panel8.ForeColor = System.Drawing.Color.Black;
            this.panel8.Location = new System.Drawing.Point(-120, 301);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(324, 37);
            this.panel8.TabIndex = 927;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Arial", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.Gray;
            this.label35.Location = new System.Drawing.Point(626, 18);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(0, 15);
            this.label35.TabIndex = 432;
            // 
            // panel43
            // 
            this.panel43.BackColor = System.Drawing.Color.Gray;
            this.panel43.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel43.Location = new System.Drawing.Point(0, 35);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(324, 2);
            this.panel43.TabIndex = 425;
            // 
            // panel9
            // 
            this.panel9.BackColor = System.Drawing.Color.Gainsboro;
            this.panel9.Controls.Add(this.txt_TaxPercentage);
            this.panel9.Location = new System.Drawing.Point(523, 328);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(194, 29);
            this.panel9.TabIndex = 1004;
            // 
            // txt_TaxPercentage
            // 
            this.txt_TaxPercentage.BackColor = System.Drawing.Color.White;
            this.txt_TaxPercentage.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_TaxPercentage.ForeColor = System.Drawing.Color.Black;
            this.txt_TaxPercentage.Location = new System.Drawing.Point(2, 2);
            this.txt_TaxPercentage.Name = "txt_TaxPercentage";
            this.txt_TaxPercentage.Size = new System.Drawing.Size(190, 25);
            this.txt_TaxPercentage.TabIndex = 3;
            // 
            // panel11
            // 
            this.panel11.BackColor = System.Drawing.Color.Gainsboro;
            this.panel11.Controls.Add(this.txt_NextShoppingDiscount);
            this.panel11.Location = new System.Drawing.Point(146, 328);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(194, 29);
            this.panel11.TabIndex = 1003;
            // 
            // txt_NextShoppingDiscount
            // 
            this.txt_NextShoppingDiscount.BackColor = System.Drawing.Color.White;
            this.txt_NextShoppingDiscount.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_NextShoppingDiscount.ForeColor = System.Drawing.Color.Black;
            this.txt_NextShoppingDiscount.Location = new System.Drawing.Point(2, 2);
            this.txt_NextShoppingDiscount.Name = "txt_NextShoppingDiscount";
            this.txt_NextShoppingDiscount.Size = new System.Drawing.Size(190, 25);
            this.txt_NextShoppingDiscount.TabIndex = 2;
            // 
            // panel12
            // 
            this.panel12.BackColor = System.Drawing.Color.Gainsboro;
            this.panel12.Controls.Add(this.txt_DirectDiscount);
            this.panel12.Location = new System.Drawing.Point(523, 291);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(194, 29);
            this.panel12.TabIndex = 1002;
            // 
            // txt_DirectDiscount
            // 
            this.txt_DirectDiscount.BackColor = System.Drawing.Color.White;
            this.txt_DirectDiscount.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_DirectDiscount.ForeColor = System.Drawing.Color.Black;
            this.txt_DirectDiscount.Location = new System.Drawing.Point(2, 2);
            this.txt_DirectDiscount.Name = "txt_DirectDiscount";
            this.txt_DirectDiscount.Size = new System.Drawing.Size(190, 25);
            this.txt_DirectDiscount.TabIndex = 3;
            // 
            // panel20
            // 
            this.panel20.BackColor = System.Drawing.Color.Gainsboro;
            this.panel20.Controls.Add(this.combo_DiscountType);
            this.panel20.Location = new System.Drawing.Point(146, 291);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(194, 29);
            this.panel20.TabIndex = 1001;
            // 
            // combo_DiscountType
            // 
            this.combo_DiscountType.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_DiscountType.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_DiscountType.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_DiscountType.DropDownHeight = 200;
            this.combo_DiscountType.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_DiscountType.ForeColor = System.Drawing.Color.Black;
            this.combo_DiscountType.FormattingEnabled = true;
            this.combo_DiscountType.IntegralHeight = false;
            this.combo_DiscountType.ItemHeight = 17;
            this.combo_DiscountType.Items.AddRange(new object[] {
            "Discount1"});
            this.combo_DiscountType.Location = new System.Drawing.Point(2, 2);
            this.combo_DiscountType.MaxDropDownItems = 50;
            this.combo_DiscountType.Name = "combo_DiscountType";
            this.combo_DiscountType.Size = new System.Drawing.Size(190, 25);
            this.combo_DiscountType.TabIndex = 572;
            this.combo_DiscountType.Text = "--- Select Discount Type---";
            // 
            // panel39
            // 
            this.panel39.BackColor = System.Drawing.Color.Gainsboro;
            this.panel39.Controls.Add(this.txt_PreferredVender);
            this.panel39.Location = new System.Drawing.Point(523, 255);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(194, 29);
            this.panel39.TabIndex = 1000;
            // 
            // txt_PreferredVender
            // 
            this.txt_PreferredVender.BackColor = System.Drawing.Color.White;
            this.txt_PreferredVender.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_PreferredVender.ForeColor = System.Drawing.Color.Black;
            this.txt_PreferredVender.Location = new System.Drawing.Point(2, 2);
            this.txt_PreferredVender.Name = "txt_PreferredVender";
            this.txt_PreferredVender.Size = new System.Drawing.Size(190, 25);
            this.txt_PreferredVender.TabIndex = 3;
            // 
            // panel41
            // 
            this.panel41.BackColor = System.Drawing.Color.Gainsboro;
            this.panel41.Controls.Add(this.txt_CompanyProduct);
            this.panel41.Location = new System.Drawing.Point(146, 255);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(194, 29);
            this.panel41.TabIndex = 999;
            // 
            // txt_CompanyProduct
            // 
            this.txt_CompanyProduct.BackColor = System.Drawing.Color.White;
            this.txt_CompanyProduct.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_CompanyProduct.ForeColor = System.Drawing.Color.Black;
            this.txt_CompanyProduct.Location = new System.Drawing.Point(2, 2);
            this.txt_CompanyProduct.Name = "txt_CompanyProduct";
            this.txt_CompanyProduct.Size = new System.Drawing.Size(190, 25);
            this.txt_CompanyProduct.TabIndex = 2;
            // 
            // panel45
            // 
            this.panel45.BackColor = System.Drawing.Color.Gainsboro;
            this.panel45.Controls.Add(this.txt_QtyPerUnit);
            this.panel45.Location = new System.Drawing.Point(146, 219);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(194, 29);
            this.panel45.TabIndex = 998;
            // 
            // txt_QtyPerUnit
            // 
            this.txt_QtyPerUnit.BackColor = System.Drawing.Color.White;
            this.txt_QtyPerUnit.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_QtyPerUnit.ForeColor = System.Drawing.Color.Black;
            this.txt_QtyPerUnit.Location = new System.Drawing.Point(2, 2);
            this.txt_QtyPerUnit.Name = "txt_QtyPerUnit";
            this.txt_QtyPerUnit.Size = new System.Drawing.Size(190, 25);
            this.txt_QtyPerUnit.TabIndex = 2;
            // 
            // panel46
            // 
            this.panel46.BackColor = System.Drawing.Color.Gainsboro;
            this.panel46.Controls.Add(this.txt_Description);
            this.panel46.Location = new System.Drawing.Point(523, 183);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(194, 65);
            this.panel46.TabIndex = 997;
            // 
            // txt_Description
            // 
            this.txt_Description.BackColor = System.Drawing.Color.White;
            this.txt_Description.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_Description.ForeColor = System.Drawing.Color.Black;
            this.txt_Description.Location = new System.Drawing.Point(2, 2);
            this.txt_Description.Multiline = true;
            this.txt_Description.Name = "txt_Description";
            this.txt_Description.Size = new System.Drawing.Size(190, 61);
            this.txt_Description.TabIndex = 3;
            // 
            // panel47
            // 
            this.panel47.BackColor = System.Drawing.Color.Gainsboro;
            this.panel47.Controls.Add(this.combo_Unit);
            this.panel47.Location = new System.Drawing.Point(523, 147);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(194, 29);
            this.panel47.TabIndex = 996;
            // 
            // combo_Unit
            // 
            this.combo_Unit.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_Unit.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_Unit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_Unit.DropDownHeight = 200;
            this.combo_Unit.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_Unit.ForeColor = System.Drawing.Color.Black;
            this.combo_Unit.FormattingEnabled = true;
            this.combo_Unit.IntegralHeight = false;
            this.combo_Unit.ItemHeight = 17;
            this.combo_Unit.Items.AddRange(new object[] {
            "Unit"});
            this.combo_Unit.Location = new System.Drawing.Point(2, 2);
            this.combo_Unit.MaxDropDownItems = 50;
            this.combo_Unit.Name = "combo_Unit";
            this.combo_Unit.Size = new System.Drawing.Size(190, 25);
            this.combo_Unit.TabIndex = 571;
            this.combo_Unit.Text = "--- Select Unit---";
            // 
            // panel48
            // 
            this.panel48.BackColor = System.Drawing.Color.Gainsboro;
            this.panel48.Controls.Add(this.combo_Color);
            this.panel48.Location = new System.Drawing.Point(146, 183);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(194, 29);
            this.panel48.TabIndex = 995;
            // 
            // combo_Color
            // 
            this.combo_Color.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_Color.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_Color.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_Color.DropDownHeight = 200;
            this.combo_Color.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_Color.ForeColor = System.Drawing.Color.Black;
            this.combo_Color.FormattingEnabled = true;
            this.combo_Color.IntegralHeight = false;
            this.combo_Color.ItemHeight = 17;
            this.combo_Color.Items.AddRange(new object[] {
            "Blue"});
            this.combo_Color.Location = new System.Drawing.Point(2, 2);
            this.combo_Color.MaxDropDownItems = 50;
            this.combo_Color.Name = "combo_Color";
            this.combo_Color.Size = new System.Drawing.Size(190, 25);
            this.combo_Color.TabIndex = 571;
            this.combo_Color.Text = "--- Select Color---";
            // 
            // panel49
            // 
            this.panel49.BackColor = System.Drawing.Color.Gainsboro;
            this.panel49.Controls.Add(this.combo_Brand);
            this.panel49.Location = new System.Drawing.Point(523, 111);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(194, 29);
            this.panel49.TabIndex = 994;
            // 
            // combo_Brand
            // 
            this.combo_Brand.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_Brand.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_Brand.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_Brand.DropDownHeight = 200;
            this.combo_Brand.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_Brand.ForeColor = System.Drawing.Color.Black;
            this.combo_Brand.FormattingEnabled = true;
            this.combo_Brand.IntegralHeight = false;
            this.combo_Brand.ItemHeight = 17;
            this.combo_Brand.Items.AddRange(new object[] {
            "Brand"});
            this.combo_Brand.Location = new System.Drawing.Point(2, 2);
            this.combo_Brand.MaxDropDownItems = 50;
            this.combo_Brand.Name = "combo_Brand";
            this.combo_Brand.Size = new System.Drawing.Size(190, 25);
            this.combo_Brand.TabIndex = 571;
            this.combo_Brand.Text = "--- Select Brand---";
            // 
            // panel50
            // 
            this.panel50.BackColor = System.Drawing.Color.Gainsboro;
            this.panel50.Controls.Add(this.combo_Category);
            this.panel50.Location = new System.Drawing.Point(146, 147);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(194, 29);
            this.panel50.TabIndex = 993;
            // 
            // combo_Category
            // 
            this.combo_Category.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_Category.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_Category.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_Category.DropDownHeight = 200;
            this.combo_Category.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_Category.ForeColor = System.Drawing.Color.Black;
            this.combo_Category.FormattingEnabled = true;
            this.combo_Category.IntegralHeight = false;
            this.combo_Category.ItemHeight = 17;
            this.combo_Category.Items.AddRange(new object[] {
            "Category1"});
            this.combo_Category.Location = new System.Drawing.Point(2, 2);
            this.combo_Category.MaxDropDownItems = 50;
            this.combo_Category.Name = "combo_Category";
            this.combo_Category.Size = new System.Drawing.Size(190, 25);
            this.combo_Category.TabIndex = 571;
            this.combo_Category.Text = "--- Select Category---";
            // 
            // panel51
            // 
            this.panel51.BackColor = System.Drawing.Color.Gainsboro;
            this.panel51.Controls.Add(this.combo_Store);
            this.panel51.Location = new System.Drawing.Point(523, 76);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(194, 29);
            this.panel51.TabIndex = 992;
            // 
            // combo_Store
            // 
            this.combo_Store.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.SuggestAppend;
            this.combo_Store.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems;
            this.combo_Store.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.combo_Store.DropDownHeight = 200;
            this.combo_Store.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Bold);
            this.combo_Store.ForeColor = System.Drawing.Color.Black;
            this.combo_Store.FormattingEnabled = true;
            this.combo_Store.IntegralHeight = false;
            this.combo_Store.ItemHeight = 17;
            this.combo_Store.Items.AddRange(new object[] {
            "Type1"});
            this.combo_Store.Location = new System.Drawing.Point(2, 2);
            this.combo_Store.MaxDropDownItems = 50;
            this.combo_Store.Name = "combo_Store";
            this.combo_Store.Size = new System.Drawing.Size(190, 25);
            this.combo_Store.TabIndex = 571;
            this.combo_Store.Text = "--- Select Store Type---";
            // 
            // panel52
            // 
            this.panel52.BackColor = System.Drawing.Color.Gainsboro;
            this.panel52.Controls.Add(this.txt_ProductnameEng);
            this.panel52.Location = new System.Drawing.Point(146, 76);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(194, 64);
            this.panel52.TabIndex = 991;
            // 
            // txt_ProductnameEng
            // 
            this.txt_ProductnameEng.BackColor = System.Drawing.Color.White;
            this.txt_ProductnameEng.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_ProductnameEng.ForeColor = System.Drawing.Color.Black;
            this.txt_ProductnameEng.Location = new System.Drawing.Point(2, 2);
            this.txt_ProductnameEng.Multiline = true;
            this.txt_ProductnameEng.Name = "txt_ProductnameEng";
            this.txt_ProductnameEng.Size = new System.Drawing.Size(190, 60);
            this.txt_ProductnameEng.TabIndex = 2;
            // 
            // panel53
            // 
            this.panel53.BackColor = System.Drawing.Color.Gainsboro;
            this.panel53.Controls.Add(this.txt_ProductnameArabic);
            this.panel53.Location = new System.Drawing.Point(523, 41);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(194, 29);
            this.panel53.TabIndex = 990;
            // 
            // txt_ProductnameArabic
            // 
            this.txt_ProductnameArabic.BackColor = System.Drawing.Color.White;
            this.txt_ProductnameArabic.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_ProductnameArabic.ForeColor = System.Drawing.Color.Black;
            this.txt_ProductnameArabic.Location = new System.Drawing.Point(2, 2);
            this.txt_ProductnameArabic.Name = "txt_ProductnameArabic";
            this.txt_ProductnameArabic.Size = new System.Drawing.Size(190, 25);
            this.txt_ProductnameArabic.TabIndex = 2;
            // 
            // panel54
            // 
            this.panel54.BackColor = System.Drawing.Color.Gainsboro;
            this.panel54.Controls.Add(this.txt_Productcode);
            this.panel54.Location = new System.Drawing.Point(146, 41);
            this.panel54.Name = "panel54";
            this.panel54.Size = new System.Drawing.Size(194, 29);
            this.panel54.TabIndex = 989;
            // 
            // txt_Productcode
            // 
            this.txt_Productcode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.txt_Productcode.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_Productcode.ForeColor = System.Drawing.Color.Black;
            this.txt_Productcode.Location = new System.Drawing.Point(2, 2);
            this.txt_Productcode.Name = "txt_Productcode";
            this.txt_Productcode.Size = new System.Drawing.Size(190, 25);
            this.txt_Productcode.TabIndex = 2;
            // 
            // panel55
            // 
            this.panel55.BackColor = System.Drawing.Color.Gainsboro;
            this.panel55.Controls.Add(this.txt_Barcode2);
            this.panel55.Location = new System.Drawing.Point(523, 6);
            this.panel55.Name = "panel55";
            this.panel55.Size = new System.Drawing.Size(194, 29);
            this.panel55.TabIndex = 988;
            // 
            // txt_Barcode2
            // 
            this.txt_Barcode2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.txt_Barcode2.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_Barcode2.ForeColor = System.Drawing.Color.Black;
            this.txt_Barcode2.Location = new System.Drawing.Point(2, 2);
            this.txt_Barcode2.Name = "txt_Barcode2";
            this.txt_Barcode2.Size = new System.Drawing.Size(190, 25);
            this.txt_Barcode2.TabIndex = 2;
            // 
            // panel56
            // 
            this.panel56.BackColor = System.Drawing.Color.Gainsboro;
            this.panel56.Controls.Add(this.txt_Barcode1);
            this.panel56.Location = new System.Drawing.Point(146, 6);
            this.panel56.Name = "panel56";
            this.panel56.Size = new System.Drawing.Size(194, 29);
            this.panel56.TabIndex = 987;
            // 
            // txt_Barcode1
            // 
            this.txt_Barcode1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.txt_Barcode1.Font = new System.Drawing.Font("Trebuchet MS", 11.25F, System.Drawing.FontStyle.Bold);
            this.txt_Barcode1.ForeColor = System.Drawing.Color.Black;
            this.txt_Barcode1.Location = new System.Drawing.Point(2, 2);
            this.txt_Barcode1.Name = "txt_Barcode1";
            this.txt_Barcode1.Size = new System.Drawing.Size(190, 25);
            this.txt_Barcode1.TabIndex = 2;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Transparent;
            this.label24.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label24.Location = new System.Drawing.Point(374, 561);
            this.label24.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(76, 15);
            this.label24.TabIndex = 986;
            this.label24.Text = "Select Status:";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.BackColor = System.Drawing.Color.Transparent;
            this.label25.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label25.Location = new System.Drawing.Point(15, 560);
            this.label25.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(77, 15);
            this.label25.TabIndex = 985;
            this.label25.Text = "Add Profit %:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Transparent;
            this.label2.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label2.Location = new System.Drawing.Point(374, 521);
            this.label2.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 15);
            this.label2.TabIndex = 984;
            this.label2.Text = "Location:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Transparent;
            this.label3.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label3.Location = new System.Drawing.Point(15, 521);
            this.label3.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(68, 15);
            this.label3.TabIndex = 983;
            this.label3.Text = "Retail Price:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.BackColor = System.Drawing.Color.Transparent;
            this.label12.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label12.Location = new System.Drawing.Point(374, 483);
            this.label12.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(91, 15);
            this.label12.TabIndex = 982;
            this.label12.Text = "Customer Price:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Transparent;
            this.label4.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label4.Location = new System.Drawing.Point(15, 482);
            this.label4.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(87, 15);
            this.label4.TabIndex = 981;
            this.label4.Text = "Purchase Price:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.Color.Transparent;
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(374, 445);
            this.label5.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 15);
            this.label5.TabIndex = 980;
            this.label5.Text = "Whole Sale Price:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.BackColor = System.Drawing.Color.Transparent;
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(15, 444);
            this.label6.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 15);
            this.label6.TabIndex = 979;
            this.label6.Text = "Selling Currency:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.BackColor = System.Drawing.Color.Transparent;
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(374, 408);
            this.label7.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(109, 15);
            this.label7.TabIndex = 978;
            this.label7.Text = "Purchase Currency:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.BackColor = System.Drawing.Color.Transparent;
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(15, 409);
            this.label8.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(69, 15);
            this.label8.TabIndex = 977;
            this.label8.Text = "Expire Date:";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label22.Location = new System.Drawing.Point(374, 370);
            this.label22.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(116, 15);
            this.label22.TabIndex = 976;
            this.label22.Text = "Manufacturing Date:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Transparent;
            this.label23.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label23.Location = new System.Drawing.Point(15, 371);
            this.label23.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(81, 15);
            this.label23.TabIndex = 975;
            this.label23.Text = "Reorder Level:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Transparent;
            this.label28.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label28.Location = new System.Drawing.Point(374, 335);
            this.label28.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(83, 15);
            this.label28.TabIndex = 974;
            this.label28.Text = "Tax Percent %:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.BackColor = System.Drawing.Color.Transparent;
            this.label31.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label31.Location = new System.Drawing.Point(15, 334);
            this.label31.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(108, 15);
            this.label31.TabIndex = 973;
            this.label31.Text = "Next Shopping Dis:";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.Transparent;
            this.label32.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label32.Location = new System.Drawing.Point(374, 298);
            this.label32.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(91, 15);
            this.label32.TabIndex = 972;
            this.label32.Text = "Direct Discount:";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.BackColor = System.Drawing.Color.Transparent;
            this.label33.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label33.Location = new System.Drawing.Point(15, 297);
            this.label33.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(84, 15);
            this.label33.TabIndex = 971;
            this.label33.Text = "Discount Type:";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.Transparent;
            this.label34.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label34.Location = new System.Drawing.Point(374, 261);
            this.label34.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(97, 15);
            this.label34.TabIndex = 970;
            this.label34.Text = "Preferred Vender:";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.Transparent;
            this.label36.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label36.Location = new System.Drawing.Point(15, 261);
            this.label36.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(107, 15);
            this.label36.TabIndex = 969;
            this.label36.Text = "Company Product:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.BackColor = System.Drawing.Color.Transparent;
            this.label37.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label37.Location = new System.Drawing.Point(373, 189);
            this.label37.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(97, 15);
            this.label37.TabIndex = 968;
            this.label37.Text = "Type Description:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.BackColor = System.Drawing.Color.Transparent;
            this.label38.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label38.Location = new System.Drawing.Point(15, 225);
            this.label38.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(74, 15);
            this.label38.TabIndex = 967;
            this.label38.Text = "Qty Per Unit:";
            // 
            // bunifuImageButton3
            // 
            this.bunifuImageButton3.BackColor = System.Drawing.Color.DimGray;
            this.bunifuImageButton3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton3.Image")));
            this.bunifuImageButton3.ImageActive = null;
            this.bunifuImageButton3.Location = new System.Drawing.Point(342, 187);
            this.bunifuImageButton3.Name = "bunifuImageButton3";
            this.bunifuImageButton3.Size = new System.Drawing.Size(20, 21);
            this.bunifuImageButton3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton3.TabIndex = 966;
            this.bunifuImageButton3.TabStop = false;
            this.bunifuImageButton3.Zoom = 10;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.BackColor = System.Drawing.Color.Transparent;
            this.label39.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label39.Location = new System.Drawing.Point(374, 12);
            this.label39.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(109, 15);
            this.label39.TabIndex = 962;
            this.label39.Text = "Barcode Number 2:";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.BackColor = System.Drawing.Color.Transparent;
            this.label40.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label40.Location = new System.Drawing.Point(15, 12);
            this.label40.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(109, 15);
            this.label40.TabIndex = 961;
            this.label40.Text = "Barcode Number 1:";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.BackColor = System.Drawing.Color.Transparent;
            this.label41.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label41.Location = new System.Drawing.Point(374, 152);
            this.label41.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(73, 15);
            this.label41.TabIndex = 965;
            this.label41.Text = "Type of Unit:";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.Transparent;
            this.label42.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label42.Location = new System.Drawing.Point(15, 189);
            this.label42.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(73, 15);
            this.label42.TabIndex = 964;
            this.label42.Text = "Select Color:";
            // 
            // bunifuImageButton15
            // 
            this.bunifuImageButton15.BackColor = System.Drawing.Color.DimGray;
            this.bunifuImageButton15.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.bunifuImageButton15.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton15.Image")));
            this.bunifuImageButton15.ImageActive = null;
            this.bunifuImageButton15.Location = new System.Drawing.Point(342, 150);
            this.bunifuImageButton15.Name = "bunifuImageButton15";
            this.bunifuImageButton15.Size = new System.Drawing.Size(20, 21);
            this.bunifuImageButton15.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.bunifuImageButton15.TabIndex = 963;
            this.bunifuImageButton15.TabStop = false;
            this.bunifuImageButton15.Zoom = 10;
            // 
            // lblModalNo
            // 
            this.lblModalNo.AutoSize = true;
            this.lblModalNo.BackColor = System.Drawing.Color.Transparent;
            this.lblModalNo.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblModalNo.Location = new System.Drawing.Point(374, 117);
            this.lblModalNo.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.lblModalNo.Name = "lblModalNo";
            this.lblModalNo.Size = new System.Drawing.Size(76, 15);
            this.lblModalNo.TabIndex = 960;
            this.lblModalNo.Text = "Brand Name:";
            // 
            // lblUnit
            // 
            this.lblUnit.AutoSize = true;
            this.lblUnit.BackColor = System.Drawing.Color.Transparent;
            this.lblUnit.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblUnit.Location = new System.Drawing.Point(374, 82);
            this.lblUnit.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.lblUnit.Name = "lblUnit";
            this.lblUnit.Size = new System.Drawing.Size(98, 15);
            this.lblUnit.TabIndex = 959;
            this.lblUnit.Text = "Select Store Type:";
            // 
            // lblGroup
            // 
            this.lblGroup.AutoSize = true;
            this.lblGroup.BackColor = System.Drawing.Color.Transparent;
            this.lblGroup.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblGroup.Location = new System.Drawing.Point(15, 79);
            this.lblGroup.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.lblGroup.Name = "lblGroup";
            this.lblGroup.Size = new System.Drawing.Size(115, 15);
            this.lblGroup.TabIndex = 958;
            this.lblGroup.Text = "Product Name (Eng)";
            // 
            // lblBrand
            // 
            this.lblBrand.AutoSize = true;
            this.lblBrand.BackColor = System.Drawing.Color.Transparent;
            this.lblBrand.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblBrand.Location = new System.Drawing.Point(15, 151);
            this.lblBrand.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.lblBrand.Name = "lblBrand";
            this.lblBrand.Size = new System.Drawing.Size(92, 15);
            this.lblBrand.TabIndex = 957;
            this.lblBrand.Text = "Select Category:";
            // 
            // lblProductCode
            // 
            this.lblProductCode.AutoSize = true;
            this.lblProductCode.BackColor = System.Drawing.Color.Transparent;
            this.lblProductCode.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblProductCode.Location = new System.Drawing.Point(374, 47);
            this.lblProductCode.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.lblProductCode.Name = "lblProductCode";
            this.lblProductCode.Size = new System.Drawing.Size(129, 15);
            this.lblProductCode.TabIndex = 956;
            this.lblProductCode.Text = "Product Name (Arabic)";
            // 
            // lblName
            // 
            this.lblName.AutoSize = true;
            this.lblName.BackColor = System.Drawing.Color.Transparent;
            this.lblName.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblName.Location = new System.Drawing.Point(15, 47);
            this.lblName.Margin = new System.Windows.Forms.Padding(0, 0, 0, 5);
            this.lblName.Name = "lblName";
            this.lblName.Size = new System.Drawing.Size(83, 15);
            this.lblName.TabIndex = 955;
            this.lblName.Text = "Product Code:";
            // 
            // Item_Master
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1287, 711);
            this.Controls.Add(this.tcMain);
            this.Controls.Add(this.panel10);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Item_Master";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Item_Master";
            this.Load += new System.EventHandler(this.Item_Master_Load);
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton14)).EndInit();
            this.tcMain.ResumeLayout(false);
            this.Registration.ResumeLayout(false);
            this.Registration.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel37.ResumeLayout(false);
            this.panel38.ResumeLayout(false);
            this.panel38.PerformLayout();
            this.panel35.ResumeLayout(false);
            this.panel35.PerformLayout();
            this.panel36.ResumeLayout(false);
            this.panel36.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.panel33.PerformLayout();
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel28.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel8.PerformLayout();
            this.panel9.ResumeLayout(false);
            this.panel9.PerformLayout();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            this.panel20.ResumeLayout(false);
            this.panel39.ResumeLayout(false);
            this.panel39.PerformLayout();
            this.panel41.ResumeLayout(false);
            this.panel41.PerformLayout();
            this.panel45.ResumeLayout(false);
            this.panel45.PerformLayout();
            this.panel46.ResumeLayout(false);
            this.panel46.PerformLayout();
            this.panel47.ResumeLayout(false);
            this.panel48.ResumeLayout(false);
            this.panel49.ResumeLayout(false);
            this.panel50.ResumeLayout(false);
            this.panel51.ResumeLayout(false);
            this.panel52.ResumeLayout(false);
            this.panel52.PerformLayout();
            this.panel53.ResumeLayout(false);
            this.panel53.PerformLayout();
            this.panel54.ResumeLayout(false);
            this.panel54.PerformLayout();
            this.panel55.ResumeLayout(false);
            this.panel55.PerformLayout();
            this.panel56.ResumeLayout(false);
            this.panel56.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bunifuImageButton15)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton7;
        private System.Windows.Forms.LinkLabel linkLabel1;
        private System.Windows.Forms.LinkLabel btn_delete;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton8;
        private System.Windows.Forms.LinkLabel lnk_exprt;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton11;
        private System.Windows.Forms.LinkLabel lnk_stock_updte;
        private System.Windows.Forms.LinkLabel lnk_sve;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton12;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton13;
        private System.Windows.Forms.LinkLabel lnk_sale_rpt;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton14;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.TabControl tcMain;
        private System.Windows.Forms.TabPage Registration;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.ComboBox combo_Status;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.TextBox txt_AddProfit;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.TextBox txt_Location;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.TextBox txt_RetailPrice;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.TextBox txt_CustomerPrice;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.TextBox txt_PurchasePrice;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.TextBox txt_WholeSalePrice;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.ComboBox combo_SellingCurrency;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.ComboBox combo_PurchaseCurency;
        private System.Windows.Forms.Panel panel6;
        internal System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.Panel panel7;
        internal System.Windows.Forms.DateTimePicker dateTimePicker2;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox txt_ReorderLevel;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.TextBox txt_TaxPercentage;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox txt_NextShoppingDiscount;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.TextBox txt_DirectDiscount;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.ComboBox combo_DiscountType;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.TextBox txt_PreferredVender;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.TextBox txt_CompanyProduct;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.TextBox txt_QtyPerUnit;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.TextBox txt_Description;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.ComboBox combo_Unit;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.ComboBox combo_Color;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.ComboBox combo_Brand;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.ComboBox combo_Category;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.ComboBox combo_Store;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.TextBox txt_ProductnameEng;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.TextBox txt_ProductnameArabic;
        private System.Windows.Forms.Panel panel54;
        private System.Windows.Forms.TextBox txt_Productcode;
        private System.Windows.Forms.Panel panel55;
        private System.Windows.Forms.TextBox txt_Barcode2;
        private System.Windows.Forms.Panel panel56;
        private System.Windows.Forms.TextBox txt_Barcode1;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton3;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private Bunifu.Framework.UI.BunifuImageButton bunifuImageButton15;
        private System.Windows.Forms.Label lblModalNo;
        private System.Windows.Forms.Label lblUnit;
        private System.Windows.Forms.Label lblGroup;
        private System.Windows.Forms.Label lblBrand;
        private System.Windows.Forms.Label lblProductCode;
        private System.Windows.Forms.Label lblName;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button btn_print;
        private System.Windows.Forms.ComboBox combo_search_type;
        private System.Windows.Forms.TextBox txt_search;
        private System.Windows.Forms.TextBox txtID;
    }
}